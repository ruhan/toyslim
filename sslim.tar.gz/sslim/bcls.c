#include<bprmf.h>

/* __thread int * g_acol = NULL; /\* globally pointer to the active columns *\/ */
float * g_ubias = NULL; 
float * g_ibias = NULL; 
extern int g_ext_flag; 
extern int g_Aopt_nrows; 
/* extern long idum;  */
int g_max_bcls_niters = 0; 


/****************************************************************
 * Bound Constrained Least Square
 ****************************************************************/
void bcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){


  g_max_bcls_niters = ctrl->max_bcls_niters; 

  /* set up timers */
  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  ctimer_t * timer0 = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  
  start_timer(timer0); 
 


  /* constants used across all problems */
  int nr = train->nrows; 
  int ni = train->ncols; 
  /*   int nnz = train->rowptr[train->nrows]; */
  /* lower/upper bound */
  double * bl = gk_malloc(sizeof(double)*ni, "malloc bl"); 
  gk_dset(ni, ctrl->bl, bl); 
  double * bu = gk_malloc(sizeof(double)*ni, "malloc bu"); 
  gk_dset(ni, ctrl->bu, bu); 
  /* RHS vector for all problems */
  double * b = gk_malloc(sizeof(double)*nr, "malloc b"); 
  gk_dset(nr, 0, b); 
  /* c, linear vector */
  double * c = gk_malloc(sizeof(double)*ni, "malloc c"); 
  gk_dset(ni, ctrl->lambda, c); 
  double * c1 = gk_malloc(sizeof(double)*ni, "malloc c1"); 
  gk_dset(ni, ctrl->lambda1, c1); 
  /* solution vector */
  double * w = gk_malloc(sizeof(double)*ni, "malloc w"); 
  gk_dset(ni, 0, w); ////
  /* the A matrix */
  gk_csr_t * A = train; 
  /* temp A */
  cs * csA = gk_malloc(sizeof(cs), "malloc csA");
  /* Workspace for BCLS */
  worksp * Wrk = gk_malloc(sizeof(worksp), "malloc Wrk"); 
  Wrk->A = csA;
  csA->p = A->colptr; /* NOTE: pointer assignment! */
  csA->i = A->colind;
  csA->x = A->colval;
  csA->m = A->nrows; /* NOTE: these params will not change across problems */
  csA->n = A->ncols;
  csA->nzmax = *(A->rowptr + A->nrows); 
  csA->nz = -1; /* column-view, not triplet */

  int * acol = gk_malloc(sizeof(int)*ni, "malloc g_acol"); 
  gk_iset(ni, 1, acol); 
  Wrk->acol = acol; 


  /* output data */
  int bsize = 1000; /* at most 1000 cols */
  gk_csr_t * mat = gk_csr_Create(); 
  mat->nrows = 0; 
  mat->ncols = ((ctrl->ibias)? train->ncols + 1: train->ncols); 
  mat->rowptr = gk_malloc(sizeof(int)*(ni+1), "malloc mat->rowptr"); 
  mat->rowptr[0] = 0; 
  mat->rowind = gk_malloc(sizeof(int)*ni*bsize, "malloc mat->rowind"); 
  gk_iset(ni*bsize, 0, mat->rowind); 
  mat->rowval = gk_malloc(sizeof(float)*ni*bsize, "malloc mat->rowval"); 
  gk_fset(ni*bsize, 0, mat->rowval); 




  /* constraint data */
  gk_csr_t * constraint = NULL; 
  if (ctrl->constraint)
    constraint = readConstraint(ctrl, ctrl->constraint_file); 
  
  int starti = (ctrl->starti >= 0)? ctrl->starti:0; 
  int endi   = (ctrl->endi   >= 0)? ctrl->endi:ni; 
  double * initw = NULL;  

  /* initial solution */
  if (!ctrl->constraint){
    if (ctrl->initW_file){
      initw = get_initW(ctrl->initW_file, ni); 
      for (int j = 0; j < ni; j ++)
	w[j] = initw[j];  
    }
  }
  
  /* weghts for each column */
  float * weights = gk_malloc(sizeof(float)*nr, "malloc weights"); 
  gk_fset(nr, 1.0, weights); 
  Wrk->weights = weights; /* pointer assignment */

  /* # of skipped columns */
  int nskipped = 0; 

  /* go through all columns  */
  for (int i = starti; i < endi; i ++){

    
    start_timer(timer); 
    printf("column %8d: ", i); 

    /* the index is beyond the true boundary */
    if (i >= train->ncols){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      end_timer(timer);
      display_timer(timer, "empty iter ");
      nskipped ++; 
      continue;    
    }

    /* this column is totally empty */
    if (train->colptr[i+1] - train->colptr[i] == 0){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      end_timer(timer);
      display_timer(timer, "empty iter ");
      nskipped ++; 
      continue;
    }
    int allzeros = 1;
    for (int j = train->colptr[i]; j < train->colptr[i+1]; j ++){
      if (train->colval[j] != 0) {
	allzeros = 0; break; 
      }
    }
    if (allzeros == 1){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      end_timer(timer);
      display_timer(timer, "empty iter ");
      nskipped ++; 
      continue;    
    }


    /***********************************************************************/
    /* set up all variables needed                                         */
    /***********************************************************************/

    /* recover the full A matrix from last run */
    if (i > starti){

      /* figure out which column to recover, in case last column is empty 
       so it was skipped */

      /* recover last column in A */
      recoverA(ctrl, A, b, weights, i - 1 - nskipped); 
      /* column from last run becomes active in this run */
      acol[i-1 - nskipped] = 1; 
    }



    /* generate A and b needed in this run, and corresponding weights */
    splitAb(ctrl, A, b, weights, i); 
    if (ctrl->normalizeA)
      normRA(ctrl, A, i); 
    /* mark inactive column of this run */
    acol[i] = 0; 


    /* initial solution */
    if (!ctrl->constraint){
      if (ctrl->initw && initw){
	for (int j = 0; j < ni; j ++ )
	  w[j] = initw[j]; 
      }
    }


    /***********************************************************************/
    /* solve the problem                                                   */
    /***********************************************************************/

    /* bound-constraints least square */
    if (!ctrl->constraint){
      switch(ctrl->lmethod){
      case LMETHOD_BCLS:
      case LMETHOD_CBCLS:
	bcsol(ctrl, A, b, w, Wrk, bl, bu, ctrl->beta, c); 
	break; 
      }
    }
    else
      getConstraint(ctrl, constraint, i, w); 
    

    /* explicit sparsity control */
    if (ctrl->sparsity)
      sbcls(ctrl, A, b, w, Wrk, bl, bu, ctrl->beta1, c1);

   

    /* timing for this run */
    end_timer(timer); 
    display_timer(timer, "iter "); 



    /***********************************************************************/
    /* periodically save the results                                       */
    /***********************************************************************/

    /* many enough, dump the data */
    if (mat->nrows >= 1000){
      printf("Dumping data...\n"); 
      csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 
      mat->nrows = 0; 
    }
    
    /* fill out the matrix */
    *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows); 
    for (int j = 0, k = 0; j < ((ctrl->ibias)? ni+1:ni); j ++){
      /*       if ((ctrl->ibias)? (w[j]): (w[j] > 1e-10)){ */
      if ((ctrl->ibias)? (w[j]): (w[j] > 1e-5)){
	*(mat->rowind + mat->rowptr[mat->nrows] + k) = j; 
	*(mat->rowval + mat->rowptr[mat->nrows] + k) = w[j]; 
	(*(mat->rowptr + mat->nrows + 1)) ++; 
	k ++; 
      }
    }
    mat->nrows ++; 




    /***********************************************************************/
    /* set up an initial solution and prepare for next run                 */
    /***********************************************************************/
    if (!ctrl->constraint){
      if (ctrl->initw ){
	if (initw == NULL){
	  initw = gk_malloc(sizeof(double)*ni, "malloc initw");  
	  for (int j = 0; j < ni; j ++ )
	    initw[j] = w[j]; 
	}/* else */
      }else{
	gk_dset(ni, 0, w); 
      }
    }else{
      gk_dset(ni, 0, w); 
    }

    nskipped = 0; 

  } /* end of starti - endi */
  
  end_timer(timer0); 
  display_timer(timer0, "BCLS"); 

  /* left-over data dump */
  printf("Dumping data...\n"); 
  csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 




  /***********************************************************************/
  /* finish up                                                           */ 
  /***********************************************************************/
  gk_free((void **)&timer, LTERM);   gk_free((void **)&timer0, LTERM); 
  gk_csr_Free(&mat);   gk_free((void **)&w, LTERM); 
  gk_free((void **)&bl, &bu, &b, &c, &c1, LTERM); 
  gk_csr_Free(&constraint);   gk_free((void **)&initw, LTERM); 
  gk_free((void **)&csA, LTERM);   gk_free((void **)&Wrk, LTERM); 
  gk_free((void **)&acol, LTERM); 
  gk_free((void **)&g_ubias, LTERM);   gk_free((void **)&g_ibias, LTERM); 
  gk_free((void **)&weights, LTERM); 

}

/*************************************************************
 * normalize each row of R without column j
 * Note this is assuming R is binary
 *************************************************************/
void normRA(ctrl_t * ctrl, gk_csr_t * R, int j){

  int nnz = R->colptr[j+1] - R->colptr[j]; 
  for (int jj = 0; jj < nnz; jj ++){
    int i = *(R->colptr[j] + jj + R->colind);
    R->rnorms[i] -= 1.0; /* do not count column j in row normalization */
  }
  /* row-normalization of R, on the column view of R */
  for (int k = 0; k < *(R->colptr + R->ncols); k ++){
    int i = *(R->colind + k); 
    if (R->rnorms[i])
      *(R->colval + k) = 1.0 / (R->rnorms[i]); /* assume R is binary */
  }
  /* recover R->rnorms */
  for (int jj = 0; jj < nnz; jj ++){
    int i = *(R->colptr[j] + jj + R->colind); 
    R->rnorms[i] += 1.0; /* do not count column j in row normalization */
  }

}

