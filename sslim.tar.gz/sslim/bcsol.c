#include<bprmf.h>

/* /\* global pointers to active columns, specified via splitting problems *\/ */
/* extern __thread int * g_acol;  */
/* global pointers to user bias, e.g., row-wise mean */
extern float * g_ubias; 
/* global pointers to item bias, e.g., column-wise mean */
extern float * g_ibias; 
/* global flag to show if the rating matrix is extened by the binary version */
extern int g_ext_flag; 
/* global number to show the first g_Aopt_nrows rows need the Aopt operations, 
   but the others do not */
extern int g_Aopt_nrows;

int niters = 0; 
extern int g_max_bcls_niters; 

#define CS_MAX(a,b) (((a) > (b)) ? (a) : (b))
#define CS_MIN(a,b) (((a) < (b)) ? (a) : (b))
#define CS_FLIP(i) (-(i)-2)
#define CS_UNFLIP(i) (((i) < 0) ? CS_FLIP(i) : (i))
#define CS_MARKED(w,j) (w [j] < 0)
#define CS_MARK(w,j) { w [j] = CS_FLIP (w [j]) ; }
#define CS_CSC(A) (A && (A->nz == -1))
#define CS_TRIPLET(A) (A && (A->nz >= 0))


// Type of projected search.                                                                  
static int proj_search = BCLS_PROJ_SEARCH_EXACT;
/* static int proj_search = BCLS_PROJ_SEARCH_APPROX; */
// Method for Newton step computation.                                                        
static int newton_step = BCLS_NEWTON_STEP_LSQR;


int ncounts = 0; 


// ---------------------------------------------------------------------                      
// CallBack.                                                                                  
// Periodically called by BCLS to test if the user wants to exit.                             
// ---------------------------------------------------------------------                      
int CallBack( BCLS *ls, void *UsrWrk )
{
  int err;
  err = 0;  // No error.                                                                    
  return err;
}

/***********************************************************************
 * call back function, immediately terminate BCLS iterations based on
 * how many iterations it runs
 ***********************************************************************/
int CallBack_it( BCLS *ls, void *UsrWrk )
{

  niters ++; 
  if (niters == g_max_bcls_niters)
    return 1; 
  else 
    return 0; 
}


// ---------------------------------------------------------------------                      
// pretty_printer                                                                             
// This is the print-routine that will be used by BCLS for its output.                        
// ---------------------------------------------------------------------                      
int pretty_printer( void *io_file, char *msg ) {
  fprintf( io_file, "%s\n", msg );
  return 0;
}


/* wrapper for free */
void *cs_free (void *p)
{
  if (p) free (p) ;	    /* free p if it is not already NULL */
  return (NULL) ;	    /* return NULL to simplify the use of cs_free */
}


/* wrapper for malloc */
void *cs_malloc (int n, size_t size)
{
  return (malloc (CS_MAX (n,1) * size)) ;
}


/* wrapper for calloc */
void *cs_calloc (int n, size_t size)
{
  return (calloc (CS_MAX (n,1), size)) ;
}




/* free a sparse matrix */
cs *cs_spfree (cs *A)
{
  if (!A) return (NULL) ;     /* do nothing if A already NULL */
  cs_free (A->p) ;
  cs_free (A->i) ;
  cs_free (A->x) ;
  return (cs_free (A)) ;      /* free the cs struct and return NULL */
}


/* allocate a sparse matrix (triplet form or compressed-column form) */
cs *cs_spalloc (int m, int n, int nzmax, int values, int triplet)
{
  cs *A = cs_calloc (1, sizeof (cs)) ;    /* allocate the cs struct */
  if (!A) return (NULL) ;                 /* out of memory */
  A->m = m ;                              /* define dimensions and nzmax */
  A->n = n ;
  A->nzmax = nzmax = CS_MAX (nzmax, 1) ;
  A->nz = triplet ? 0 : -1 ;              /* allocate triplet or comp.col */
  A->p = cs_malloc (triplet ? nzmax : n+1, sizeof (int)) ;
  A->i = cs_malloc (nzmax, sizeof (int)) ;
  A->x = values ? cs_malloc (nzmax, sizeof (double)) : NULL ;
  return ((!A->p || !A->i || (values && !A->x)) ? cs_spfree (A) : A) ;
}

// ---------------------------------------------------------------------                      
// dload                                                                                      
// Load a constant into a vector.                                                             
// ---------------------------------------------------------------------                      
void dload( const int n, const double alpha, double x[] ) {

  int j;
  for (j = 0; j < n; j++) x[j] = alpha;
  return;
}



// ---------------------------------------------------------------------
// Aprod
// Matrix-vector products.
//
// If     mode == BCLS_PROD_A  (0), compute y <- A *x, with x untouched;
// and if mode == BCLS_PROD_At (1), compute x <- A'*y, with y untouched.
// ---------------------------------------------------------------------
int Aprod( int mode, int m, int n, int nix, int ix[],
	   double x[], double y[], void *UsrWrk ) {
  
  int     i, j, k, l;
  double  aij;
  double xj, sum;
  worksp * Wrk = (worksp *)UsrWrk;
  cs *A = (cs *)Wrk->A;
  int * Ai = A->i; 
  int * Ap = A->p; 
  float * Ax = A->x; 
  float * weights = Wrk->weights; 
  int * acol = Wrk->acol; 

  ncounts ++; 

  /*   assert( mode == BCLS_PROD_A     || */
  /* 	  mode == BCLS_PROD_At    || */
  /* 	  mode == BCLS_PROD_INIT  || */
  /* 	  mode == BCLS_PROD_TERM  ); */
  /*   assert( nix  <= n ); */
  /*   assert( A->m == m ); */
  /*   assert( A->n == n ); */

  if (mode == BCLS_PROD_A) {

    gk_dset(m, 0.0, y); 

    for (l = 0; l < nix; l++) {
      j = ix[l];
      
/*       if (!g_acol[j]) continue; */
      if (!acol[j]) continue;

      xj = x[j];
      if (xj == 0.0)
	; // Relax.
      else
	for (k = Ap[j]; k < Ap[j+1]; k++) {
	  aij   = Ax[k];

	  /* 	  /\* 		    assert(aij == 1 || aij == 0);  *\/ */
	  /* 	  if (!g_acol[j])  assert( aij == 0);   */
	  /* 	  else assert( aij == 1);   */

	  /* this is to handle float-valued A matrix */
	  i     = Ai[k];
	  /* y[i] += aij * xj; */
	  y[i] += aij * xj * weights[i]; /* weighted version */

	  
	  /* 	  /\* this is specific to binary A matrix *\/ */
	  /* 	  i = Ai[k]; */
	  /* 	  y[i] += xj; */
 
	}
    }
  }

  else if (mode == BCLS_PROD_At) {
    for (l = 0; l < nix; l++) {
      j = ix[l];
      sum = 0;

/*       if (!g_acol[j]) { */
      if (!acol[j]) {
	x[j] = sum;
	continue;
      }

      for (k = Ap[j]; k < Ap[j+1]; k++) {
	aij  = Ax[k];
	/* 	/\* 		assert(aij == 1 || aij == 0);  *\/ */
	/* 	if (!g_acol[j])  assert( aij == 0);   */
	/* 	else assert( aij == 1);   */

	/* this is to handle float-valued A matrix */
	i    = Ai[k];
	/* sum += aij * y[i]; */
	sum += aij * y[i] * weights[i]; /* weighted version */

	/* this is specific to binary A matrix */
	/* 	i    = Ai[k]; */
	/* 	sum += y[i]; */
	
      }
      x[j] = sum;
    }
  }

  // Exit.
  return 0;
}


/******************************************************************
 * min 1/2 || A x - b||^2 + 1/2 beta ||x||^2 + lambda x
 *     1/2 || A x - b||^2 + 1/2 mu ||x||^2 + c^t x
 *
 * st.    0 <= x 
 ******************************************************************/
void  bcsol(ctrl_t * ctrl, gk_csr_t * AA, double * bb, double * x, worksp * Wrk, 
	    double * bl, double * bu, 
	    double beta, double * c){

  ncounts = 0; 
  niters = 0; 

  /*  Problem dimensions. */
  int m = AA->nrows; 
  int n = AA->ncols; 

  /* init a bcls problem */
  BCLS   *ls = bcls_create_prob( m, n ); 

  switch(ctrl->Aopt){
    /* use original A */
  case AOPT_SPARSE:
/*   case AOPT_UBIAS: */
/*   case AOPT_IBIAS: */
    bcls_set_problem_data(ls, m, n, Aprod,  Wrk, beta, x, bb, c, bl, bu); 
    break; 

    /* use the A matrix after row-wise user bias and column-wise item bias
       has been subtracted */
  case AOPT_FULL_BIAS:
    /* use the A matrix after row-wise user bias has been subtracted */
  case AOPT_UBIAS:
    /* use the A matrix after column-wise item bias has been subtracted */
  case AOPT_IBIAS:
    bcls_set_problem_data(ls, m, n, Aprodd, Wrk, beta, x, bb, c, bl, bu); 
    break; 
  }

  /* set up tolerance */
  ls->optTol = ctrl->optTol;  
    
  /* whatever */
  bcls_set_print_hook( ls, stdout, pretty_printer );
  ls->proj_search    = proj_search; 
  ls->newton_step    = newton_step; 
  if (ctrl->test_bcls)
    ls->CallBack       = CallBack_it; 
  else
    ls->CallBack       = CallBack; 

  /* call the solver */
  /* int err = bcls_solve_prob( ls );  */
  bcls_solve_prob( ls ); 

  /* solution */
  if (ctrl->dbglvl > 1){
    int nnzx = 0; 
    printf("\n Solution\n --------\n");
    printf("%4s  %18s %1s %18s %1s %18s  %18s\n",
	   "Var","Lower","","Value","","Upper","Gradient");
    for (int j = 0; j < n; j++) {
      if (x[j] > 1e-10){
	nnzx ++; 
	char * blActiv = "";
	char * buActiv = "";
	if (x[j] - bl[j] < ls->epsx) blActiv = "=";
	if (bu[j] - x[j] < ls->epsx) buActiv = "=";
	printf("%4d  %18.11e %1s %18.11e %1s %18.11e  %18.11e\n",
	       j+1, bl[j], blActiv, x[j], buActiv, bu[j], (ls->g)[j]);
      }
    }
    printf("%d nnz solution values\n", nnzx); 
  }
    

  /* free the problem */
  /* err = bcls_free_prob( ls ); */
  bcls_free_prob( ls );

/*   printf("Aprod %d times\n", ncounts);  */

}


/**************************************************************************/
/*  Aprod                                                                 */
/*  Matrix-vector products, for structured psuedo-sparse A.               */
/*  A: size of m by n, in column-major format (GK_CSR_COL format)         */ 
/*  A->p : A->colptr                                                      */ 
/*  A->i : A->colind                                                      */
/*  A->x : A->colval                                                      */ 
/*                                                                        */
/*  If     mode == BCLS_PROD_A  (0), compute y <- A *x, with x untouched; */
/*  and if mode == BCLS_PROD_At (1), compute x <- A'*y, with y untouched. */
/*  x and y are dense vectors                                             */
/**************************************************************************/
int Aprodd( int mode, int m, int n, int nix, int ix[],
	    double x[], double y[], void *UsrWrk ) {
  
  int     i, j, k, l;
  double  aij;
  double xj, sum;
  worksp * Wrk = (worksp *)UsrWrk;
  cs *A = (cs *)Wrk->A;
  int * Ai = A->i; 
  int * Ap = A->p; 
  float * Ax = A->x; 
  double sum_x = 0, sum_y = 0; 
  double ic = 0, uc = 0; 
  int * acol = Wrk->acol; 

  ncounts ++; 

  /*   assert( mode == BCLS_PROD_A     || */
  /* 	  mode == BCLS_PROD_At    || */
  /* 	  mode == BCLS_PROD_INIT  || */
  /* 	  mode == BCLS_PROD_TERM  ); */
  /*   assert( nix  <= n ); */
  /*   assert( A->m == m ); */
  /*   assert( A->n == n ); */

  if (mode == BCLS_PROD_A) {

    /* full-length y */
    gk_dset(m, 0.0, y); 

    /* only the columns of interest */
    for (l = 0; l < nix; l++) {
      j = ix[l]; 
      
/*       if (!g_acol[j]) continue; */
      if (!acol[j]) continue;

      xj = x[j];
      if (xj == 0.0)
	; // Relax.
      else{
	for (k = Ap[j]; k < Ap[j+1]; k++) {
	  aij   = Ax[k];

	  /* 	  /\* 		    assert(aij == 1 || aij == 0);  *\/ */
	  /* 	  if (!g_acol[j])  assert( aij == 0);   */
	  /* 	  else assert( aij == 1);   */


	  /* this is to handle float-valued A matrix */
	  i     = Ai[k];
	  y[i] += aij * xj;

	  /* 	  /\* this is specific to binary A matrix *\/ */
	  /* 	  i = Ai[k]; */
	  /* 	  y[i] += xj; */
 
	}
      }
    }

    /* sum_x in range for user-mean component */
    for(l = 0; l < nix; l ++){
      j = ix[l];
/*       if (!g_acol[j]) continue; */
      if (!acol[j]) continue;
      sum_x += x[j]; 
    }
    /* the constant in range for item-mean component */
    for (l = 0; l < nix; l ++){
      j = ix[l]; 
/*       if (!g_acol[j]) continue; */
      if (!acol[j]) continue;
      ic += g_ibias[j]*x[j]; 
    }
    /* compute the dense A*x in range */
    for (i = 0; i < m; i ++){
      if (g_ext_flag == 1){
	if (i < g_Aopt_nrows)
	  y[i] -= sum_x * g_ubias[i] + ic; 
	else
	  ; 
      }else{
	y[i] -= sum_x * g_ubias[i] + ic; 
      }
    }

  }

  else if (mode == BCLS_PROD_At) {
    for (l = 0; l < nix; l++) {
      j = ix[l];
      sum = 0;

/*       if (!g_acol[j]) { */
      if (!acol[j]) {
	x[j] = sum;
	continue;
      }

      for (k = Ap[j]; k < Ap[j+1]; k++) {
	aij  = Ax[k];
	/* 	/\* 		assert(aij == 1 || aij == 0);  *\/ */
	/* 	if (!g_acol[j])  assert( aij == 0);   */
	/* 	else assert( aij == 1);   */

	/* this is to handle float-valued A matrix */
	i    = Ai[k];
	sum += aij * y[i];

/* 	/\* this is specific to binary A matrix *\/ */
/* 	i    = Ai[k]; */
/* 	sum += y[i]; */
	
      }
      x[j] = sum;
    }

    /* sum_y in range for item-mean component */
    for(i = 0; i < m; i ++)
      sum_y += y[i]; 
    /* the constant in range for user-mean component */
    for(i = 0; i < m; i ++){
      if (g_ext_flag == 1){
	if (i < g_Aopt_nrows)
	  uc += g_ubias[i] * y[i]; 
	else
	  ; 
      }else{
	uc += g_ubias[i] * y[i]; 
      }
    }
    /* compute the dense A'*y in range */
    for (l = 0; l < nix; l ++){
      j = ix[l]; 
/*       if (!g_acol[j]) continue; */
      if (!acol[j]) continue;
      x[j] -= uc + g_ibias[j] * sum_y; 
    }

  }

  // Exit.
  return 0;
}
