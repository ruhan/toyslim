#include<bprmf.h>


/******************************************************
 * collective BCLS
 *****************************************************/
void cbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  double alpha = ctrl->alpha; 
  assert(alpha >= 0); 
  int interi = ctrl->interi; 
  assert(interi <= train->nrows); 

  for (int i = train->rowptr[interi]; i < train->rowptr[train->nrows]; i ++){
    train->rowval[i] *= (float)sqrt(alpha); 
  }

  gk_csr_CreateIndex(train, GK_CSR_COL); 
  
  bcls(ctrl, train, test); 

}
