#include<bprmf.h>

/*************************************************************
 * check errors
 ************************************************************/
void check_error(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  suggest_model_t * model = NULL; 

  /* 
     suggest model is nothing but an |I|-by-|I| item-item similarity matrix, 
     in which each value at position (i, j) says if item i is within 
     item j's neighborbood (i.e., nnz values), and value determines "similarity"
     Note that it is the output directly from QP, which is the transpose of 
     W in AW ~ A and the transpose of SUGGEST itemcos model, and this is the
     default model setting
  */
  model = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); 
  model->ncols = train->ncols; 
  gk_csr_SortIndices(model, GK_CSR_ROW);

  
  int nrows = train->nrows; 
  int ncols = train->ncols; 
  float error = 0.0; 
  float error1 = 0.0, error0 = 0.0; 
  for (int i = 0; i < nrows; i ++){
    
    int ni = train->rowptr[i+1] - train->rowptr[i]; 

    if (i % 100 == 0){
      printf("."); fflush(stdout); 
    }

    /* for (int j = 0; j < ni; j ++){ */
    for (int j = 0; j < ncols; j ++){

      int nj = (model->rowptr[j+1] - model->rowptr[j]); 

      int i2 = 0, j2 = 0; 
      float sum = 0; 

      while (i2 < ni && j2 < nj){
      
	int jj1  = *(train->rowptr[i] + i2 + train->rowind);
	int jj2  = *(model->rowptr[j] + j2 + model->rowind);
	float v1 = *(train->rowptr[i] + i2 + train->rowval);
	float v2 = *(model->rowptr[j] + j2 + model->rowval);

	if (jj1 == jj2){
	  sum += v1 * v2; 
	  i2 ++; j2 ++; 
	}else if (jj1 < jj2)
	  i2 ++; 
	else 
	  j2 ++; 
      }
      
      float v = 0;
      for (int ii = 0; ii < ni; ii ++){
	if (*(train->rowptr[i] + ii + train->rowind) == j){
	  v = *(train->rowptr[i] + ii + train->rowval); 
	  break ; 
	}
      }

      if (ctrl->ibias)
	sum += *(model->rowptr[j] + nj - 1 + model->rowval); 
      
      if (v != 0)
	error1 = error1 + ((v - sum)*(v - sum));  
      else
	error0 = error0 + ((v - sum)*(v - sum));  

      error    = error  + ((v - sum)*(v - sum)); 
    }
  }


  printf("\nsum of squared error             = %.5f\n", error); 
  printf("sum of squared error on ratings  = %.5f\n", error1); 
  printf("sum of squared error on missings = %.5f\n", error0); 

  gk_csr_Free(&model); 

}

/*************************************************************
 * check if test is in train
 ************************************************************/
void check_train_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  int error = 0; 

  int nrows_test = test->nrows; 

  for (int i = 0; i < nrows_test; i ++){
    
    int nc_test = test->rowptr[i+1] - test->rowptr[i]; 
    int nc_train = train->rowptr[i+1] - train->rowptr[i]; 

    for (int j = 0; j < nc_test; j ++){
      
      int item_test = *(test->rowptr[i] + j + test->rowind); 
      
      for (int k = 0; k < nc_train; k ++){
	
	int item_train = *(train->rowptr[i] + k + train->rowind); 

	if (item_test == item_train){
	  printf("ERROR: user %6d has item %6d in both train and test\n", i, item_train); 
	  error = 1; 
	  break; 
	}

      }

    }

  }

  if (error)
    errexit("ERROR: train and test not disjoint\n"); 

}
