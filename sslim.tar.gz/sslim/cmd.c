#include<bprmf.h>

/*******************************************************
 * command-line options
 ******************************************************/
static struct gk_option bprmf_options[] = {
  {"train_file",               1,      0,       CMD_TRAIN_FILE}, 
  {"test_file",                1,      0,       CMD_TEST_FILE}, 
  {"ft_file",                  1,      0,       CMD_FT_FILE}, 
  {"suggest_file",             1,      0,       CMD_SUGGEST_FILE}, 
  {"constraint_file",          1,      0,       CMD_CONSTRAINT_FILE}, 
  {"initW_file",               1,      0,       CMD_INITW_FILE}, 
  {"similarity_file",          1,      0,       CMD_SIMILARITY_FILE}, 
  {"c_pos",                    1,      0,       CMD_C_POS}, 
  {"k",                        1,      0,       CMD_K}, 
  {"k0",                       1,      0,       CMD_K0}, 
  {"k1",                       1,      0,       CMD_K1}, 
  {"user_bias",                0,      0,       CMD_USER_BIAS}, 
  {"item_bias",                0,      0,       CMD_ITEM_BIAS}, 
  {"init_mean",                1,      0,       CMD_INIT_MEAN}, 
  {"init_stdev",               1,      0,       CMD_INIT_STDEV}, 
  {"max_nepochs",              1,      0,       CMD_MAX_NEPOCHS}, 
  {"iter_length",              1,      0,       CMD_ITER_LENGTH}, 
  {"lrate",                    1,      0,       CMD_LRATE}, 
  {"reg_i",                    1,      0,       CMD_REG_I}, 
  {"reg_j",                    1,      0,       CMD_REG_J}, 
  {"reg_u",                    1,      0,       CMD_REG_U}, 
  {"topn",                     1,      0,       CMD_TOPN}, 
  {"dbglvl",                   1,      0,       CMD_BPRMF_DBGLVL}, 
  {"blas",                     0,      0,       CMD_BLAS}, 
  {"pfile",                    1,      0,       CMD_PFILE}, 
  {"ifile",                    1,      0,       CMD_IFILE},
  {"ufile",                    1,      0,       CMD_UFILE},    
  {"load_model",               0,      0,       CMD_LOAD_MODEL},
  {"save_model",               0,      0,       CMD_SAVE_MODEL}, 
  {"save_model_iter",          0,      0,       CMD_SAVE_MODEL_ITER}, 
  {"notest",                   0,      0,       CMD_NOTEST}, 
  {"exttest",                  0,      0,       CMD_EXTTEST}, 
  {"exttest_file",             1,      0,       CMD_EXTTEST_FILE}, 
  {"fast_test",                0,      0,       CMD_FAST_TEST}, 
  {"lmethod",                  1,      0,       CMD_LMETHOD}, 
  {"normalize",                0,      0,       CMD_NORMALIZE}, 
  {"sc_weighted",              0,      0,       CMD_SCWEIGHTED}, 
  {"sm_topk",                  1,      0,       CMD_SMTOPK}, 
  {"wsim",                     1,      0,       CMD_WSIM}, 
  {"wtype",                    1,      0,       CMD_WTYPE}, 
  {"fast_sample",              0,      0,       CMD_FAST_SAMPLE}, 
/*   {"test2",                    0,      0,       CMD_TEST2},  */
  {"lambda",                   1,      0,       CMD_BPRMF_LAMBDA},
  {"beta",                     1,      0,       CMD_BETA}, 
  {"lambda1",                  1,      0,       CMD_BPRMF_LAMBDA1},
  {"lambda2",                  1,      0,       CMD_BPRMF_LAMBDA2},
  {"beta1",                    1,      0,       CMD_BETA1}, 
  {"beta2",                    1,      0,       CMD_BETA2}, 
  {"gamma",                    1,      0,       CMD_GAMMA}, 
  {"gamma1",                   1,      0,       CMD_GAMMA1}, 
  {"sigma",                    1,      0,       CMD_SIGMA}, 
  {"alpha",                    1,      0,       CMD_ALPHA}, 
  {"starti",                   1,      0,       CMD_STARTI}, 
  {"interi",                   1,      0,       CMD_INTERI}, 
  {"endi",                     1,      0,       CMD_ENDI}, 
  {"realtime_eval",            0,      0,       CMD_REALTIME_EVAL}, 
  {"error2",                   0,      0,       CMD_ERROR2}, 
  {"errork",                   0,      0,       CMD_ERRORK}, 
  {"w1",                       1,      0,       CMD_W1}, 
  {"normalizeA",               0,      0,       CMD_NORMALIZEA}, 
  {"p",                        1,      0,       CMD_P}, 
  {"sparsity",                 0,      0,       CMD_SPARSITY}, 
  {"gnoise",                   0,      0,       CMD_GNOISE}, 
  {"constraint",               0,      0,       CMD_CONSTRAINT}, 
  {"rowmajor",                 0,      0,       CMD_ROWMAJOR}, 
  {"ibias",                    0,      0,       CMD_IBIAS}, 
  {"bl",                       1,      0,       CMD_BL}, 
  {"bu",                       1,      0,       CMD_BU}, 
  {"stop",                     0,      0,       CMD_STOP}, 
  {"tol",                      1,      0,       CMD_TOL}, 
  {"ibias_step",               1,      0,       CMD_IBIAS_STEP}, 
  {"sample_train",             0,      0,       CMD_SAMPLETRAIN}, 
  {"srate",                    1,      0,       CMD_SRATE}, 
  {"optTol",                   1,      0,       CMD_OPTTOL}, 
  {"initw",                    0,      0,       CMD_INITW}, 
  {"sim_threshold",            1,      0,       CMD_SIM_THRESHOLD}, 
  {"mst",                      0,      0,       CMD_MST}, 
  {"pred_norm",                0,      0,       CMD_PRED_NORM}, 
  {"Aopt",                     1,      0,       CMD_AOPT}, 
  {"cdl1_method",              1,      0,       CMD_CDL1_METHOD}, 
  {"combineBR",                0,      0,       CMD_COMBINEBR}, 
  {"nratings",                 1,      0,       CMD_NRATINGS}, 
  {"check_support",            0,      0,       CMD_CHECK_SUPPORT}, 
  {"test_bcls",                0,      0,       CMD_TEST_BCLS}, 
  {"max_bcls_niters",          1,      0,       CMD_MAX_BCLS_NITERS}, 
  {"suggest_br",               0,      0,       CMD_SUGGEST_BR}, 
  {"rscale",                   1,      0,       CMD_RSCALE}, 
  {"rscale_alpha",             1,      0,       CMD_RSCALE_ALPHA}, 
  {"pred_rating",              0,      0,       CMD_PRED_RATING}, 
  {"kernel",                   1,      0,       CMD_KERNEL}, 
  {"nthreads",                 1,      0,       CMD_NTHREADS}, 
  {"openmp",                   0,      0,       CMD_OPENMP}, 
  {"mult2binary",              0,      0,       CMD_MULT2BINARY}, 
  {0,                          0,      0,       0}
};

/*************************************************
 * kernel options
 *************************************************/
static gk_StringMap_t kernel_options[] = {
  {"linear",   KERNEL_LINEAR}, 
  {"logistic", KERNEL_LOGISTIC}, 
  {"rbf",      KERNEL_RBF}, 
}; 

/*************************************************
 * rscale options
 *************************************************/
static gk_StringMap_t rscale_options[] = {
  {"rbf",         RSCALE_RBF}, 
  {"linear",      RSCALE_LINEAR}, 
  {"log",         RSCALE_LOG}, 
  {"sq",          RSCALE_SQ}, 
  {NULL,          0}
};


/*************************************************
 * wsim options
 *************************************************/
static gk_StringMap_t wsim_options[] = {
  {"sparse",      WSIM_SPARSE},
  {"dense",       WSIM_DENSE},
  {"combine",     WSIM_COMBINE}, 
  {NULL,          0}
};

/*************************************************
 * wtype options
 *************************************************/
static gk_StringMap_t wtype_options[] = {
  {"user",        WTYPE_USER}, 
  {"item",        WTYPE_ITEM}, 
  {NULL,          0}
};

/*************************************************
 * cdl1 method
 *************************************************/
static gk_StringMap_t cdl1method_options[] = {
  {"naive",       CDL1_METHOD_NAIVE},
  {"covariance",  CDL1_METHOD_COVARIANCE}, 
  {NULL,          0}
};


/*************************************************
 * Aopt options
 *************************************************/
static gk_StringMap_t Aopt_options[] = {
  {"original",    AOPT_SPARSE},     /* original sparse A */
  {"full_bias",   AOPT_FULL_BIAS},  /* dense A with user&item bias subtracted */
  {"ubias",       AOPT_UBIAS},      /* sparse A with ubias subtracted along each row */
  {"ibias",       AOPT_IBIAS},      /* sparse A with ibias subtracted along each column */
  {"tfidf",       AOPT_TFIDF},      /* if tf-idf on A */
  {NULL,          0}
};



/*************************************************
 * learning METHOD 
 *************************************************/
static gk_StringMap_t lmethod_options[] = {
  {"cbcls",       LMETHOD_CBCLS}, 
  {"scbcls",      LMETHOD_SCBCLS}, 
  {"bprmf",       LMETHOD_BPRMF},
  {"bprmfr",      LMETHOD_BPRMFR},
  {"bpriknn",     LMETHOD_BPRIKNN}, 
  {"bpriknnr",    LMETHOD_BPRIKNNR}, 
  {"wrmf",        LMETHOD_WRMF}, 
  {"wrmfr",       LMETHOD_WRMFR}, 
  {"brismf",      LMETHOD_BRISMF}, 
  {"cdl1",        LMETHOD_CDL1}, 
  {"cdl1lr",      LMETHOD_CDL1LR}, 
  {"svd",         LMETHOD_SVD},
  {"suggest",     LMETHOD_SUGGEST}, 
  {"suggestlr",   LMETHOD_SUGGESTLR}, 
  {"suggest_blend",LMETHOD_SUGGEST_BLEND}, 
  {"sc",          LMETHOD_SC}, 
  {"qp",          LMETHOD_QP}, 
  {"bcls",        LMETHOD_BCLS},
  {"dbcls",       LMETHOD_DBCLS},
  {"enet",        LMETHOD_ENET}, 
  {"check_error", LMETHOD_CHECK_ERROR}, 
  {"smfsgd",      LMETHOD_SMFSGD}, 
  {"cwrmf",       LMETHOD_CWRMF}, 
  {"fm",          LMETHOD_FM}, 
  {"suggest2sim", LMETHOD_SUGGEST2SIM}, 
  {"contbcls1",   LMETHOD_CONTBCLS1}, 
  {"contbcls2",   LMETHOD_CONTBCLS2}, 
  {"contbcls_test1",   LMETHOD_CONTBCLS_TEST1}, 
  {"contbcls_test2",   LMETHOD_CONTBCLS_TEST2}, 
  {"sibcls",      LMETHOD_SIBCLS}, 
  {"sibcls_test", LMETHOD_SIBCLS_TEST}, 
  {"sibcls2",     LMETHOD_SIBCLS2}, 
  {"sibcls2_test",LMETHOD_SIBCLS2_TEST}, 
  {"sibcls2_constraint",      LMETHOD_SIBCLS2_CONSTRAINT}, 
  {"sibcls2_constraint_test", LMETHOD_SIBCLS2_CONSTRAINT_TEST}, 
  {"dsibcls1",    LMETHOD_DSIBCLS1}, 
  {"dsibcls2",    LMETHOD_DSIBCLS2}, 
  {"dsibcls_test",LMETHOD_DSIBCLS_TEST}, 
  {"dsibcls21",   LMETHOD_DSIBCLS21}, 
  {"dsibcls22",   LMETHOD_DSIBCLS22}, 
  {"dsibcls2_test", LMETHOD_DSIBCLS2_TEST}, 
  {NULL,          0}
};


/******************************************************                                                                                                                                             
 * entry point of the command-line argument parsing                                                                                                                                                 
 * the ctrl should be NULL when calling this function                                                                                                                                               
 ******************************************************/
void parse_cmdline(ctrl_t *ctrl, int argc, char * argv[]){

  int c = -1, option_index = -1;
  
  if (ctrl == NULL)
    ctrl = create_ctrl(); 

  while((c = gk_getopt_long_only(argc, argv, "", bprmf_options, &option_index)) != -1){
    switch(c){

    case CMD_SUGGEST_BR:
      ctrl->suggest_br = 1; 
      break; 

    case CMD_MAX_BCLS_NITERS:
      ctrl->max_bcls_niters = atoi(gk_optarg); 
      break; 

    case CMD_TEST_BCLS:
      ctrl->test_bcls = 1; 
      break; 

    case CMD_C_POS:
      ctrl->c_pos = atof(gk_optarg); 
      break; 

    case CMD_CHECK_SUPPORT:
      ctrl->check_support = 1; 
      break; 

    case CMD_NTHREADS:
      ctrl->nthreads = atoi(gk_optarg); 
      break; 

    case CMD_OPENMP:
      ctrl->openmp = 1; 
      break; 

    case CMD_COMBINEBR:
      ctrl->combineBR = 1; 
      break; 

    case CMD_PRED_NORM:
      ctrl->pred_norm = 1; 
      break; 

    case CMD_MST:
      ctrl->mst = 1; 
      break; 


    case CMD_RSCALE_ALPHA:
      ctrl->rscale_alpha = atof(gk_optarg); 
      break; 

    case CMD_NRATINGS:
      ctrl->nratings = atoi(gk_optarg); 
      break; 

    case CMD_PRED_RATING:
      ctrl->pred_rating = 1; 
      break; 

    case CMD_SIM_THRESHOLD:
      ctrl->sim_threshold = atof(gk_optarg); 
      break; 
      
    case CMD_OPTTOL:
      ctrl->optTol = atof(gk_optarg); 
      break; 

    case CMD_SAMPLETRAIN:
      ctrl->sample_train = 1; 
      break; 
      
    case CMD_INITW:
      ctrl->initw = 1; 
      break; 

    case CMD_SRATE:
      ctrl->srate = (float)atof(gk_optarg); 
      break; 

    case CMD_IBIAS_STEP:
      ctrl->ibias_step = (float)atof(gk_optarg); 
      break; 

    case CMD_SIGMA:
      ctrl->sigma = atof(gk_optarg); 
      break; 

    case CMD_STOP:
      ctrl->stop = 1; 
      break; 
      
    case CMD_TOL:
      ctrl->tol = atof(gk_optarg); 
      break; 
      
    case CMD_BL:
      ctrl->bl = atof(gk_optarg); 
      break; 
    case CMD_BU:
      ctrl->bu = atof(gk_optarg); 
      break; 

    case CMD_ROWMAJOR:
      ctrl->rowmajor = 1; 
      break; 

    case CMD_CONSTRAINT:
      ctrl->constraint = 1; 
      break; 

    case CMD_GNOISE:
      ctrl->gnoise = 1; 
      break; 

    case CMD_SPARSITY:
      ctrl->sparsity = 1; 
      break; 

    case CMD_ERRORK:
      ctrl->errork = 1; 
      break; 

    case CMD_P:
      ctrl->p = atof(gk_optarg); 
      break; 

    case CMD_NORMALIZEA:
      ctrl->normalizeA = 1; 
      break; 


    case CMD_IBIAS:
      ctrl->ibias = 1; 
      break; 

    case CMD_W1:
      ctrl->w1 = atof(gk_optarg); 
      break; 

    case CMD_ERROR2:
      ctrl->error2 = 1; 
      break; 

    case CMD_STARTI:
      ctrl->starti = atoi(gk_optarg); 
      break; 
    case CMD_ENDI:
      ctrl->endi = atoi(gk_optarg); 
      break; 
    case CMD_INTERI:
      ctrl->interi = atoi(gk_optarg); 
      break; 

    case CMD_REALTIME_EVAL:
      ctrl->realtime_eval = 1; 
      break; 
      
    case CMD_FAST_SAMPLE:
      ctrl->fast_sample = 1; 
      break; 

    case CMD_GAMMA1:
      ctrl->gamma1 = atof(gk_optarg); 
      break; 

    case CMD_GAMMA:
      ctrl->gamma = atof(gk_optarg); 
      break; 

    case CMD_BPRMF_LAMBDA:
      ctrl->lambda = atof(gk_optarg);
      break; 
    case CMD_BETA:
      ctrl->beta = atof(gk_optarg); 
      break; 

    case CMD_BPRMF_LAMBDA1:
      ctrl->lambda1 = atof(gk_optarg);
      break; 
    case CMD_BPRMF_LAMBDA2:
      ctrl->lambda2 = atof(gk_optarg);
      break; 

    case CMD_BETA1:
      ctrl->beta1 = atof(gk_optarg); 
      break; 
    case CMD_BETA2:
      ctrl->beta2 = atof(gk_optarg); 
      break; 
    case CMD_ALPHA:
      ctrl->alpha = atof(gk_optarg); 
      break; 

    case CMD_TEST2:
      ctrl->test2 = 1; 
      break; 

    case CMD_SMTOPK:
      ctrl->sm_topk = atoi(gk_optarg); 
      break; 

    case CMD_SCWEIGHTED:
      ctrl->sc_weighted = 1; 
      break; 

    case CMD_NORMALIZE:
      ctrl->normalize = 1; 
      break; 

    case CMD_FAST_TEST:
      ctrl->fast_test = 1; 
      break; 

    case CMD_KERNEL:
      if (gk_optarg){
	if ((ctrl->kernel = gk_GetStringID(kernel_options, gk_optarg)) == -1)
          errexit("Unknown kernel method  specified\n");
      }
      break; 

    case CMD_RSCALE:
      if (gk_optarg){
	if ((ctrl->rscale = gk_GetStringID(rscale_options, gk_optarg)) == -1)
          errexit("Unknown Rscale method  specified\n");
      }
      break; 

    case CMD_CDL1_METHOD:
      if (gk_optarg){
	if ((ctrl->cdl1_method = gk_GetStringID(cdl1method_options, gk_optarg)) == -1)
          errexit("Unknown CDL1 method  specified\n");
      }
      break; 

    case CMD_AOPT:
      if (gk_optarg){
	if ((ctrl->Aopt = gk_GetStringID(Aopt_options, gk_optarg)) == -1)
          errexit("Unknown Aopt method  specified\n");
      }
      break; 
      
    case CMD_PFILE:
      ctrl->pred_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_SIMILARITY_FILE:
      ctrl->similarity_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_INITW_FILE:
      ctrl->initW_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_EXTTEST_FILE:
      ctrl->exttest_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_EXTTEST:
      ctrl->exttest = 1; 
      break; 

    case CMD_NOTEST:
      ctrl->notest = 1; 
      break; 

    case CMD_LOAD_MODEL:
      ctrl->load_model = 1; 
      break; 

    case CMD_SAVE_MODEL:
      ctrl->save_model = 1; 
      break; 

    case CMD_SAVE_MODEL_ITER:
      ctrl->save_model_iter = 1; 
      break; 

    case CMD_UFILE:
      ctrl->ufactor_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_IFILE:
      ctrl->ifactor_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_REG_U:
      ctrl->reg_u = atof(gk_optarg); 
      break; 

    case CMD_TOPN:
      ctrl->topn = atoi(gk_optarg); 
      break; 

    case CMD_REG_J:
      ctrl->reg_j = atof(gk_optarg); 
      break; 

    case CMD_REG_I:
      ctrl->reg_i = atof(gk_optarg); 
      break; 

    case CMD_LRATE:
      ctrl->lrate = atof(gk_optarg); 
      break; 
      
    case CMD_ITER_LENGTH:
      ctrl->iter_length = atoi(gk_optarg); 
      break; 

    case CMD_MAX_NEPOCHS:
      ctrl->max_nepochs = atoi(gk_optarg); 
      break; 


    case CMD_CONSTRAINT_FILE:
      ctrl->constraint_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_SUGGEST_FILE:
      ctrl->suggest_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_TRAIN_FILE:
      ctrl->train_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_FT_FILE:
      ctrl->ft_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_TEST_FILE:
      ctrl->test_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_K0:
      ctrl->k0 = atoi(gk_optarg); 
      break; 
    case CMD_K1:
      ctrl->k1 = atoi(gk_optarg); 
      break; 

    case CMD_K:
      ctrl->k = atoi(gk_optarg); 
      break; 

    case CMD_USER_BIAS:
      ctrl->user_bias = true; 
      break; 

    case CMD_ITEM_BIAS:
      ctrl->item_bias = true; 
      break; 

    case CMD_INIT_MEAN:
      ctrl->init_mean = atof(gk_optarg); 
      break; 

    case CMD_INIT_STDEV:
      ctrl->init_stdev = atof(gk_optarg); 
      break; 

    case CMD_BPRMF_DBGLVL:
      ctrl->dbglvl = atoi(gk_optarg); 
      break; 
      
    case CMD_BLAS:
      ctrl->blas = 1; 
      break; 

    case CMD_WSIM:
      if (gk_optarg){
	if ((ctrl->wsim = gk_GetStringID(wsim_options, gk_optarg)) == -1)
          errexit("Unknown wsim method  specified\n");
      }
      break; 

    case CMD_WTYPE:
      if (gk_optarg){
	if ((ctrl->wtype = gk_GetStringID(wtype_options, gk_optarg)) == -1)
          errexit("Unknown wtype method  specified\n");
      }
      break; 

    case CMD_MULT2BINARY:
      ctrl->mult2binary = 1; 
      break; 


    case CMD_LMETHOD:
      if (gk_optarg){
	if ((ctrl->lmethod = gk_GetStringID(lmethod_options, gk_optarg)) == -1)
          errexit("Unknown leanring method  specified\n");
      }
      break;


    case '?':
    default:
      printf("Illegal command-line option(s) %s\n", gk_optarg);
      exit(0);

    }
  }

/*   seed_random(ctrl, ctrl->rseed);  */

}
