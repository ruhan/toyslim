#ifndef __BPRMF_DEF_H__
#define __BPRMF_DEF_H__

#define CMD_TRAIN_FILE 1
#define CMD_TEST_FILE  2
#define CMD_K          3
#define CMD_USER_BIAS  4
#define CMD_ITEM_BIAS  5
#define CMD_INIT_MEAN  6
#define CMD_INIT_STDEV 7
#define CMD_MAX_NEPOCHS 8
#define CMD_ITER_LENGTH 9
#define CMD_LRATE      10 
#define CMD_REG_I      11 
#define CMD_REG_J      12
#define CMD_REG_U      13
#define CMD_TOPN       14
#define CMD_BPRMF_DBGLVL     15
#define CMD_BLAS       16
#define CMD_IFILE      18
#define CMD_LOAD_MODEL 19
#define CMD_SAVE_MODEL 20
#define CMD_UFILE      30
#define CMD_NOTEST     40
#define CMD_EXTTEST    50
#define CMD_EXTTEST_FILE 60
#define CMD_FAST_TEST    70
#define CMD_LMETHOD      80
#define CMD_SUGGEST_FILE 90
#define CMD_NORMALIZE   100
#define CMD_SCWEIGHTED  110
#define CMD_SMTOPK      120
#define CMD_TEST2       130
#define CMD_BPRMF_LAMBDA      140
#define CMD_BETA        150
#define CMD_STARTI      160
#define CMD_ENDI          170
#define CMD_REALTIME_EVAL 180
#define CMD_FAST_SAMPLE   190
#define CMD_WSIM          200
#define CMD_ERROR2        300
#define CMD_W1            350
#define CMD_NORMALIZEA    360
#define CMD_P             370
#define CMD_ERRORK        380
#define CMD_SPARSITY      390
#define CMD_BETA1         400
#define CMD_BETA2         405
#define CMD_ALPHA         406
#define CMD_BPRMF_LAMBDA1       410
#define CMD_BPRMF_LAMBDA2       411
#define CMD_GNOISE        420
#define CMD_CONSTRAINT    430
#define CMD_CONSTRAINT_FILE 440
#define CMD_ROWMAJOR      450
#define CMD_IBIAS         460
#define CMD_BL            500
#define CMD_BU            510
#define CMD_STOP          520
#define CMD_TOL           530
#define CMD_SIGMA         540
#define CMD_IBIAS_STEP    550
#define CMD_SRATE         600
#define CMD_SAMPLETRAIN   610
#define CMD_OPTTOL        700
#define CMD_INITW         710
#define CMD_INITW_FILE    720
#define CMD_SIM_THRESHOLD 730
#define CMD_SIMILARITY_FILE 740
#define CMD_MST             750
#define CMD_PRED_NORM       760
#define CMD_AOPT            770
#define CMD_CDL1_METHOD     780
#define CMD_COMBINEBR       790
#define CMD_GAMMA           800
#define CMD_NRATINGS        810
#define CMD_CHECK_SUPPORT   820
#define CMD_TEST_BCLS       900
#define CMD_MAX_BCLS_NITERS 910
#define CMD_SUGGEST_BR      920
#define CMD_GAMMA1          930
#define CMD_RSCALE          940
#define CMD_RSCALE_ALPHA    950
#define CMD_C_POS           960
#define CMD_PRED_RATING     1000
#define CMD_SAVE_MODEL_ITER 1100
#define CMD_KERNEL          1200
#define CMD_NTHREADS        1300
#define CMD_OPENMP          1400
#define CMD_WTYPE           1500
#define CMD_INTERI          1600
#define CMD_CBCLS           1700
#define CMD_K0              1800
#define CMD_K1              1801
#define CMD_FT_FILE         1802
#define CMD_PFILE           1900
#define CMD_MULT2BINARY     2000

#define WSIM_SPARSE  1
#define WSIM_DENSE   2
#define WSIM_COMBINE 3

#define WTYPE_USER 1
#define WTYPE_ITEM 2

#define LMETHOD_BPRMF       1
#define LMETHOD_SVD         2
#define LMETHOD_SUGGEST     3
#define LMETHOD_SC          4
#define LMETHOD_QP          5
#define LMETHOD_BCLS        6
#define LMETHOD_ESBCLS      7
#define LMETHOD_ENET        8
#define LMETHOD_BRISMF      9
#define LMETHOD_CDL1        10
#define LMETHOD_CHECK_ERROR 11
#define LMETHOD_BPRMFR      12
#define LMETHOD_WRMF        13
#define LMETHOD_WRMFR       14
#define LMETHOD_BPRIKNN     15
#define LMETHOD_BPRIKNNR    16
#define LMETHOD_CDL1LR      17
#define LMETHOD_SUGGESTLR   18
#define LMETHOD_SMFSGD      19
#define LMETHOD_DBCLS       20
#define LMETHOD_CBCLS       21
#define LMETHOD_CWRMF       22
#define LMETHOD_FM          23
#define LMETHOD_SUGGEST2SIM 24
#define LMETHOD_CONTBCLS1   25
#define LMETHOD_CONTBCLS2   26
#define LMETHOD_SCBCLS      27
#define LMETHOD_CONTBCLS_TEST1 28
#define LMETHOD_CONTBCLS_TEST2 29
#define LMETHOD_COLDSUGGEST    30
#define LMETHOD_SUGGEST_BLEND 31
#define LMETHOD_SIBCLS      32
#define LMETHOD_SIBCLS_TEST 33
#define LMETHOD_DSIBCLS1    34
#define LMETHOD_DSIBCLS2    35
#define LMETHOD_DSIBCLS_TEST    36
#define LMETHOD_SIBCLS2      37
#define LMETHOD_SIBCLS2_TEST 38
#define LMETHOD_DSIBCLS21    39
#define LMETHOD_DSIBCLS22    40
#define LMETHOD_DSIBCLS2_TEST 41
#define LMETHOD_SIBCLS2_CONSTRAINT 42
#define LMETHOD_SIBCLS2_CONSTRAINT_TEST 43


#define KERNEL_LINEAR   1
#define KERNEL_LOGISTIC 2
#define KERNEL_RBF      3


#define CDL1_METHOD_NAIVE      1
#define CDL1_METHOD_COVARIANCE 2

#define SUGGEST_TOPK_KEEPVAL 1000000

#define AOPT_SPARSE    1
#define AOPT_FULL_BIAS 2
#define AOPT_UBIAS     3
#define AOPT_IBIAS     4
#define AOPT_TFIDF     5

#define RSCALE_RBF 1
#define RSCALE_LINEAR 2
#define RSCALE_LOG 3
#define RSCALE_SQ 4

#define DUSER 1
#define DITEM 2

#define TRANSPOSE   1
#define NOTRANSPOSE 0

#define NORM_L2 2
#define NORM_L1 1


#define SAMPLE_ALL 1
#define SAMPLE_ASRATE 2

#define RCMD_EXCLUDE_HISTORY 1
#define RCMD_INCLUDE_HISTORY 2

#define EPSILON 0.000001

#define CSR_SUBTRACT 1
#define CSR_ADD      2

#endif
