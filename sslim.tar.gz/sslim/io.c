#include<bprmf.h>

/*****************************************************
 * load a factor model from a file
 ****************************************************/
mf_model_t * bprmf_load(ctrl_t * ctrl, char * ufile, char * ifile){

  printf("Loading model from file %s and %s...\n", ufile, ifile); fflush(stdout); 

  
  int nu = 0, uk = 0; 
  double ** ufactor = load_matrix(ufile, &nu, &uk); 
  
  int ni = 0, ik = 0; 
  double ** ifactor = load_matrix(ifile, &ni, &ik); 

  assert(uk == ik); 

  mf_model_t * model = gk_malloc(sizeof(mf_model_t), "malloc model"); 

  model->nu = nu; 
  model->ni = ni; 
  model->k  = uk - 1; 

  model->user_bias = ctrl->user_bias; 
  model->item_bias = ctrl->item_bias; 
  
  model->user_factors = ufactor; 
  model->item_factors = ifactor; 

  return model; 
  
}



/*****************************************************
 * save a factor model into a file
 ****************************************************/
void bprmf_save(ctrl_t * ctrl, mf_model_t * model, char * ufile, char * ifile){

  printf("Saving model into file %s and %s...\n", ufile, ifile); fflush(stdout); 

  save_matrix(ufile, model->user_factors, model->nu, model->k+1); 
  save_matrix(ifile, model->item_factors, model->ni, model->k+1); 

}

/*****************************************************
 * load a matrix from a file
 ****************************************************/
double ** load_matrix(char * file, int * nr, int * nc){

  FILE * fp = gk_fopen(file, "r", "open file"); 

  double ** matrix = NULL; 
  gk_idx_t  nrows = 0, nnz = 0, ncols = 0, nbytes = 0; 
  gk_getfilestats(file, &nrows, &nnz, &nbytes); 
  ncols = nnz / nrows; /* dense matrix */

  matrix = gk_dAllocMatrix(nrows, ncols, 0, "malloc matrix"); 

  for (int i = 0; i < nrows; i ++){

    char * line = NULL; 
    size_t n = 0; 
    gk_getline(&line, &n, fp); 
    gk_Tokens_t itokens; 
    gk_strtokenize(line, " \t\n", &itokens); 
    
    assert(ncols == itokens.ntoks); 

    for (int j = 0; j < ncols; j ++)
      matrix[i][j] = atof(itokens.list[j]); 
    

    gk_freetokenslist(&itokens); 
    gk_free((void **)&line, LTERM); 

  }

  gk_fclose(fp); 

  *nr = nrows; 
  *nc = ncols; 
  
  return matrix; 

}


/*****************************************************
 * save a matrix into a file
 ****************************************************/
void save_matrix(char * file, double ** mat, int nr, int nc){

  FILE * fp = gk_fopen(file, "w", "open file"); 

  for (int i = 0; i < nr; i ++){
    for (int j = 0; j < nc; j ++){
      fprintf(fp, "%.5f ", mat[i][j]); 
    }
    fprintf(fp, "\n"); 
  }

  gk_fclose(fp); 

}

/*****************************************************
 * read constraint/item-sim file
 ****************************************************/
gk_csr_t * readConstraint(ctrl_t * ctrl, char * file){

  gk_csr_t * constraint = gk_csr_Read(file, GK_CSR_FMT_CSR, 1, 1); 

  if (ctrl->rowmajor){
    /* use the model from Wsparse as constraint, which is transpose of W actually */
    constraint->colptr = constraint->rowptr; 
    constraint->colind = constraint->rowind; 
    constraint->colval = constraint->rowval; 
    int tmp_ncols = constraint->ncols; 
    constraint->ncols  = constraint->nrows; 
    constraint->rowptr = NULL; 
    constraint->rowind = NULL; 
    constraint->rowval = NULL; 
    constraint->nrows  = tmp_ncols; 
    gk_csr_CreateIndex(constraint, GK_CSR_ROW); 
  }else{
    /* use the model from SUGGEST as constraint */
    gk_csr_CreateIndex(constraint, GK_CSR_COL); 
  }
  /*     assert(constraint->nrows == constraint->ncols);  */

  return constraint; 
}

/*****************************************************
 * print a vector into a file
 ****************************************************/
void save_vector(char * file, double * w, int n){

  FILE * fp = gk_fopen(file, "w", "open file"); 

  for (int i = 0; i < n; i ++)
    fprintf(fp, "%.10f\n", w[i]); 


  gk_fclose(fp); 

}

/*****************************************************
 * load a vector into a file
 ****************************************************/
double * load_vector(char * file, int * n){

  FILE * fp = gk_fopen(file, "r", "load vecotr"); 

  gk_idx_t  nrows = 0, nnz = 0, nbytes = 0; 
  gk_getfilestats(file, &nrows, &nnz, &nbytes); 

  double * w = gk_malloc(sizeof(double)*nrows, "malloc w"); 
  for (int i = 0;i < nrows; i ++)
    fscanf(fp, "%lf\n", &w[i]); 


  gk_fclose(fp); 
  *n = nrows; 

  return w; 

}
