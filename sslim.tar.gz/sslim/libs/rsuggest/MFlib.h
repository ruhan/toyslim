#include<mf_struct.h>  


#ifndef __MFLIB_H_
#define __MFLIB_H_

#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <time.h>
#include <string.h>
#include <limits.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>
#include <sys/stat.h>


#include<mf_defs.h>
#include<GKlib.h>
//#include<proto.h>  
//#include<suggest.h>

/* io.c */
/* void ReadMatrix(MatType *, char *); */
/* void PrintMat(MatType *); */
/* void WriteMatrix(char *, MatType *); */
/* void WriteMatrix_Mat(char *, MatType *); */
void WriteVector(char * filename, double * vector, int nrows,  int ncols); 


/* np.c */
float * NonPersonalizedUser(params_t *params, gk_csr_t *train, gk_csr_t *test);
float * NonPersonalizedItem(params_t *params, gk_csr_t *train, gk_csr_t *test);
float *NonPersonalizedUserItem(params_t *params, gk_csr_t *train, gk_csr_t *test);

/* mf.c */
float *MatrixFactorization(params_t *params, gk_csr_t *train0, gk_csr_t *test);
/* float *LocalMatrixFactorization(params_t *params, gk_csr_t *train0, gk_csr_t *test); */
/* float *LocalMatrixFactorization2(params_t *params, gk_csr_t *train0, gk_csr_t *test); */
int BRISMF(params_t *params, gk_csr_t *train, gk_csr_t *validate, double *conf, 
        double *p, double *q);
void SplitIntoLearnValidate(params_t *params, gk_csr_t *train, gk_csr_t **lmat,
         gk_csr_t **vmat);
model_mf_t * LearnMFModel(params_t * params, gk_csr_t * train); 
float *ApplyMFModel(params_t *params, gk_csr_t *test, double mu, double *p, double *q);
double ComputeRMSE(params_t *params, gk_csr_t *test, double *conf, double *p, double *q);


#ifdef XXX
/* urate.c */
void UserKnnRecommender(CtrlType *, MatType *, MatType *, float *);
float RecommendKnnPosNeg(CtrlType *, MatType *, int, int, float *, float *, FKeyValueType *);
float RecommendKnnPos(CtrlType *, MatType *, int, int, float *, float *, FKeyValueType *);


/* irate.c */
void ItemKnnRecommender(CtrlType *, MatType *, MatType *, float *);
GraphType *ComputeItemGraph(CtrlType *, MatType *);
float FindRateTranslation(CtrlType *, int **, float *);
float RecommendIKNbrRT(CtrlType *, MatType *, int, int, GraphType *, FKeyValueType *, float *);
float RecommendIKNbrSim(CtrlType *, MatType *, int, int, GraphType *, FKeyValueType *, float *);
float RecommendIKNbrSimSlow(CtrlType *, MatType *, int, int, FKeyValueType *, float *);


/* matutil.c */
void CreateColMat(MatType *);
void InitMat(MatType *);
void FreeMat(MatType *);


#endif

/* stat.c */
void AnalyzeRecommendations(params_t *param, gk_csr_t *test, int *active, float *rcmds);

/* cmdline.c */
params_t *getcmdline_params(int argc, char **argv);


#endif
