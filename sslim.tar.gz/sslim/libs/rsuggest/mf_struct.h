/*
 * struct.h
 *
 * This file contains data structures for the bigroup clustering algorithm
 *
 * Started 10/31/99
 * George
 *
 * $Id: struct.h 8857 2010-06-24 13:39:45Z karypis $
 */

#ifndef _STRUCT_H_
#define _STRUCT_H_
#include<GKlib.h>

#ifdef XXX
/*************************************************************************
* This data structure stores the data set
**************************************************************************/
struct matdef {
  int nrows, ncols;
  int *rowptr, *rowind;
  int *colptr, *colind;
  float *rowval, *colval;
  float *rowavg, *colavg;
};

typedef struct matdef MatType;


/*************************************************************************
* This data structure stores user-item ratings
**************************************************************************/
struct ratedef {
  int nratings;
  int *userid;
  int *itemid;
  float *rating;
};

typedef struct ratedef RateType;



/*************************************************************************
* This data structure stores a sparse graph 
**************************************************************************/
struct graphdef {
  int nvtxs;
  int *xadj, *adjncy;
  float *adjwgt;
  int *adjiwgt;
  float *rmap;
};

typedef struct graphdef GraphType;


/*************************************************************************
* The following data structure is used to store the buckets for the
* refinment algorithms
**************************************************************************/
struct pqueuedef {
  int nnodes;
  int maxnodes;

  /* Heap version of the data structure */
  FKeyValueType *heap;
  int *locator;
};

typedef struct pqueuedef PQueueType;

#endif

/*************************************************************************
* matrix-factorization based model data structure
**************************************************************************/
typedef struct{

  int n;      /* # of users*/   
  int m;      /* # of items */
  int k;      /* # of factors */
  double mu;  /* global mean */
  double * p; /* user factor vectors*/
  double * q; /* item factor vectors */

}model_mf_t; 


/*************************************************************************
* This data structure stores control information
**************************************************************************/
typedef struct {
  int rtype;            /* The recommendation algorithm to use */

  int nnbrs;            /* The number of neighbors in the personalized algorithms */

  float minrvalue;        /* Minimum rating value */
  float maxrvalue;        /* Maximum rating value */
  float rrange;           /* The range of the ratings */

  int nepochs;          /* The maximum number of gradient descent epochs */
  int msize;            /* The model size for the MF-based approaches */
  double lambda;        /* The regularization parameter */
  double lrnrate;       /* The learning rate for the gradient descent algorithm */
  float vldfrac;        /* The fraction of the training set to be used for validation */

  int nparts;           /* The number of clusters to use */

  int map2int;          /* Maps the predicted ratings into the closest int */
  int mincom;           /* The minimum number of common ratings before even computing a corelation */
  float mincfrac;       /* The fraction of common items */
  float minerror;       /* The minimum aceptable translation error */
  int MType;            /* The scheme to use to compute the weights of the neighbors */
  int dbglvl;           /* Debuging information */
  float expfactor;      /* exponent to be raised for weight assignment */ 

  char *trainfile;      /* The file storing the training set */
  char *testfile;       /* The file storing the testing set */
  char * umodelfile;    /* user model file for output */
  char * imodelfile;    /* item model file for output */
} params_t;



#endif 
