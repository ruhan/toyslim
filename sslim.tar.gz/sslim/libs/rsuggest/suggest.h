/*
 * suggest.h
 *
 * This file contains the various header inclusions
 *
 * Started 4/6/99
 * George
 */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <time.h>

#include <suggest_GKlib.h>
//#include <cluto.h>

#ifdef DMALLOC
#include <dmalloc.h>
#endif

/* #include <suggest_struct.h> */
#include <mf_struct.h>
/* #include <suggest_defs.h> */
#include <mf_defs.h>
/* #include <suggest_proto.h> */
#include <mf_proto.h>

