/*
 * defs.h
 *
 * This file contains various constant definitions
 *
 * Started 4/8/99
 * George
 *
 */

int commoncnt[943];

#define MAXLINE         1024*128

#define MFACTOR         10000.0
#define SPOWER          1.0

#define PRUNEFRACTION   0.75
#define PRUNEFRACTION2  0.75

#define NCOMMON         20

#define MINCOS          .40

#define IKNN            50


/* command-line options */
#define CMD_RTYPE               1
#define CMD_NNBRS               2
#define CMD_MSIZE               3
#define CMD_LAMBDA              4
#define CMD_LRNRATE             5
#define CMD_VLDFRAC             6
#define CMD_MINR                7
#define CMD_MAXR                8
#define CMD_NPARTS              9
#define CMD_NEPOCHS             10
#define CMD_DBGLVL              100
#define CMD_HELP                200
#define CMD_UMODELFILE          300
#define CMD_IMODELFILE          400


/* recommendation types */
#define RTYPE_NPU               1
#define RTYPE_NPI               2
#define RTYPE_NPUI              3
#define RTYPE_NNU               4
#define RTYPE_NNI               5
#define RTYPE_MF                6
#define RTYPE_LMF               7
#define RTYPE_LMF2              8

/* The text labels for the different rowmodels */
/* static char rtypenames[][10] = */
/*                {"", "npu", "npi", "npui", "nnu", "nni", "mf", "lmf", "lmf2"}; */


