#include<bprmf.h>

int * iidx = NULL; 
/* gsl_vector * uvector = NULL;  */
/* gsl_vector * ivector = NULL; */

extern float * g_ubias; 
extern float * g_ibias; 
extern float * g_A_colval; 
/**********************************************************
 * main entry
 **********************************************************/
int main(int argc, char * argv[]){
  
  srand(0); 

  /* parse command line */
  ctrl_t * ctrl = create_ctrl(); 
  parse_cmdline(ctrl, argc, argv); 

  /* I/O */
  gk_csr_t * train = gk_csr_Read(ctrl->train_file, GK_CSR_FMT_CSR, 1, 1); 
  gk_csr_t * test  = gk_csr_Read(ctrl->test_file, GK_CSR_FMT_CSR, 1, 1); 

  /* preprocess training data */
  preprocess(ctrl, train, test); 
  
  /* learn/prediction */
  switch(ctrl->lmethod){


    /* collective bcls */
  case LMETHOD_CBCLS:
    cbcls(ctrl, train, test); 
    break; 

    /* co-regularized BCLS */
  case LMETHOD_SCBCLS:
    scbcls(ctrl, train, test); 
    break; 

    /* slim using side info, explicit diagonal constraint */
  case LMETHOD_SIBCLS2:
    sibcls2(ctrl, train, test); 
    break; 
  case LMETHOD_SIBCLS2_TEST:
    sibcls2_test(ctrl, train, test); 
    break; 


    
/*     /\* weighted regularized matrix factorization*\/ */
/*   case LMETHOD_WRMF: */
/*   case LMETHOD_WRMFR: */
/*     wrmf(ctrl, train, test);  */
/*     break;  */

/*     /\* collective weighted regularized matrix factorization *\/ */
/*   case LMETHOD_CWRMF: */
/*     cwrmf(ctrl, train, test);  */
/*     break;  */


/*     /\* Bayesian Personalized Ranking with Matrix Factorization *\/ */
/*   case LMETHOD_BPRMF: */
/*   case LMETHOD_BPRMFR: */
/*     bprmf(ctrl, train, test);  */
/*     break;  */

/*     /\* sparse MF via stochastic gradient descent  *\/ */
/*   case LMETHOD_SMFSGD: */
/*     smfsgd(ctrl, train, test); */
/*     break; */

/*     /\* Bayesian Personalized Ranking with item-knn *\/ */
/*   case LMETHOD_BPRIKNN: */
/*   case LMETHOD_BPRIKNNR: */
/*     bpriknn(ctrl, train, test);  */
/*     break;  */

/*     /\* BRISMF *\/ */
/*   case LMETHOD_BRISMF: */
/*     brismf(ctrl, train, test);  */
/*     break;  */

/*     /\* Pure SVD *\/ */
/*   case LMETHOD_SVD: */
/*     ssvd(ctrl, train, test); */
/*     break; */
    
/*     /\* SUGGEST item-based *\/ */
/*   case LMETHOD_SUGGEST: */
/*     suggest(ctrl, train, test);  */
/*     break;  */

/* /\*     /\\* SUGGEST for cold start *\\/ *\/ */
/* /\*   case LMETHOD_COLDSUGGEST: *\/ */
/* /\*     cold_suggest(ctrl, train, test);  *\/ */
/* /\*     break;  *\/ */
    
/*     /\* SUGGEST + LR *\/ */
/*   case LMETHOD_SUGGESTLR: */
/*     suggestlr(ctrl, train, test); */
/*     break; */

/*     /\* SUGGEST from two sim matrices *\/ */
/*   case LMETHOD_SUGGEST2SIM: */
/*     suggest2sim(ctrl, train, test);  */
/*     break;  */

/*     /\* SUGGEST and blending with session info *\/ */
/*   case LMETHOD_SUGGEST_BLEND: */
/*     suggest_blend(ctrl, train, test);  */
/*     break;  */
    
/* /\*     /\\* Set-Covering *\\/ *\/ */
/* /\*   case LMETHOD_SC: *\/ */
/* /\*     ssc(ctrl, train, test);  *\/ */
/* /\*     break;  *\/ */

/*     /\* bound constrained least squares *\/ */
/*   case LMETHOD_BCLS: */
/*     /\* elastic net  *\/ */
/*   case LMETHOD_ENET:  */
/* /\*     if (ctrl->ibias) *\/ */
/* /\*       bcls_bias(ctrl, train, test);  *\/ */
/* /\*     else *\/ */
/*     if (ctrl->mst) */
/*       bcls_tree(ctrl, train, test);  */
/*     else */
/*       bcls(ctrl, train, test);  */
/*     break; */

    

/*     /\* double BCLS *\/ */
/*   case LMETHOD_DBCLS: */
/*     dbcls(ctrl, train, test); */
/*     break; */

/*     /\* coordinate descent for least squares *\/ */
/*   case LMETHOD_CDL1: */
/*     cdl1(ctrl, train, test);  */
/*     break;  */

/*     /\* coordinate descent for logistic regression *\/ */
/*   case LMETHOD_CDL1LR: */
/*     cdl1lr(ctrl, train, test);  */
/*     break;  */

/* /\*     /\\* AW ~ W via QP *\\/ *\/ */
/* /\*   case LMETHOD_QP: *\/ */
/* /\*     qp_train(ctrl, train, test); *\/ */
/* /\*     break; *\/ */

/*     /\* factorization machines *\/ */
/*   case LMETHOD_FM: */
/*     fm(ctrl, train, test);  */
/*     break;  */
    
/*     /\* content-based model *\/ */
/*   case LMETHOD_CONTBCLS1: */
/*   case LMETHOD_CONTBCLS2: */
/*   case LMETHOD_CONTBCLS_TEST1: */
/*   case LMETHOD_CONTBCLS_TEST2: */
/* /\*     contbcls(ctrl, train, test);  *\/ */
/*     contbcls2(ctrl, train, test);  */
/*     break;  */

/* /\*     /\\* slim using side info *\\/ *\/ */
/* /\*   case LMETHOD_SIBCLS: *\/ */
/* /\*     sibcls(ctrl, train, test);  *\/ */
/* /\*     break;  *\/ */
/* /\*   case LMETHOD_SIBCLS_TEST: *\/ */
/* /\*     sibcls_test(ctrl, train, test);  *\/ */
/* /\*     break;  *\/ */

/*     /\* slim using side info, explicit diagonal constraint & non-zero structure constraint *\/ */
/*   case LMETHOD_SIBCLS2_CONSTRAINT: */
/*   case LMETHOD_SIBCLS2_CONSTRAINT_TEST: */

/*     /\* slim + sibcls*\/ */
/*   case LMETHOD_DSIBCLS1: */
/*   case LMETHOD_DSIBCLS2:  */
/*     dsibcls(ctrl, train, test);  */
/*     break;  */
/*   case LMETHOD_DSIBCLS_TEST: */
/*     dsibcls_test(ctrl, train, test);  */
/*     break;  */

/*     /\* slim + sibcls2 *\/ */
/*   case LMETHOD_DSIBCLS21: */
/*   case LMETHOD_DSIBCLS22: */
/*     dsibcls2(ctrl, train, test);  */
/*     break;  */
/*   case LMETHOD_DSIBCLS2_TEST: */
/*     dsibcls2_test(ctrl, train, test);  */
/*     break; */


/*   case LMETHOD_CHECK_ERROR: */
/*     check_error(ctrl, train, test);  */
/*     break;  */

  }


  /* clean up */
  free_ctrl(ctrl); 
  gk_csr_Free(&train); 
  gk_csr_Free(&test); 
  gk_free((void **)&iidx, LTERM); 
  /* if (uvector)    gsl_vector_free(uvector);  */
  /* if (ivector)    gsl_vector_free(ivector);  */
  if (g_ubias)    gk_free((void **)&g_ubias, LTERM); 
  if (g_ibias)    gk_free((void **)&g_ibias, LTERM); 
  if (g_A_colval) gk_free((void **)&g_A_colval, LTERM); 
}
