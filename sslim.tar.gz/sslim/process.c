#include<bprmf.h>


extern float * g_ubias; 
extern float * g_ibias; 

int g_ext_flag = 0; 
int g_Aopt_nrows = -1; 

/****************************************************************
 * pre-process training/testing data
 ****************************************************************/
void preprocess(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  if (ctrl->rscale){
    rscale(ctrl, train); 
/*     rscale(ctrl, test);  */
  }

  /* user-based/item-based model */
  switch(ctrl->wtype){
  case WTYPE_ITEM:
    break; 
  case WTYPE_USER:
/*     csr_transpose(train);  */
    break; 
  }

  /* record row size of train, this is used when normalize train */
  train->rnorms = gk_fsmalloc(train->nrows, 0.0, "rnorms"); 
  for (int i = 0; i < train->nrows; i ++)
    train->rnorms[i] = train->rowptr[i+1] - train->rowptr[i]; 
    

  /* pre-calculate user-bias and item-bias, on original rating data */
  gk_csr_CreateIndex(train, GK_CSR_COL); 
  g_ubias = csr_mean(train, GK_CSR_ROW); 
  g_ibias = csr_mean(train, GK_CSR_COL);   
  

  if (ctrl->combineBR){
    extend_binary(ctrl, train); 
    g_ext_flag = 1; /* flag that the rating version is 
		       extended by the binary version, used in fast Aprod */
    g_Aopt_nrows = train->nrows/2; /* the first g_Aopt_nrows rows need the 
				    Aopt operation, used in fast Aprod */
  }

  /* sort column indices */
  gk_csr_SortIndices(train, GK_CSR_ROW); 
  gk_csr_SortIndices(test,  GK_CSR_ROW); 

  /* sanity check */
  if (ctrl->dbglvl > 1)
    check_train_test(ctrl, train, test);

  /* all in column-view of the training matrix */
  gk_csr_CreateIndex(train, GK_CSR_COL); 

  /* some pre-processing */
  if (ctrl->normalizeA)
    gk_csr_Normalize(train, GK_CSR_ROW, 1);  


  /* sample training data */
  if (ctrl->sample_train){
    printf("sampling..\n"); fflush(stdout); 
    gk_csr_t * train2 = csr_sampling_rows(train, ctrl->srate); 
    /* random sampling of nnzs */
    /*     gk_csr_t * train2 = csr_sampling(train, ctrl->srate);  */
    gk_csr_Free(&train); 
    train = train2; 
  }

  /* process A(train) matrix. NOTE test matris is untouched */
  switch(ctrl->Aopt){
    /* use the original A, need to do nothing */
  case AOPT_SPARSE: 
    break; 

    /* A has user bias and item bias subtracted.
       need to do nothing for now but later on */
  case AOPT_FULL_BIAS:
/*     /\* pre-calculate user-bias and item-bias *\/ */
/*     g_ubias = csr_mean(train, GK_CSR_ROW);  */
/*     g_ibias = csr_mean(train, GK_CSR_COL);    */
    break; 

/*     /\* A has user bias subtracted from each row, ONLY ON NNZS *\/ */
  case AOPT_UBIAS:
/*     for (int i = 0; i < train->nrows; i ++){ */
/*       int ni = train->rowptr[i+1] - train->rowptr[i];  */
/*       float rsum = 0;  */
/*       for (int jj = 0; jj < ni; jj ++) */
/* 	rsum += *(train->rowptr[i] + jj + train->rowval);  */
/*       /\* average across all nnzs! *\/  */
/*       rsum /= (float)ni;  */
/*       for (int jj = 0; jj < ni; jj ++) */
/* 	*(train->rowptr[i] + jj + train->rowval) -= rsum;  */
/*     } */
    gk_fset(train->ncols, 0.0, g_ibias); 
    break; 

/*     /\* A has item bias subtracted from each column, ONLY ON NNZS *\/ */
  case AOPT_IBIAS:

/*     for (int j = 0; j < train->ncols; j ++){ */
/*       int nj = train->colptr[j+1] - train->colptr[j];  */
/*       float csum = 0;  */
/*       for (int ii = 0; ii < nj; ii ++) */
/* 	csum += *(train->colptr[j] + ii + train->colval);  */
/*       /\* average across all nnzs! *\/ */
/*       csum /= (float)nj;  */
/*       for (int ii = 0; ii < nj; ii ++) */
/* 	*(train->colptr[j] + ii + train->colval) -= csum;  */
/*     } */
    if (ctrl->combineBR)
      gk_fset(train->nrows/2, 0.0, g_ubias); 
    else
      gk_fset(train->nrows,   0.0, g_ubias); 
    break; 

    /* tf-idf on matrix */
  case AOPT_TFIDF:
    ; 
    break; 

  }
}


/**************************************************************
 * recover full A matrix from previous run
 *************************************************************/
void recoverA(ctrl_t * ctrl, gk_csr_t * A, double * b, float * weights, int i){

  if (weights)
    gk_fset(A->nrows, 1.0, weights); 
  

  int nj = A->colptr[i+1] - A->colptr[i]; 
  for (int j = 0; j < nj; j ++){
    int ii = *(A->colptr[i] + j + A->colind); 
    

    /* row view */
    int nii = A->rowptr[ii+1] - A->rowptr[ii]; 
    int kk = -1; 
    for (int k = 0; k < nii; k ++){
      int i2 = *(A->rowptr[ii] + k + A->rowind); 
      if (i2 == i){
	kk = k; break; 
      }
    }
    assert(kk >= 0); 

    switch(ctrl->Aopt){
      /* use original A matrix */
    case AOPT_SPARSE:
    case AOPT_UBIAS:
      if (ctrl->normalizeA){
	*(A->colptr[i] + j + A->colval) = 1.0; 
	*(A->rowptr[ii] + kk + A->rowval) = 1.0; 
      }
      else{
	*(A->colptr[i] + j + A->colval) = b[ii]; // / 1.0 as default weight
	*(A->rowptr[ii] + kk + A->rowval) = b[ii]; 
      }
      break; 

      /* use the A matrix after row-wise user bias and column-wise item bias
	 has been subtracted. A is still sparse for now but will be manipulated
	 as dense in bcls solver. b must have been set dense. need to recover 
	 all necessary biases in A */
    case AOPT_FULL_BIAS:
      /* item bias subtracted */
    case AOPT_IBIAS:
      /*     L11: /\* corresponding to label L12 *\/ */
      if (g_ext_flag){
	if (ii < g_Aopt_nrows){
	  // / 1.0 as default weight
	  *(A->colptr[i] + j + A->colval) = b[ii] + g_ubias[ii] + g_ibias[i]; 
	  *(A->rowptr[ii] + kk + A->rowval) = *(A->colptr[i] + j + A->colval); 
	}
	else
	  ; 
      }else{
	// / 1.0 as default weight
	*(A->colptr[i] + j + A->colval) = b[ii] + g_ubias[ii] + g_ibias[i]; 
	*(A->rowptr[ii] + kk + A->rowval) = *(A->colptr[i] + j + A->colval); 
      }
      break; 

      /* something else */
    }
  
    /* always reset b */
    b[ii] = 0;  
  }
}

/**************************************************************
 * split A and b for current run 
 *************************************************************/
void splitAb(ctrl_t * ctrl, gk_csr_t * A, double * b, float * weights, int i){

  /* uniform but lower weights on missing data */
  /* on observed data, default weight as 1.0   */
  if (weights)
    gk_fset(A->nrows, ctrl->gamma1, weights);  

  int nj = A->colptr[i+1] - A->colptr[i]; 
  for (int j = 0; j < nj; j ++){
    int ii = *(A->colptr[i] + j + A->colind); 
    
    if (weights)
      weights[ii] = 1.0; 

    switch(ctrl->Aopt){
      
      /* use original A matrix, simple split */
    case AOPT_UBIAS:
    case AOPT_SPARSE:
      b[ii]  = *(A->colptr[i] + j + A->colval);  // * 1.0 as default weight
      if (ctrl->normalizeA)
	b[ii] = 1.0; // only for binary 
      break; 

      /* use the A matrix after row-wise user bias and column-wise item bias
	 has been subtracted. A is still sparse for now but will be manipulated
	 as dense in bcls solver. b needs to be dense right now */
    case AOPT_FULL_BIAS:
      /* item bias subtracted */
    case AOPT_IBIAS:
      /*     L12: /\* corresponding to label L11 *\/ */
      if (g_ext_flag){
	if (ii < g_Aopt_nrows)
	  // * 1.0 as default weight
	  b[ii]  = *(A->colptr[i] + j + A->colval) - g_ubias[ii] - g_ibias[i];  
	else
	  ; 
      }else{
	// * 1.0 as default weight
	b[ii]  = *(A->colptr[i] + j + A->colval) - g_ubias[ii] - g_ibias[i];  
      }
      break; 

      /* something else */

    }
    /* always reset the current column as 0 
       NOTE that "0" might not be the correct value, but 
       this column is not going to be touched (i.e., controlled 
       by g_acol) so it does not matter to put 0 here */
    *(A->colptr[i] + j + A->colval) = 0; 
    
    /* row view, used in CDL1 */
    int k = *(A->colptr[i] + j + A->colind);
    int nk = A->rowptr[k+1] - A->rowptr[k];
    for (int kk = 0; kk < nk; kk ++){
      int ii = *(A->rowptr[k] + kk + A->rowind);
      if (ii == i){
	*(A->rowptr[k] + kk + A->rowval) = 0;
	break;
      }
    }
  }



  /* do not like weights on the binary part */
  if (g_ext_flag && weights)
    gk_fset(g_Aopt_nrows, 1.0, weights + g_Aopt_nrows);

}

/**************************************************************
 * mark active rows
 *************************************************************/
void find_active_rows(ctrl_t * ctrl, int n, double * b, int * active_rows, int * nactive_rows){


  int nnz = 0; 
  int nr = 0; 

  switch(ctrl->wsim){

  case WSIM_SPARSE:
    *nactive_rows = n; 
    break; 

  case WSIM_DENSE:
    for (int i = 0; i < n; i ++){
      if (b[i] != 0){
	active_rows[i] = 1; 
	nnz ++; 
      }
      else
	active_rows[i] = 0; 
    }
    *nactive_rows = nnz; 
    break; 

  case WSIM_COMBINE:
    for (int i = 0; i < n; i ++){
      if (b[i] != 0){
	active_rows[i] = 1; 
	nnz ++; 
      }
      else
	active_rows[i] = 0; 
    } 
    srand(0); 
    /* randomly select same number of zeros */
    for (int i = 0; i < n; i ++){
      int r = gk_irandInRange(n); 
      if (!active_rows[r]){
	active_rows[r] = 1; 
	nr ++; 
	if (nr == nnz) break; 
      }
    }
    *nactive_rows = nr + nnz; 
    break; 
  }

}

/**************************************************************
 * scale the ratings
 *************************************************************/
void rscale(ctrl_t * ctrl, gk_csr_t * mat){

  float maxr = 1.0; 
  float alpha = ctrl->rscale_alpha; 

  switch(ctrl->rscale){
    /* exp scale all the ratings into 0-1 range */
  case RSCALE_RBF:
    maxr = exp((float)ctrl->nratings * alpha); 
    for (int i = 0; i < mat->rowptr[mat->nrows]; i ++)
      mat->rowval[i] = exp(mat->rowval[i]*alpha)/maxr; 
    break; 

    /* sqaure */
  case RSCALE_SQ:
    maxr = (float)ctrl->nratings; 
    for (int i = 0; i < mat->rowptr[mat->nrows]; i ++){
      mat->rowval[i] = 1.0/(maxr - 1.0)*(mat->rowval[i] - 1.0)*(mat->rowval[i] - 1.0) + 1.0; 
      mat->rowval[i] /= maxr; 
    }
    break; 

    /* linearly scale all the ratings into 0-1 range */
  case RSCALE_LINEAR:
    maxr = (float)ctrl->nratings; 
    for (int i = 0; i < mat->rowptr[mat->nrows]; i ++){
      if (mat->rowval[i] > maxr/2.0)
	mat->rowval[i] = 1.0; 
      else
	mat->rowval[i] = 0.5; 
    }
    break; 

    /* log into 0-1 range */
  case RSCALE_LOG:
    maxr = logf((float)ctrl->nratings + 0.001); 
    for (int i = 0; i < mat->rowptr[mat->nrows]; i ++)
      mat->rowval[i] = logf(mat->rowval[i] + 0.001)/maxr; 
    break;     
  }

}
