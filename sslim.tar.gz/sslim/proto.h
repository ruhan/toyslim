

#ifndef __PROTO_H__
#define __PROTO_H__

#include<struct.h>
//#include<CDL1lib.h>

/* bcls.c */
void bcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void normRA(ctrl_t * ctrl, gk_csr_t * R, int j); 

/* bcsol.c */
int CallBack( BCLS *ls, void *UsrWrk ); 
int CallBack_it( BCLS *ls, void *UsrWrk ); 
int pretty_printer( void *io_file, char *msg ); 
void *cs_free (void *p); 
void *cs_malloc (int n, size_t size);
void *cs_calloc (int n, size_t size); 
cs *cs_spfree (cs *A); 
cs *cs_spalloc (int m, int n, int nzmax, int values, int triplet); 
void dload( const int n, const double alpha, double x[] ); 
int Aprod( int mode, int m, int n, int nix, int ix[],
	   double x[], double y[], void *UsrWrk ); 
void  bcsol(ctrl_t * ctrl, gk_csr_t * AA, double * bb, double * x, worksp * Wrk, 
	    double * bl, double * bu, 
	    double beta, double * c); 
int Aprodd( int mode, int m, int n, int nix, int ix[],
	    double x[], double y[], void *UsrWrk ); 

/* cbcls.c */
void cbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test);

/* check.c */
void check_error(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void check_train_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 

/* cmd.c */
void parse_cmdline(ctrl_t *ctrl, int argc, char * argv[]); 

/* io.c */
mf_model_t * bprmf_load(ctrl_t * ctrl, char * ufile, char * ifile); 
void bprmf_save(ctrl_t * ctrl, mf_model_t * model, char * ufile, char * ifile); 
double ** load_matrix(char * file, int * nr, int * nc); 
void save_matrix(char * file, double ** mat, int nr, int nc); 
gk_csr_t * readConstraint(ctrl_t * ctrl, char * file); 
void save_vector(char * file, double * w, int n); 
double * load_vector(char * file, int * n); 


/* process.c */
void preprocess(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void recoverA(ctrl_t * ctrl, gk_csr_t * A, double * b, float * weights, int i); 
void splitAb(ctrl_t * ctrl, gk_csr_t * A, double * b, float * weights, int i); 
void find_active_rows(ctrl_t * ctrl, int n, double * b, int * active_rows, int * nactive_rows); 
void rscale(ctrl_t * ctrl, gk_csr_t * mat); 


/* scbcls.c */
void scbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void alter_scbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * sim, 
		  double alpha, double beta1, double beta2, double lambda); 
gk_csr_t * csr_stack(gk_csr_t * A, gk_csr_t * B); 
gk_csr_t * csr_make_identity(int nr); 
void external_bcls(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * R, 
		   double beta, double lambda); 


/* sbcls.c */
void sbcls(ctrl_t * ctrl, gk_csr_t * A, double * b, double * w, worksp * Wrk, 
	   double * bl, double * bu, 
	   double beta1, double * c1); 

/* sibcls2.c */
void sibcls2(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void sibcls2_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void sibcls2_train(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * ft, gk_csr_t * R, gk_csr_t * Z, 
		   double beta, double lambda); 
void sibcls2_generate_c(ctrl_t * ctrl, gk_csr_t * ft, double lambda, int i,
			double * c, int n); 
void sibcls2_generate_R(ctrl_t * ctrl, gk_csr_t * R, float * R_rowval, float * R_colval, 
			gk_csr_t * Y, gk_csr_t * ft, 
			float * yi, float * fti, int i, int flag); 
void sibcls2_mv2binary(gk_csr_t * R, float * R_rowval, float * R_colval, int flag); 
void sibcls2_recover_R(ctrl_t * ctrl, gk_csr_t * R, float * R_rowval, float * R_colval, 
		       gk_csr_t * Y, gk_csr_t * ft, 
		       float * yi, float * fti, int i); 
void sibcls2_generate_constraint(ctrl_t * ctrl, int * acol, int n, 
				 gk_csr_t* ft, int i); 


/* sibcls.c */
void sibcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void sibcls_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
void sibcls_train(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * ft, gk_csr_t * R, 
		  double beta, double lambda); 
gk_csr_t * sibcls_aggregate(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * ft); 
void sibcls_generate_bounds(ctrl_t * ctrl, gk_csr_t * ft, int i, 
			    double * bl, double * bu, int n); 
void sibcls_generate_c(ctrl_t * ctrl, gk_csr_t * ft, double lambda, 
		       double * c, int n); 

/* suggest.c */
void suggest(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 
double * suggest_test2(ctrl_t * ctrl, suggest_model_t * model, 
		       gk_csr_t * train, gk_csr_t * train2, gk_csr_t * test); 
int suggest_predict2(ctrl_t * ctrl, suggest_model_t * model, int * idx, 
		     gk_csr_t * train, gk_csr_t * train2, int u, int flag, gk_dkv_t ** rcmd); 
double * suggest_test(ctrl_t * ctrl, suggest_model_t * model, 
		      gk_csr_t * train, gk_csr_t * test); 
double suggest_predict(ctrl_t * ctrl, suggest_model_t * model, 
		       gk_csr_t * train, int u, int i); 
void check_support(ctrl_t * ctrl, suggest_model_t * model, gk_csr_t * train, 
		   int useri, int itemj); 


/* topn.c */
int update_topn(gk_dkv_t * list, int topn, int i, double key, gk_idx_t val); 


/* util.c */
void extend_binary(ctrl_t * ctrl, gk_csr_t * mat); 
double rand1(); 
double gasdev2(long * idum); 
void mv2binary(gk_csr_t * mat); 
gk_csr_t * csr_sampling_rows(gk_csr_t * mat, float rate); 
void csr_RemoveDiag(gk_csr_t * mat); 
gk_csr_t * csr_multiply(gk_csr_t * A, gk_csr_t * B); 
float * csr_mean(gk_csr_t * mat, int what); 
void csr_ExtractColumnsRows(gk_csr_t * mat, int i, float * vec, int what); 
void csr_multiplyScalar(gk_csr_t * A, float a); 
void csr_RandomSparseInit(gk_csr_t ** A, int nrows, int ncols, 
			  float srate, float mean, float stdev); 
void csr_transpose(gk_csr_t * A); 
void csr_Write(gk_csr_t *mat, char *filename, char * mode, 
	       int format, int writevals, int numbering); 
void findCol(gk_csr_t * X, int j, double * col); 
ctrl_t * create_ctrl(); 
void free_ctrl(ctrl_t * ctrl); 
void start_timer(ctimer_t * ctimer); 
void end_timer(ctimer_t * ctimer); 
void display_timer(ctimer_t * ctimer, char * msg); 
int count_nnz(double * array, int narray); 
void find_topk(double * w, int n, int topk, double * map, int * topk2); 
void getConstraint(ctrl_t * ctrl, gk_csr_t * constraint, int i, double * w); 
double * get_initW(char * file, int n); 


#endif
