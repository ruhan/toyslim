#include<bprmf.h>

/* extern __thread int * g_acol;  */

float * g_A_colval = NULL; 

/*******************************************************************
 * top-k bcls
 *******************************************************************/
void sbcls(ctrl_t * ctrl, gk_csr_t * A, double * b, double * w, worksp * Wrk, 
	   double * bl, double * bu, 
	   double beta1, double * c1){

  int nnz = *(A->colptr + A->ncols); 
  int * acol = Wrk->acol; 

  /* count nnz */
  int kk = count_nnz(w, A->ncols); 
	
  /* find topk nnz */
  int topk = 0; 
  /* find the indices of topk entries, meanwhile w is over-written as the topk locations */
  find_topk(w, A->ncols, gk_min(ctrl->k, kk), w, &topk);  
  /*   printf("Sparsity control: shrink w from nnz %d to %d..\n", kk, topk);  */

  /* back up original values, this is done only once */
  if (g_A_colval == NULL){
    g_A_colval = gk_malloc(sizeof(float)*nnz, "malloc A_colval"); 
    memcpy((void *)g_A_colval, (void *)A->colval, sizeof(float)*nnz); 
  }

  /* remove all A nnz values, this will not affect the column under consideration */
  gk_fset(nnz, 0, A->colval); 
  /* set all columns as inactive */
  gk_iset(A->ncols, 0, acol); 
  /* recover all topk columns in A */
  for (int i = 0; i < topk; i ++){
    int j = (int)w[i]; 
    /* activate this column */
    acol[j] = 1; 
    int nj = A->colptr[j+1] - A->colptr[j];
    for (int k = 0; k < nj; k ++){
      /* get the orignal values back */
      *(A->colptr[j] + k + A->colval) = *(A->colptr[j] + k + g_A_colval); 
    }
  }

  /* BCLS */
  gk_dset(A->ncols, 0, w); 
  bcsol(ctrl, A, b, w, Wrk, bl, bu, beta1, c1); 
    
  /* recover full A, specific to binary A, this will over-write the column of b, 
     but will not matter */
   memcpy((void *)A->colval, (void *)g_A_colval, sizeof(float)*nnz); 
  /* activate all columns */
  gk_iset(A->ncols, 1, acol); 


}
      
