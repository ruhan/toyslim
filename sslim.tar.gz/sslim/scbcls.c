#include<bprmf.h>


extern int g_max_bcls_niters ; 
/***********************************************************************
 * seperate collective BCLS
 * min 1/2 || R - R S_r ||_2^2 + \alpha/2 || D - D S_d|| 
 *       + \lambda ( || S_r ||_1 + || S_d ||_1 ) 
 *       + \beta_1/2 || S_r - S_d ||_2^2 
 *       + \beta_2/2 ( || S_r ||_2^2 + || S_d ||_2^2 )
 ***********************************************************************/
void scbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  /* up to the user to supply train/sim/out_file so as for different alternations */
  /* user-item train + doc-sim sim  => fix doc-sim S_d and solve S_r              */
  /* doc-item train  + item-sim sim => fix item-sim S_r and solve S_d             */
  /* for the initial step, S_r/S_d from Suggest cos item similarity               */
  /* test using suggest option                                                    */
  gk_csr_t * sim = NULL; 
  if (ctrl->similarity_file != NULL){
    sim = gk_csr_Read(ctrl->similarity_file, GK_CSR_FMT_CSR, 1, 1);
    sim->ncols = gk_max(sim->nrows, sim->ncols); 
    csr_transpose(sim); /* the sim matrix from bcls is always in transpose form */
  }else{
    csr_RandomSparseInit(&sim, train->ncols, train->ncols, 
			 ctrl->srate, ctrl->init_mean, ctrl->init_stdev);  
  }

  if (train->ncols < sim->ncols){
    train->ncols = sim->ncols; 
    gk_csr_CreateIndex(train, GK_CSR_COL); 
  }

  alter_scbcls(ctrl, train, sim, ctrl->alpha, ctrl->beta1, ctrl->beta2, ctrl->lambda); //

  gk_csr_Free(&sim); 

}

/***********************************************************************
 * seperate collective BCLS
 * fix one S, learn the other
 * min \alpha/2 || R - R S ||_2^2 
 *       + \lambda || S ||_1 
 *       + \beta_1/2 || S - Sim ||_2^2 + \beta_2/2 || S ||_2^2 
 ***********************************************************************/
void alter_scbcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * sim, 
		  double alpha, double beta1, double beta2, double lambda){

/*   int nr = train->nrows;  */
  int nc = train->ncols; 
  /* extend the train matrix by an identity matrix of size nc by nc */
  gk_csr_t * identity = csr_make_identity(nc); 
  /* sqrt(beta1 / alpha) * I */
  printf("Stacking I * %.5f...\n", sqrt(beta1/alpha)); 
  csr_multiplyScalar(identity, sqrt(beta1/alpha)); 
  gk_csr_CreateIndex(identity, GK_CSR_COL); 
  /* [ train; sqrt(beta1/alpha) * I] */
  gk_csr_t * A = csr_stack(train, identity); 

  /* sqrt(beta1 / alpha) * sim */
  printf("Stacking SIM * %.5f...\n", sqrt(beta1/alpha)); 
  csr_multiplyScalar(sim, sqrt(beta1/alpha)); 
  /* [ train; sqrt(beta1/alpha) * I] */
  gk_csr_t * Y = csr_stack(train, sim); 

/*   /\* weigh the sim matrix *\/ */
/*   for (int i = train->rowptr[train->nrows]; i < A->rowptr[A->nrows]; i ++){ */
/*     A->rowval[i] *= sqrt(alpha); */
/*     Y->rowval[i] *= sqrt(alpha); /\* alpha is the regularizer on l2 of diff *\/  */
/*   } */
  
  /* column view */
  gk_csr_CreateIndex(A, GK_CSR_COL);
  gk_csr_CreateIndex(Y, GK_CSR_COL); 

  /* solve the problem and save it into the output file  */
  external_bcls(ctrl, Y, A, beta2/alpha, lambda/alpha);
   

  /* clean  up */
  gk_csr_Free(&A); 
  gk_csr_Free(&Y); 
  gk_csr_Free(&identity); 

}

/***********************************************************************
 * stack two matrices
 ***********************************************************************/
gk_csr_t * csr_stack(gk_csr_t * A, gk_csr_t * B){

  if (A->ncols != B->ncols)
    printf("A->ncols = %d, B->ncols = %d\n", A->ncols, B->ncols); 
  assert(A->ncols == B->ncols); 
  
  int nnzA = *(A->rowptr + A->nrows); 
  int nnzB = *(B->rowptr + B->nrows); 

  gk_csr_t * C = gk_malloc(sizeof(gk_csr_t), "malloc C"); 
  C->nrows = A->nrows + B->nrows; 
  C->ncols = A->ncols; 

  /* row view */
  C->rowptr = gk_malloc(sizeof(int) * (C->nrows + 1), "malloc C->rowptr"); 
  C->rowind = gk_malloc(sizeof(int) * (nnzA + nnzB),  "malloc C->rowind"); 
  C->rowval = gk_malloc(sizeof(float)*(nnzA + nnzB),  "malloc C->rowval"); 
  /* copy everything in A to C */
  memcpy((void *)C->rowptr, (void *)A->rowptr, sizeof(int)*(A->nrows + 1)); 
  memcpy((void *)C->rowind, (void *)A->rowind, sizeof(int)*nnzA); 
  memcpy((void *)C->rowval, (void *)A->rowval, sizeof(float)*nnzA); 
  /* copy everything in B to C */
  memcpy((void *)(C->rowptr + A->nrows + 1), (void *)(B->rowptr + 1), sizeof(int)*B->nrows );  ////
  memcpy((void *)(C->rowind + nnzA), (void *)B->rowind, sizeof(int)*nnzB); 
  memcpy((void *)(C->rowval + nnzA), (void *)B->rowval, sizeof(float)*nnzB); 
  /* stack rows */
  for (int i = 1; i < B->nrows + 1; i ++)
    *(C->rowptr + A->nrows + i ) += nnzA; 
  
  /* column view */
  C->colptr = NULL; 
  C->colind = NULL; 
  C->colval = NULL; 

  return C; 

}


/***********************************************************************
 * make an identity matrix
 ***********************************************************************/
gk_csr_t * csr_make_identity(int nr){

  gk_csr_t * identity = gk_malloc(sizeof(gk_csr_t), "malloc identity"); 
  identity->nrows = identity->ncols = nr; 
  identity->colptr = NULL; 
  identity->colind = NULL; 
  identity->colval = NULL;   

  identity->rowptr = gk_malloc(sizeof(int)*(nr + 1), "malloc rowptr"); 
  for (int i = 0; i < nr + 1; i ++)
    identity->rowptr[i] = i; 
  identity->rowind = gk_malloc(sizeof(int)*nr, "malloc rowind"); 
  for (int i = 0; i < nr; i ++)
    identity->rowind[i] = i; 
  identity->rowval = gk_malloc(sizeof(float)*nr, "malloc rowval"); 
  for (int i = 0; i < nr; i ++)
    identity->rowval[i] = 1.0; 
  
  return identity; 

}

/****************************************************************
 * Bound Constrained Least Square || Y - R x ||  + reg
 ****************************************************************/
void external_bcls(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * R, 
		   double beta, double lambda){


  g_max_bcls_niters = ctrl->max_bcls_niters;

  /* constants used across all problems */
  int nr = R->nrows; 
  int nc = R->ncols;



  /* lower/upper bound */
  double * bl = gk_malloc(sizeof(double)*nc, "malloc bl"); 
  gk_dset(nc, ctrl->bl, bl); 
  double * bu = gk_malloc(sizeof(double)*nc, "malloc bu"); 
  gk_dset(nc, ctrl->bu, bu); 
  /* RHS vector for all problems */
  double * b = gk_malloc(sizeof(double)*nr, "malloc b"); 
  gk_dset(nr, 0, b); 
  double * b1 = gk_malloc(sizeof(double)*nr, "malloc b1"); 
  gk_dset(nr, 0, b1); 
  /* c, linear vector */
  double * c = gk_malloc(sizeof(double)*nc, "malloc c"); 
  gk_dset(nc, lambda, c); 
  /* solution vector */
  double * w = gk_malloc(sizeof(double)*nc, "malloc w"); 
  gk_dset(nc, 0, w); ////
  /* the A matrix */
  gk_csr_t * A = R; 
  /* temp A */
  cs * csA = gk_malloc(sizeof(cs), "malloc csA");
  /* Workspace for BCLS */
  worksp * Wrk = gk_malloc(sizeof(worksp), "malloc Wrk"); 
  Wrk->A = csA;
  csA->p = A->colptr; /* NOTE: pointer assignment! */
  csA->i = A->colind;
  csA->x = A->colval;
  csA->m = A->nrows; /* NOTE: these params will not change across problems */
  csA->n = A->ncols;
  csA->nzmax = *(A->rowptr + A->nrows); 
  csA->nz = -1; /* column-view, not triplet */
  /* pointer to the active columns in A */
  int * acol = gk_malloc(sizeof(int)*nc, "malloc g_acol"); 
  gk_iset(nc, 1, acol); 
  Wrk->acol = acol; 
  

  /* output data */
  int bsize = 1000; /* at most 1000 cols */
  gk_csr_t * mat = gk_csr_Create(); 
  mat->nrows = 0; 
  mat->ncols = R->ncols; 
  mat->rowptr = gk_malloc(sizeof(int)*(nc+1), "malloc mat->rowptr"); 
  mat->rowptr[0] = 0; 
  mat->rowind = gk_malloc(sizeof(int)*nc*bsize, "malloc mat->rowind"); 
  gk_iset(nc*bsize, 0, mat->rowind); 
  mat->rowval = gk_malloc(sizeof(float)*nc*bsize, "malloc mat->rowval"); 
  gk_fset(nc*bsize, 0, mat->rowval); 


  /* constraint data */
  gk_csr_t * constraint = NULL; 
  if (ctrl->constraint)
    constraint = readConstraint(ctrl, ctrl->constraint_file); 



  int starti = ctrl->starti; 
  int endi   = ctrl->endi; 
  if (starti < 0) starti = 0; 
  if (endi < 0) endi = nc; ///
  float * weights = gk_malloc(sizeof(float)*nr, "malloc weights"); 
  gk_fset(nr, 1.0, weights); /* no weight */
  Wrk->weights = weights; /* pointer assignment */


  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  start_timer(timer); 

  /* # of skipped columns */
  int nskipped = 0; 

  /* go through all columns  */
  for (int i = starti; i < endi; i ++){

    
    /* printf("column %8d: ", i);  */
    if ((i - starti) % 100 == 0){
      printf(".%d", i);  fflush(stdout); 
    }

    /* this column is totally empty */
    if (R->colptr[i+1] - R->colptr[i] == 0){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      end_timer(timer);
      display_timer(timer, "empty iter ");
      nskipped ++; 
      continue;
    }
    int allzeros = 1;
    for (int j = R->colptr[i]; j < R->colptr[i+1]; j ++){
      if (R->colval[j] != 0) {
	allzeros = 0; break; 
      }
    }
    if (allzeros == 1){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      end_timer(timer);
      display_timer(timer, "empty iter ");
      nskipped ++; 
      continue;    
    }



    /***********************************************************************/
    /* set up all variables needed                                         */
    /***********************************************************************/

    /* recover the full A matrix from last run */
    if (i > starti){
      /* recover last column in A */
      recoverA(ctrl, A, b1, weights, i - 1 - nskipped);  
      /* column from last run becomes active in this run */
      acol[i-1-nskipped] = 1; 
    }

    /* generate A and b needed in this run, and corresponding weights */
    gk_dset(nr, 0, b1); 
    splitAb(ctrl, A, b1, weights, i); 
    gk_dset(nr, 0, b); 
    findCol(Y, i, b); 
    /* mark inactive column of this run */
    acol[i] = 0; 
    


    /***********************************************************************/
    /* solve the problem                                                   */
    /***********************************************************************/
    if (!ctrl->constraint){
      bcsol(ctrl, A, b, w, Wrk, bl, bu, beta, c); 
    }else{
      getConstraint(ctrl, constraint, i, w);
      sbcls(ctrl, A, b, w, Wrk, bl, bu, beta, c);
    }
    



    /***********************************************************************/
    /* periodically save the results                                       */
    /***********************************************************************/

    /* many enough, dump the data */
    if (mat->nrows >= 1000){
      printf("Dumping data...\n"); 
      csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 
      mat->nrows = 0; 
    }
    
    /* fill out the matrix */
    *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows); 
    for (int j = 0, k = 0; j < nc; j ++){
      /*       if ((ctrl->ibias)? (w[j]): (w[j] > 1e-10)){ */
      if (w[j] > 1e-5){
	*(mat->rowind + mat->rowptr[mat->nrows] + k) = j; 
	*(mat->rowval + mat->rowptr[mat->nrows] + k) = w[j]; 
	(*(mat->rowptr + mat->nrows + 1)) ++; 
	k ++; 
      }
    }
    mat->nrows ++; 

    gk_dset(nc, 0, w); 
    
    nskipped = 0; 

  } /* end of starti - endi */
  printf("\n"); fflush(stdout); 

  /* dump left-overs */
  printf("Dumping data...\n"); 
  csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 


  end_timer(timer); 
  display_timer(timer, "External BCLS"); 


  /***********************************************************************/
  /* finish up                                                           */ 
  /***********************************************************************/
  recoverA(ctrl, R, b1, weights, endi - 1); 
  gk_free((void **)&w, LTERM); 
  gk_free((void **)&bl, &bu, &b, &c, &b1, LTERM); 
  gk_free((void **)&csA, LTERM);   gk_free((void **)&Wrk, LTERM); 
/*   gk_free((void **)&g_acol, LTERM);    */
  gk_free((void **)&acol, LTERM);   
  gk_free((void **)&weights, LTERM); 
  gk_csr_Free(&mat); 
  gk_free((void **)&timer, LTERM); 
  gk_csr_Free(&constraint); 

}
