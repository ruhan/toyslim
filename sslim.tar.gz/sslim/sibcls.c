#include<bprmf.h>

extern int g_max_bcls_niters ; 

/*****************************************************************
 * min_w 1/2| M - MDW| + beta/2|W|_2 + lambda|DW|_1
 * st. W >= 0
 *     diag(DW) = 0
 * 
 * M: user-item collaborative matrix
 * D: item-sideinfo matrix
 * assume side info is on items
 ******************************************************************/
void sibcls(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){
  
  /* item feature file, item-feature row view */
  gk_csr_t * ft = gk_csr_Read(ctrl->ft_file, GK_CSR_FMT_CSR, 1, 1); 
/*   mv2binary(ft); /// tmp */
  gk_csr_CreateIndex(ft, GK_CSR_COL); 
  /* column sum, use in solving the problem */
  gk_csr_ComputeSums(ft, GK_CSR_COL); 

/*   /\* use item side information to represent users *\/ */
/*   gk_csr_t * train2 = csr_multiply(train, ft); */
/*   /\* convert multi-value matrix to binary *\/ */
/*   if (ctrl->mult2binary) */
/*     mv2binary(train2); */
/*   /\*   gk_csr_Write(train2, "./train2.mat", GK_CSR_FMT_CSR, 1, 1); *\/ */
/*   gk_csr_CreateIndex(train2, GK_CSR_COL); */

  /* R = user-item * item-feature */
  gk_csr_t * train2 = sibcls_aggregate(ctrl, train, ft);

  /* solve the problem */
  sibcls_train(ctrl, train, ft, train2, ctrl->beta, ctrl->lambda);

/*   /\* test *\/ */
/*   gk_csr_t * w = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); */
/*   csr_transpose(w); */
/*   gk_csr_t * W = csr_multiply(ft, w); */
/*   gk_csr_Write(W, "./train2.mat", GK_CSR_FMT_CSR, 1, 1); */
/*   gk_csr_Free(&w); */
/*   gk_csr_Free(&W); */
  

  /* clean up */
  gk_free((void **)&ft->csums, LTERM);
  gk_csr_Free(&ft); 
  gk_csr_Free(&train2); 


}


/*******************************************************************
 * test using si-bcls
 *******************************************************************/
void sibcls_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  /* item feature file, item-feature row view */
  gk_csr_t * ft = gk_csr_Read(ctrl->ft_file, GK_CSR_FMT_CSR, 1, 1); 
/*   mv2binary(ft);  ///tmp */
  gk_csr_CreateIndex(ft, GK_CSR_COL); 

  /* use item side information to represent users */
/*   gk_csr_t * train2 = csr_multiply(train, ft);   */
/*   /\* convert multi-value matrix to binary *\/ */
/* /\*   mv2binary(train2);  *\/ */
/*   gk_csr_CreateIndex(train2, GK_CSR_COL);  */
  gk_csr_t * train2 = sibcls_aggregate(ctrl, train, ft); 

  /* predict as in simple bcls */
  suggest_model_t * model = NULL; 

  /* 
     suggest model is nothing but an |I|-by-|I| item-item similarity matrix, 
     in which each value at position (i, j) says if item i is within 
     item j's neighborbood (i.e., nnz values), and value determines "similarity"
     Note that it is the output directly from QP, which is the transpose of 
     W in AW ~ A and the transpose of SUGGEST itemcos model, and this is the
     default model setting
  */
  model = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); 
  assert(model->ncols <= ft->ncols);  
  if (model->ncols < ft->ncols)
    model->ncols = ft->ncols; 

  /* sanity check */
  printf("model->nrows = %d, model->ncols = %d\n", model->nrows, model->ncols); 
  /* if (model->nrows != model->ncols) printf("model->nrows = %d, model->ncols = %d\n", model->nrows, model->ncols);  */
  /* assert(model->nrows == model->ncols);  */
  double * eval = suggest_test2(ctrl, model, train2, train, test); 


  /* print the results */
  for (int j = 0; j < ctrl->nratings; j ++)
    printf("R%3d HR = %.5f ARHR = %.5f cumulative HR = %.5f ARHR = %.5f\n", 
	   j+1, eval[j*4], eval[j*4+1], eval[j*4+2], eval[j*4+3]); 


  /* clean up */
  gk_csr_Free(&ft); 
  gk_csr_Free(&train2); 
  gk_csr_Free(&model); 
  gk_free((void **)&eval, LTERM); 

}



/****************************************************************
 * Bound Constrained Least Square || Y - R x ||  + reg
 ****************************************************************/
void sibcls_train(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * ft, gk_csr_t * R, 
		  double beta, double lambda){

  /* global variable to control bcls iterations */
  g_max_bcls_niters = ctrl->max_bcls_niters;

/*   /\* R = user-item * item-feature *\/ */
/*   gk_csr_t * R = sibcls_aggregate(ctrl, Y, ft);  */

  /* constants used across all problems */
  int nr = R->nrows; 
  int nc = R->ncols;


  /* lower/upper bound, hold the place for now */
  /* the bounds should be different for different columns of x */
  double * bl = gk_malloc(sizeof(double)*nc, "malloc bl");
  gk_dset(nc, ctrl->bl, bl);
  double * bu = gk_malloc(sizeof(double)*nc, "malloc bu");
  gk_dset(nc, ctrl->bu, bu);




  /* RHS vector for all problems */
  double * b = gk_malloc(sizeof(double)*nr, "malloc b"); 
  gk_dset(nr, 0, b); 
  double * b1 = gk_malloc(sizeof(double)*nr, "malloc b1"); 
  gk_dset(nr, 0, b1); 

  /* c, linear vector */
  double * c = gk_malloc(sizeof(double)*nc, "malloc c"); 
  gk_dset(nc, lambda, c); 
  sibcls_generate_c(ctrl, ft, lambda, c, nc); 

  /* solution vector */
  double * w = gk_malloc(sizeof(double)*nc, "malloc w"); 
  gk_dset(nc, 0, w); ////
  /* the A matrix */
  gk_csr_t * A = R; 
  /* temp A */
  cs * csA = gk_malloc(sizeof(cs), "malloc csA");
  /* Workspace for BCLS */
  worksp * Wrk = gk_malloc(sizeof(worksp), "malloc Wrk"); 
  Wrk->A = csA;
  csA->p = A->colptr; /* NOTE: pointer assignment! */
  csA->i = A->colind;
  csA->x = A->colval;
  csA->m = A->nrows; /* NOTE: these params will not change across problems */
  csA->n = A->ncols;
  csA->nzmax = *(A->rowptr + A->nrows); 
  csA->nz = -1; /* column-view, not triplet */
  /* pointer to the active columns in A */
  int * acol = gk_malloc(sizeof(int)*nc, "malloc g_acol"); 
  gk_iset(nc, 1, acol); 
  Wrk->acol = acol; 
  

  /* output data */
  int bsize = 1000; /* at most 1000 cols */
  gk_csr_t * mat = gk_csr_Create(); 
  mat->nrows = 0; 
  mat->ncols = R->ncols; 
  mat->rowptr = gk_malloc(sizeof(int)*(Y->ncols+1), "malloc mat->rowptr"); 
  mat->rowptr[0] = 0; 
  mat->rowind = gk_malloc(sizeof(int)*mat->ncols*bsize, "malloc mat->rowind"); 
  gk_iset(mat->ncols*bsize, 0, mat->rowind); 
  mat->rowval = gk_malloc(sizeof(float)*mat->ncols*bsize, "malloc mat->rowval"); 
  gk_fset(mat->ncols*bsize, 0, mat->rowval); 



  int starti = ctrl->starti; 
  int endi   = ctrl->endi; 
  if (starti < 0) starti = 0; 
  if (endi < 0) endi = Y->ncols; ///
  float * weights = gk_malloc(sizeof(float)*nr, "malloc weights"); 
  gk_fset(nr, 1.0, weights); /* no weight */
  Wrk->weights = weights; /* pointer assignment */


  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  start_timer(timer); 


  /* go through all columns  */
  for (int i = starti; i < endi; i ++){

    
    /* printf("column %8d: ", i);  */
    if ((i - starti) % 100 == 0){
      printf(".%d", i);  fflush(stdout); 
    }

    /* this column is totally empty */
    if (Y->colptr[i+1] - Y->colptr[i] == 0){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      continue;
    }

    /***********************************************************************/
    /* set up all variables needed                                         */
    /***********************************************************************/

    /* generate all the constants for this run */
    /* the bounds for x */
    sibcls_generate_bounds(ctrl, ft, i, bl, bu, nc);
    /* the dependent variable */
    gk_dset(nr, 0, b); 
    findCol(Y, i, b); 
    


    /***********************************************************************/
    /* solve the problem                                                   */
    /***********************************************************************/
    bcsol(ctrl, A, b, w, Wrk, bl, bu, beta, c); 
    



    /***********************************************************************/
    /* periodically save the results                                       */
    /***********************************************************************/

    /* many enough, dump the data */
    if (mat->nrows >= 1000){
      printf("Dumping data...\n"); 
      csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 
      mat->nrows = 0; 
    }
    
    /* fill out the matrix */
    *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows); 
    for (int j = 0, k = 0; j < nc; j ++){
      /*       if ((ctrl->ibias)? (w[j]): (w[j] > 1e-10)){ */
      if (w[j] > 1e-5){
	*(mat->rowind + mat->rowptr[mat->nrows] + k) = j; 
	*(mat->rowval + mat->rowptr[mat->nrows] + k) = w[j]; 
	(*(mat->rowptr + mat->nrows + 1)) ++; 
	k ++; 
      }
    }
    mat->nrows ++; 

    /* reset */
    gk_dset(nc, 0, w); 


  } /* end of starti - endi */
  printf("\n"); fflush(stdout); 

  /* dump left-overs */
  printf("Dumping data...\n"); 
  csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 


  end_timer(timer); 
  display_timer(timer, "External BCLS"); 


  /***********************************************************************/
  /* finish up                                                           */ 
  /***********************************************************************/
  gk_free((void **)&w, LTERM); 
  gk_free((void **)&bl, &bu, &b, &c, &b1, LTERM); 
  gk_free((void **)&csA, LTERM);   gk_free((void **)&Wrk, LTERM); 
  gk_free((void **)&acol, LTERM);
  gk_free((void **)&weights, LTERM); 
  gk_csr_Free(&mat); 
  gk_free((void **)&timer, LTERM); 
/*   gk_csr_Free(&R);  */

}

/*******************************************************************
 * test using si-bcls
 *******************************************************************/
gk_csr_t * sibcls_aggregate(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * ft){

  /* use item side information to represent users */
  gk_csr_t * train2 = csr_multiply(train, ft);
  /* convert multi-value matrix to binary */
  if (ctrl->mult2binary)
    mv2binary(train2);
  /*   gk_csr_Write(train2, "./train2.mat", GK_CSR_FMT_CSR, 1, 1); */
  gk_csr_CreateIndex(train2, GK_CSR_COL);
  
  return train2; 

}

/*******************************************************************
 * calculate the bounds
 *******************************************************************/
void sibcls_generate_bounds(ctrl_t * ctrl, gk_csr_t * ft, int i, 
			    double * bl, double * bu, int n){

  /* default */
  gk_dset(n, ctrl->bl, bl); 
  gk_dset(n, ctrl->bu, bu); 

  int nnz = ft->rowptr[i+1] - ft->rowptr[i]; 
  for (int j = 0; j < nnz; j ++){
    /* column idx for a non-zero value */
    int jj = *(ft->rowptr[i] + j + ft->rowind); 
    /* double check, just in case */
    if (*(ft->rowptr[i] + j + ft->rowval) != 0)
      /* fixed variables, they must have 0 value  */
      bu[jj] = bl[jj] = 0; 
  }

}


/*******************************************************************
 * calculate c
 *******************************************************************/
void sibcls_generate_c(ctrl_t * ctrl, gk_csr_t * ft, double lambda, 
		       double * c, int n){

  for (int i = 0; i < n; i ++){
    c[i] = lambda * ft->csums[i]; 
  }

}
