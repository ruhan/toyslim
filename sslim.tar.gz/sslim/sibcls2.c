#include<bprmf.h>

extern int g_max_bcls_niters ; 

/*****************************************************************
 * min_w 1/2| M - M (DW - X) | + beta/2|W|_2 + lambda|DW-X|_1
 * st. W >= 0
 * 
 * M: user-item collaborative matrix
 * D: item-sideinfo matrix
 * X: eye(diag(DW))
 * assume side info is on items
 ******************************************************************/
void sibcls2(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  ctrl->mult2binary = 0; //////////////// for now

  
  /* item feature file, item-feature row view */
  gk_csr_t * ft = gk_csr_Read(ctrl->ft_file, GK_CSR_FMT_CSR, 1, 1); 
/*   mv2binary(ft); /// tmp */
  gk_csr_CreateIndex(ft, GK_CSR_COL); 
  /* column sum, use in solving the problem */
  gk_csr_ComputeSums(ft, GK_CSR_COL); 


  /* in case the train data is sparsified */
  if (train->ncols < ft->nrows){
    train->ncols = ft->nrows;
    gk_csr_CreateIndex(train, GK_CSR_COL);
  }

/*   /\* use item side information to represent users *\/ */
/*   gk_csr_t * train2 = csr_multiply(train, ft); */
/*   /\* convert multi-value matrix to binary *\/ */
/*   if (ctrl->mult2binary) */
/*     mv2binary(train2); */
/*   /\*   gk_csr_Write(train2, "./train2.mat", GK_CSR_FMT_CSR, 1, 1); *\/ */
/*   gk_csr_CreateIndex(train2, GK_CSR_COL); */

  /* R = user-item * item-feature */
  /* R is never converted to binary here, but might be later in each iteration */
  gk_csr_t * train2 = sibcls_aggregate(ctrl, train, ft);
  
  /* solve the problem */
  sibcls2_train(ctrl, train, ft, train2, train, ctrl->beta, ctrl->lambda);

/*   /\* test *\/ */
/*   gk_csr_t * w = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); */
/*   csr_transpose(w); */
/*   gk_csr_t * W = csr_multiply(ft, w); */
/*   gk_csr_Write(W, "./train2.mat", GK_CSR_FMT_CSR, 1, 1); */
/*   gk_csr_Free(&w); */
/*   gk_csr_Free(&W); */
  

  /* clean up */
  gk_free((void **)&ft->csums, LTERM);
  gk_csr_Free(&ft); 
  gk_csr_Free(&train2); 


}

/*******************************************************************
 * test using si-bcls
 *******************************************************************/
void sibcls2_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  /* item feature file, item-feature row view */
  gk_csr_t * ft = gk_csr_Read(ctrl->ft_file, GK_CSR_FMT_CSR, 1, 1); 
/*   mv2binary(ft);  ///tmp */
  gk_csr_CreateIndex(ft, GK_CSR_COL); 

  /* W  */
  gk_csr_t * model = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); 
  assert(model->ncols <= ft->ncols); 
  model->ncols = ft->ncols;
  csr_transpose(model); 
  /* DW */
  gk_csr_t * model2 = sibcls_aggregate(ctrl, ft, model); 
  assert(model2->nrows == model2->ncols); 
  csr_transpose(model2); 
  /* DW - X, in transpose */
  csr_RemoveDiag(model2); 


  /* evaluation */
  double * eval = suggest_test2(ctrl, model2, train, train, test); 


  /* print the results */
  for (int j = 0; j < ctrl->nratings; j ++)
    printf("R%3d HR = %.5f ARHR = %.5f cumulative HR = %.5f ARHR = %.5f\n", 
	   j+1, eval[j*4], eval[j*4+1], eval[j*4+2], eval[j*4+3]); 


  /* clean up */
  gk_csr_Free(&ft); 
  gk_csr_Free(&model); 
  gk_csr_Free(&model2); 
  gk_free((void **)&eval, LTERM); 

}


/****************************************************************
 * Bound Constrained Least Square || Y - R x ||  + reg
 * R = Z * ft
 ****************************************************************/
void sibcls2_train(ctrl_t * ctrl, gk_csr_t * Y, gk_csr_t * ft, gk_csr_t * R, gk_csr_t * Z, 
		   double beta, double lambda){

  /* global variable to control bcls iterations */
  g_max_bcls_niters = ctrl->max_bcls_niters;


/*   /\* R = user-item * item-feature *\/ */
/*   gk_csr_t * R = sibcls_aggregate(ctrl, Y, ft);  */

  /* constants used across all problems */
  int nr = R->nrows; 
  int nc = R->ncols;


  /* lower/upper bound, hold the place for now */
  /* the bounds should be same for different columns of x */
  double * bl = gk_malloc(sizeof(double)*nc, "malloc bl");
  gk_dset(nc, ctrl->bl, bl);
  double * bu = gk_malloc(sizeof(double)*nc, "malloc bu");
  gk_dset(nc, ctrl->bu, bu);




  /* RHS vector for all problems */
  double * b = gk_malloc(sizeof(double)*nr, "malloc b"); 
  gk_dset(nr, 0, b); 
  double * b1 = gk_malloc(sizeof(double)*nr, "malloc b1"); 
  gk_dset(nr, 0, b1); 

  /* c, linear vector */
  /* hold the place for now, c is different across columns */
  double * c = gk_malloc(sizeof(double)*nc, "malloc c"); 
  gk_dset(nc, lambda, c); 


  /* the i-th column of Z, customized for each column */
  float * zi = gk_malloc(sizeof(float)*nr, "malloc zi"); 
  gk_fset(nr, 0, zi); 

  /* the i-th row of ft, customized for each row */
  float * fti = gk_malloc(sizeof(float)*ft->ncols, "malloc fti"); 
  gk_fset(ft->ncols, 0, fti); 

  /* place in case R is converted to binary */
  float * R_rowval = gk_malloc(sizeof(float)*R->rowptr[R->nrows], "malloc R_rowval"); 
  gk_fset(R->rowptr[R->nrows], 0, R_rowval); 
  float * R_colval = gk_malloc(sizeof(float)*R->colptr[R->ncols], "malloc R_colval"); 
  gk_fset(R->colptr[R->ncols], 0, R_colval); 

  /* solution vector */
  double * w = gk_malloc(sizeof(double)*nc, "malloc w"); 
  gk_dset(nc, 0, w); ////
  /* the A matrix */
  gk_csr_t * A = R;  /*  pointer assignment */
  /* temp A */
  cs * csA = gk_malloc(sizeof(cs), "malloc csA");
  /* Workspace for BCLS */
  worksp * Wrk = gk_malloc(sizeof(worksp), "malloc Wrk"); 
  Wrk->A = csA;
  csA->p = A->colptr; /* NOTE: pointer assignment! */
  csA->i = A->colind;
  csA->x = A->colval;
  csA->m = A->nrows; /* NOTE: these params will not change across problems */
  csA->n = A->ncols;
  csA->nzmax = *(A->rowptr + A->nrows); 
  csA->nz = -1; /* column-view, not triplet */
  /* pointer to the active columns in A */
  int * acol = gk_malloc(sizeof(int)*nc, "malloc g_acol"); 
  /* for method sibcls2 */
  gk_iset(nc, 1, acol); 
  Wrk->acol = acol; 
  

  /* output data */
  int bsize = 1000; /* at most 1000 cols */
  gk_csr_t * mat = gk_csr_Create(); 
  mat->nrows = 0; 
  mat->ncols = R->ncols; 
  mat->rowptr = gk_malloc(sizeof(int)*(Y->ncols+1), "malloc mat->rowptr"); 
  mat->rowptr[0] = 0; 
  mat->rowind = gk_malloc(sizeof(int)*mat->ncols*bsize, "malloc mat->rowind"); 
  gk_iset(mat->ncols*bsize, 0, mat->rowind); 
  mat->rowval = gk_malloc(sizeof(float)*mat->ncols*bsize, "malloc mat->rowval"); 
  gk_fset(mat->ncols*bsize, 0, mat->rowval); 



  int starti = ctrl->starti; 
  int endi   = ctrl->endi; 
  if (starti < 0) starti = 0; 
  if (endi < 0) endi = Y->ncols; ///
  float * weights = gk_malloc(sizeof(float)*nr, "malloc weights"); 
  gk_fset(nr, 1.0, weights); /* no weight */
  Wrk->weights = weights; /* pointer assignment */


  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  start_timer(timer); 


  /* go through all columns  */
  for (int i = starti; i < endi; i ++){

    
    /* printf("column %8d: ", i);  */
    if ((i - starti) % 100 == 0){
      printf(".%d", i);  fflush(stdout); 
    }

    /* this column is totally empty */
    if (Y->colptr[i+1] - Y->colptr[i] == 0){
      *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows);
      mat->nrows ++;
      continue;
    }

    /***********************************************************************/
    /* set up all variables needed                                         */
    /***********************************************************************/

    /* generate all the constants for this run */

    /* the bounds for x are same across columns */
/*     gk_dset(nc, ctrl->bl, bl); */
/*     gk_dset(nc, ctrl->bu, bu); */

    /* set up constrainted structure */
    switch(ctrl->lmethod){
    case LMETHOD_SIBCLS2:
      break; 
    case LMETHOD_SIBCLS2_CONSTRAINT:
      sibcls2_generate_constraint(ctrl, acol, nc, ft, i); 
      break; 
    }
    
    /* the c vector is different across columns */
    sibcls2_generate_c(ctrl, ft, lambda, i, c, nc); 

    /* get the i-th column of Z in dense format */
    csr_ExtractColumnsRows(Z, i, zi, GK_CSR_COL); 
    /* get the i-th row of ft in dense format */
    csr_ExtractColumnsRows(ft, i, fti, GK_CSR_ROW); 

    /* R is customized for each column i */
    sibcls2_generate_R(ctrl, R, R_rowval, R_colval, Z, ft, zi, fti, i, CSR_SUBTRACT);  
      


    /* the dependent variable */
    gk_dset(nr, 0, b); 
    findCol(Y, i, b); 
    


    /***********************************************************************/
    /* solve the problem                                                   */
    /***********************************************************************/
    bcsol(ctrl, A, b, w, Wrk, bl, bu, beta, c); 
    



    /***********************************************************************/
    /* periodically save the results                                       */
    /***********************************************************************/

    /* many enough, dump the data */
    if (mat->nrows >= 1000){
      printf("Dumping data...\n"); 
      csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 
      mat->nrows = 0; 
    }
    
    /* fill out the matrix */
    *(mat->rowptr + mat->nrows + 1) = *(mat->rowptr + mat->nrows); 
    for (int j = 0, k = 0; j < nc; j ++){
      /*       if ((ctrl->ibias)? (w[j]): (w[j] > 1e-10)){ */
      if (w[j] > 1e-5){
	*(mat->rowind + mat->rowptr[mat->nrows] + k) = j; 
	*(mat->rowval + mat->rowptr[mat->nrows] + k) = w[j]; 
	(*(mat->rowptr + mat->nrows + 1)) ++; 
	k ++; 
      }
    }
    mat->nrows ++; 

    /* reset */
    gk_dset(nc, 0, w); 
    
    /* recover the R matrix */
    sibcls2_recover_R(ctrl, R, R_rowval, R_colval, Y, ft, zi, fti, i); 


  } /* end of starti - endi */
  printf("\n"); fflush(stdout); 

  /* dump left-overs */
  printf("Dumping data...\n"); 
  csr_Write(mat, ctrl->suggest_file, "a", GK_CSR_FMT_CSR, 1, 1); 


  end_timer(timer); 
  display_timer(timer, "External BCLS"); 


  /***********************************************************************/
  /* finish up                                                           */ 
  /***********************************************************************/
  gk_free((void **)&w, LTERM); 
  gk_free((void **)&bl, &bu, &b, &c, &b1, LTERM); 
  gk_free((void **)&csA, LTERM);   gk_free((void **)&Wrk, LTERM); 
  gk_free((void **)&acol, LTERM);
  gk_free((void **)&weights, LTERM); 
  gk_csr_Free(&mat); 
  gk_free((void **)&timer, LTERM); 
  gk_free((void **)&zi, &fti, LTERM); 
  gk_free((void **)&R_rowval, &R_colval, LTERM); 

}


/*******************************************************************
 * calculate c for a certain column
 *******************************************************************/
void sibcls2_generate_c(ctrl_t * ctrl, gk_csr_t * ft, double lambda, int i,
		       double * c, int n){

  /* column sum over ft */
  for (int k = 0; k < n; k ++){
    c[k] = lambda * ft->csums[k];  
  }
  
  /* subtract the i-th row of ft */
  int nnz = ft->rowptr[i+1] - ft->rowptr[i]; 
  for (int j = 0; j < nnz; j ++){
    int k   = *(ft->rowptr[i] + j + ft->rowind); 
    float v = *(ft->rowptr[i] + j + ft->rowval); 
    c[k] -= lambda * v; 
  }

}


/*******************************************************************
 * calculate R for a certain column
 * this will change R
 *******************************************************************/
void sibcls2_generate_R(ctrl_t * ctrl, gk_csr_t * R, float * R_rowval, float * R_colval, 
			gk_csr_t * Y, gk_csr_t * ft, 
			float * yi, float * fti, int i, int flag){
 
  /*   R = Y * ft */
  /*   R - Y * (the i-th row of ft) */
  /* = Y * ft - Y * (the i-th row of ft ) */
  /* = Y * ( ft with the i-th row as 0 )   */
  /*     since Y >= 0, ft >= 0, the results >= 0 */
  /*   the only positions that need "-" are the ones which have > values since the results  */
  /*   cannot be < 0 */
  

  /* row view first */
  for (int ii = 0; ii < R->nrows; ii ++){
    int nnz = R->rowptr[ii+1] - R->rowptr[ii]; 
    for (int kk = 0; kk < nnz; kk ++){
      int jj  = *(R->rowptr[ii] + kk + R->rowind); 
      /* the ii-jj position in R has non-zero value v */
      switch(flag){
      case CSR_ADD:
/* 	if (ctrl->mult2binary)  */
/* 	  *(R->rowptr[ii] + kk + R->rowval) = 1.0;  ////// */
/* 	else */
	*(R->rowptr[ii] + kk + R->rowval) += yi[ii] * fti[jj]; 
	break; 
      case CSR_SUBTRACT:
/* 	if (ctrl->mult2binary)  */
/* 	  *(R->rowptr[ii] + kk + R->rowval) -= 1.0;  */
/* 	else */
	*(R->rowptr[ii] + kk + R->rowval) -= yi[ii] * fti[jj]; 
	break; 
      }
    }
  }
  
  /* column view also needs updates, this is very important */
  for (int jj = 0; jj < R->ncols; jj ++){
    int nnz = R->colptr[jj+1] - R->colptr[jj]; 
    for (int kk = 0; kk < nnz; kk ++){
      int ii = *(R->colptr[jj] + kk + R->colind); 
      switch(flag){
      case CSR_ADD:
	*(R->colptr[jj] + kk + R->colval) += yi[ii] * fti[jj]; 
	break; 
      case CSR_SUBTRACT:
	*(R->colptr[jj] + kk + R->colval) -= yi[ii] * fti[jj]; 
	break; 
      }
    }
  }


  /* if need binary version */
  if (ctrl->mult2binary)
    sibcls2_mv2binary(R, R_rowval, R_colval, flag); 

}

/*******************************************************************
 * multivariant to binary
 *******************************************************************/
void sibcls2_mv2binary(gk_csr_t * R, float * R_rowval, float * R_colval, int flag){

  int nnz  = R->rowptr[R->nrows]; 
  int nnz2 = R->colptr[R->ncols]; 
  assert(nnz == nnz2); 

  switch(flag){
  case CSR_SUBTRACT:
    gk_fset(nnz, 0, R_rowval); 
    gk_fset(nnz, 0, R_colval); 
    for (int i = 0; i < nnz; i ++){
      if (R->rowval[i] != 0){
	R_rowval[i] = R->rowval[i]; 
	R->rowval[i] = 1.0; 
      }
      if (R->colval[i] != 0){
	R_colval[i] = R->colval[i]; 
	R->colval[i] = 1.0; 
      }
    }
    break; 
  case CSR_ADD:
    for (int i = 0; i < nnz; i ++){
      if (R->rowval[i] != 0)
	R->rowval[i] = R_rowval[i]; 
    }
    for (int i = 0; i < nnz; i ++){
      if (R->colval[i] != 0)
	R->colval[i] = R_colval[i]; 
    }
    break; 
  }

}



/*******************************************************************
 * remove R from sibcls2_generate_R
 *******************************************************************/
void sibcls2_recover_R(ctrl_t * ctrl, gk_csr_t * R, float * R_rowval, float * R_colval, 
		       gk_csr_t * Y, gk_csr_t * ft, 
		       float * yi, float * fti, int i){

  sibcls2_generate_R(ctrl, R, R_rowval, R_colval, Y, ft, yi, fti, i, CSR_ADD); 

}


/*******************************************************************
 * generate structure constraints
 *******************************************************************/
void sibcls2_generate_constraint(ctrl_t * ctrl, int * acol, int n, 
				 gk_csr_t* ft, int i){
  
  gk_iset(n, 0, acol); 
  int nnz = ft->rowptr[i+1] - ft->rowptr[i]; 
  for (int k = 0; k < nnz; k ++){
    int jj  = *(ft->rowptr[i] + k + ft->rowind); 
    acol[jj] = 1; 
  }

}
