#ifndef _BPRMF_H_
#define _BPRMF_H_


/* #include <svdlib.h> */
/* #include <CDL1lib.h> */
#define true 1
#define false 0
typedef int bool; 

/**********************************************
 * suggest model
 **********************************************/
typedef gk_csr_t suggest_model_t; 


/*********************************************************
 * a svd model
 *********************************************************/
typedef struct svdrec svd_model_t ; 


/*****************************************************  
 * timer type
 ****************************************************/
typedef struct {

  clock_t start; 
  clock_t end; 

}ctimer_t; 

/*********************************************************
 * a dense matrix model
 *********************************************************/
typedef struct {

  int nrows; /* # of rows */
  int ncols; /* # of cols */
  
/*   double ** C; /\* a dense item-item similarity matrix *\/ */
  /* float ** C; /\* a dense item-item similarity matrix *\/ */
  float * C; /* a dense item-item similarity matrix, upper-triangle */

}dmat_model_t; 



/*********************************************************
 * a matrix-factorization model
 *********************************************************/
typedef struct {

  bool user_bias; /* if user biased */
  bool item_bias; /* if item biased */
  
  int nu; /* # of users */
  int ni; /* # of items */
  int k;  /* # of latent factors */

  double ** user_factors; /* nu by k if no user biased, otherwise nu by (k+1) */
  double ** item_factors; /* ni by k if no item biased, otherwise ni by (k+1) */

}mf_model_t; 


/*********************************************************
 * a ctrl 
 *********************************************************/
typedef struct{

  char * train_file; /* .csr file containing training data */
  char * test_file;  /* .csr file containing testing data  */
  char * suggest_file;  /* a file with two uses: 
			   1. a W matrix as input to prediction 
			   2. a W matrix as output of BCLS
			*/
  char * ft_file;    /* file for item features, if any */
  char * initW_file; /* this file contains an initial solution for W, it is only one
			line/row (i.e., one init solution) in .mat format */
  
  char * constraint_file; /* .csr file containing a matrix as constraint to sBCLS method */
  char * similarity_file; /* .csr file containing a similarity matrix for items for tree-based method */


  int k; /* # of latent factors */
  int k0; /* if global bias for fm */
  int k1; /* if weights on each feature for fm */
  bool user_bias; /* if user bias */
  bool item_bias; /* if item bias */
  
  double init_mean;  /* mean for normal distribution */
  double init_stdev; /* standard deviation for normal distribution */

  int max_nepochs;  /* max # of iterations */
  int iter_length;  /* length for each iteration */

  double lrate;  /* learning rate */
  double reg_i;  /* regularization for seen items */
  double reg_j;  /* regularization for unseen items */
  double reg_u;  /* regularization for users */

  int topn; /* recommand topn items */

  int dbglvl; /* debug level */
  int realtime_eval; /* if real time evaluation */
  int fast_sample; /* if use fast sampling */
  int sample_train; /* if sample training data */
  float srate; /* sample rate */

  int blas; /* if use blas functions */
  int notest; /* if doing test */
  int exttest; /* test based on externally provided items */
  int fast_test; /* if fast test */

  int wsim; /* if use sparse matrix in QP or not */
  int wtype; /* wsparse type: user or item */

  char * pred_file;    /* file to save predictions  */
  char * ufactor_file; /* file to save user factors/left singular factors */
  char * ifactor_file; /* file to save item factors/right singular factors */
  char * exttest_file; /* file of external items to recommend */

  int load_model; /* if load model from files */
  int save_model; /* if save model into files */
  int save_model_iter; /* if save model in each iteration */

  int lmethod; /* learning method */
  int normalize; /* if normalize suggest matrix */
  int normalizeA; /* if normalize A matrix in QP formuation */

  int sc_weighted; /* if sc weighted */

  int sm_topk;  /* if only use topk from suggest model, set as > 0 */
  int test2; 

  double beta; 
  double lambda; 
  double beta1; 
  double beta2; 
  double lambda1;
  double lambda2; 
  double gamma; 
  double gamma1; 
  double sigma; 
  double alpha; 

  int starti; 
  int endi; 
  int interi; /* from this point on, the features are different, e.g., words - item or user - item*/

  int errork; /* if seperate errors into two parts 1s and 0s, 
		 and weights on 1s are k-times of weights on 0s */
  int error2; /* if seperate errors into two parts */
  int sparsity; /* if explicitly control w sparsity in BCLS */
  float w1; /* weight on nnzs in QP formuation */
  float p ; /* weight ratio on 1s and 0s */
  int gnoise; /* if add gaussian noise */
  int constraint; 
  int rowmajor; /* in model matrix, if each row has knn, used only in suggest prediction*/

  int ibias; /* if has item bias */
  float ibias_step; /* step size for linear bias search */

  double bl; /* lower bound */
  double bu; /* upper bound */

  /* for enet */
  int stop; 
  double tol; 

  double optTol; /* optimality tolerance for BCLS */
  int initw; /* if use init w */

  float sim_threshold; /* similarity threshold */

  int mst; /* if use mst */

  int pred_norm; /* during prediction if normalize */

  int Aopt; /* options on how to manipulate A matrix */

  int cdl1_method; /* method for CDL1 updates */

  int combineBR; /* combine binary&raing into one formuation */
  
  int nratings; /* number of different unique ratings */

  int check_support; /* check support during recommendation */

  int test_bcls; /* test */
  int max_bcls_niters; /* max number of iterations allow in BCLS solver */
  int suggest_br; /* use predictions from both ratings and binaries */

  int rscale; /* if scale the rating data */
  float rscale_alpha; 

  double c_pos; 

  int pred_rating; /* if predict ratings */

  int kernel; /* kernel type */

  int nthreads; /* # of threads in parallel */
  int openmp; /* if use openmp */

  int mult2binary; /* if convert multivariante to binary  */

}ctrl_t; 


/* /\* --- primary CSparse routines and data structures ------------------------- *\/ */
/* /\* this is the column view of gk_csr_t *\/ */
/* typedef struct cs_sparse    /\* matrix in compressed-column or triplet form *\/ */
/* { */
/*   int nzmax ;	    /\* maximum number of entries *\/ */
/*   int m ;	    /\* number of rows *\/ */
/*   int n ;	    /\* number of columns *\/ */
/*   int *p ;	    /\* column pointers (size n+1) or col indices (size nzmax) *\/ */
/*   int *i ;	    /\* row indices, size nzmax *\/ */
/*   /\*     double *x ;	    /\\* numerical values, size nzmax *\\/ *\/ */
/*   float *x ;	    /\* numerical values, size nzmax *\/ */
/*   int nz ;	    /\* # of entries in triplet matrix, -1 for compressed-col *\/ */
/* } cs ; */

/* // --------------------------------------------------------------------- */
/* // Workspace structure passed to Aprod and Usolve routines. */
/* // --------------------------------------------------------------------- */
/* typedef struct { */
/*   cs *A; */
/*   float * weights; */
/*   int * acol; */
/* } worksp; */


/*******************************************************
 * a node structure for MST
 ******************************************************/
struct mst_node_t; 
typedef struct mst_node * pnode; 
typedef struct mst_node{

  int max_nchildren; /* max number of children */
  int nchildren; /* current number of children */
  pnode * children ; /* pointer to the children of this node, should be a list of size nchildren */
  pnode parent; /* pointer to the parent of this node */
  int id; /* id of this node, should correspond to the column id */

  float parsim; /* similarity to the parent */
  
  int nnzs; /* number of non-zeros in the solution */
  int * colptr; /* same as in csr_t structure */
  float * colval; /* same as in csr_t strcuture */

}mst_node_t; 


/*********************************************************
 * a structure for weighted edges  
 *********************************************************/
typedef struct wedge{

  float weight; 
  int node1; 
  int node2; 

}wedge_t; 

/*********************************************************
 * a queue structure for weighted edges  
 *********************************************************/
typedef struct queue_edges{

  int head; 
  int tail; 
  int max_size; 
  int nedges; 
  wedge_t * queue; 

}queue_edges_t; 

/*********************************************************
 * a queue structure for nodes
 *********************************************************/
typedef struct queue_nodes{

  int head; 
  int tail; 
  int max_size; 
  int nnodes; 
  int * queue; 

}queue_nodes_t; 

/*********************************************************
 * factorization machines
 *********************************************************/
typedef struct fm2{

  double w0; /* global bias */
  double reg0; /* regular scale for w0 */

  double * w; /* weight on each feature */
  double regw; /* regular for w */

  double ** v; /* factorized interactions */
  double * regv; /* regular for v */

  int k0; /* if use global bias */
  int k1; /* if independent weight */
  int num_factor; /* factor dimension */
  int n;  /* number of all features */

}fm_t; 

/* --- primary CSparse routines and data structures ------------------------- */
/* this is the column view of gk_csr_t */
typedef struct cs_sparse    /* matrix in compressed-column or triplet form */
{
  int nzmax ;       /* maximum number of entries */
  int m ;           /* number of rows */
  int n ;           /* number of columns */
  int *p ;          /* column pointers (size n+1) or col indices (size nzmax) */
  int *i ;          /* row indices, size nzmax */
  /*     double *x ;        /\* numerical values, size nzmax *\/ */
  float *x ;        /* numerical values, size nzmax */
  int nz ;          /* # of entries in triplet matrix, -1 for compressed-col */
} cs ;

typedef struct {
  cs *A;
  float * weights;
  int * acol;
  int * arow; 
} worksp;


#endif
