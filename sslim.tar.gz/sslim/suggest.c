#include<bprmf.h>

extern int * iidx; 
extern float * g_ubias; 
extern float * g_ibias; 
float * g_ubiasw = NULL; 
float * g_ibiasw = NULL; 


/*******************************************************
 * suggest
 *******************************************************/
void suggest(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  gk_csr_t * train2 = gk_csr_Dup(train); 

  suggest_model_t * model = NULL; 

  /* 
     suggest model is nothing but an |I|-by-|I| item-item similarity matrix, 
     in which each value at position (i, j) says if item i is within 
     item j's neighborbood (i.e., nnz values), and value determines "similarity"
     Note that it is the output directly from QP, which is the transpose of 
     W in AW ~ A and the transpose of SUGGEST itemcos model, and this is the
     default model setting
  */
  model = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1); 
/*   model->ncols = train2->ncols;  */
  


  double * eval = NULL;  
  switch(ctrl->wtype){

    /* item based model */
  case WTYPE_ITEM:
    /* this is to handle models from SUGGEST */
    if (ctrl->rowmajor){
      model->ncols = train2->ncols;
      csr_transpose(model); 
      /* gk_csr_SortIndices(model, GK_CSR_ROW); */
    }
    /* sanity check */
    printf("model->nrows = %d, model->ncols = %d\n", model->nrows, model->ncols); 
/*     model->ncols = train2->ncols;  */
    model->ncols = model->nrows; 
    /* if (model->nrows != model->ncols) printf("model->nrows = %d, model->ncols = %d\n", model->nrows, model->ncols);  */
    /* assert(model->nrows == model->ncols);  */
    eval = suggest_test2(ctrl, model, train2, train2, test); 
    break; 

    /* user based model */
  case WTYPE_USER:
/*     /\* this is to handle models from SUGGEST *\/ */
    if (ctrl->rowmajor){
/*       model->ncols = train2->ncols; */
      csr_transpose(model); 
      /* gk_csr_SortIndices(model, GK_CSR_ROW); */
    }
    printf("model->nrows = %d, model->ncols = %d\n", model->nrows, model->ncols); 
    /* sanity check */
/*     model->ncols = train2->nrows;  */
/*     csr_transpose(train2);  */
    
/*     eval = suggest_test2(ctrl, train2, model, test);  */
    eval = suggest_test2(ctrl, model, train2, train2, test); 
    break; 
  }

  /* print the results */
  for (int j = 0; j < ctrl->nratings; j ++)
    printf("R%3d HR = %.5f ARHR = %.5f cumulative HR = %.5f ARHR = %.5f\n", 
	   j+1, eval[j*4], eval[j*4+1], eval[j*4+2], eval[j*4+3]); 


  /* clean up */
  gk_free((void **)&eval, LTERM); 
  gk_csr_Free(&train2); 
  gk_csr_Free(&model); 
  
}


/* /\******************************************************* */
/*  * suggest */
/*  *******************************************************\/ */
/* void suggest(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){ */

/*   gk_csr_t * train2 = gk_csr_Dup(train);  */
/*   if (ctrl->ibias) */
/*     add_ibias(&train2); */
  

/*   double alpha = ctrl->alpha;  */
/*   int interi = ctrl->interi;  */
/*   if (alpha >= 0 && alpha < 1.0 && interi >= 0){ */
/*     assert(interi <= train->nrows);  */
/*     for (int i = train->rowptr[interi]; i < train->rowptr[train->nrows]; i ++) */
/*       train->rowval[i] *= sqrt(alpha);  */
/*   } */
/*   gk_csr_CreateIndex(train, GK_CSR_COL);  */
/*   suggest_model_t * model = NULL;  */

/*   /\*  */
/*      suggest model is nothing but an |I|-by-|I| item-item similarity matrix,  */
/*      in which each value at position (i, j) says if item i is within  */
/*      item j's neighborbood (i.e., nnz values), and value determines "similarity" */
/*      Note that it is the output directly from QP, which is the transpose of  */
/*      W in AW ~ A and the transpose of SUGGEST itemcos model, and this is the */
/*      default model setting */
/*   *\/ */
/*   model = gk_csr_Read(ctrl->suggest_file, GK_CSR_FMT_CSR, 1, 1);  */
/*   model->ncols = train2->ncols;  */
/*   if (ctrl->sm_topk > 0){ */
/*     gk_csr_t * model2 = gk_csr_TopKPlusFilter(model, GK_CSR_ROW, ctrl->sm_topk, SUGGEST_TOPK_KEEPVAL);  */
/*     gk_csr_Free(&model);  */
/*     model = model2;  */
/*   } */

/*   /\* this is to handle models from SUGGEST *\/ */
/*   if (ctrl->rowmajor){ */
/*     model->colptr = model->rowptr;  */
/*     model->colind = model->rowind;  */
/*     model->colval = model->rowval;  */
/*     int tmp_ncols = model->ncols;  */
/*     model->ncols  = model->nrows;  */
/*     model->rowptr = NULL;  */
/*     model->rowind = NULL;  */
/*     model->rowval = NULL;  */
/*     model->nrows  = tmp_ncols;  */
/*     gk_csr_CreateIndex(model, GK_CSR_ROW);  */
/*   } */

/*   gk_csr_SortIndices(model, GK_CSR_ROW); */
/*   if (ctrl->normalize){ */
/*     gk_csr_CreateIndex(model, GK_CSR_COL);  */
/*     gk_csr_Normalize(model, GK_CSR_COL, 1);  */
/*     gk_csr_CreateIndex(model, GK_CSR_ROW);  */
/*   } */


/*   if (ctrl->Aopt == AOPT_FULL_BIAS){ */
/*     /\* pre-calculate user-bias and item-bias *\/ */
/*     g_ubias = csr_mean(train, GK_CSR_ROW);  */
/*     g_ibias = csr_mean(train, GK_CSR_COL);    */
/*     /\* ibias * W*\/ */
/*     g_ibiasw = gk_malloc(sizeof(float)*train->ncols, "malloc g_ibiasw");  */
/*     gk_fset(train->ncols, 0, g_ibiasw);  */
/*     /\* column sum of W *\/ */
/*     g_ubiasw = gk_malloc(sizeof(float)*train->ncols, "malloc g_ubiasw");  */
/*     gk_fset(train->ncols, 0, g_ubiasw);  */
/*     for (int i = 0; i < model->nrows; i ++){ */
/*       int ni = model->rowptr[i+1] - model->rowptr[i];  */
/*       for (int ii = 0; ii < ni; ii ++){ */
/* 	int j = *(model->rowptr[i] + ii + model->rowind);  */
/* 	g_ibiasw[j] += g_ibias[i]* *(model->rowptr[i] + ii + model->rowval);  */
/* 	g_ubiasw[j] += *(model->rowptr[i] + ii + model->rowval);  */
/*       } */
/*     } */
/*   } */



/*   double * eval = NULL;   */
/* /\*   if (!ctrl->test2) *\/ */
/* /\*     eval = suggest_test(ctrl, model, train2, test);  *\/ */
/* /\*   else *\/ */
/*   switch(ctrl->wtype){ */
/*   case WTYPE_ITEM: */
/*     eval = suggest_test2(ctrl, model, train2, test);  */
/*     break;  */
/*   case WTYPE_USER: */
/*     eval = suggest_test2(ctrl, train2, model, test);  */
/*     break;  */
/*   } */
/* /\*   printf("     HR = %.5f ARHR = %.5f \n", eval[0], eval[1]);  *\/ */
/* /\*   for (int j = 0; j < ctrl->nratings; j ++) *\/ */
/* /\*     printf("R%3d HR = %.5f ARHR = %.5f \n", j+1, eval[(j+1)*2], eval[(j+1)*2+1]);  *\/ */
/*   for (int j = 0; j < ctrl->nratings; j ++) */
/*     printf("R%3d HR = %.5f ARHR = %.5f cumulative HR = %.5f ARHR = %.5f\n",  */
/* 	   j+1, eval[j*4], eval[j*4+1], eval[j*4+2], eval[j*4+3]);  */


/*   gk_free((void **)&eval, LTERM);  */

/*   gk_csr_Free(&train2);  */
/*   gk_csr_Free(&model);  */
  
/*   //  if (ctrl->Aopt == AOPT_FULL_BIAS) */
/*   gk_free((void **)&g_ubias, &g_ubiasw, &g_ibias, &g_ibiasw, LTERM);  */
  
/* } */

/********************************************************
 * suggest test
 ********************************************************/
double * suggest_test2(ctrl_t * ctrl, suggest_model_t * model, 
		       gk_csr_t * train, gk_csr_t * train2, gk_csr_t * test){

/*   int nu = train->nrows;  */
  int nu = test->nrows; 
  int nhits = 0; 
  double arh = 0; 
  int n = 0; 

  gk_csr_CreateIndex(model, GK_CSR_COL); 

  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  start_timer(timer); 

/*   double * eval = gk_malloc(sizeof(double)*(1+ctrl->nratings)*2, "malloc eval");  */
/*   gk_dset((1+ctrl->nratings)*2, 0, eval);  */
  double * eval = gk_malloc(sizeof(double)*(ctrl->nratings)*4, "malloc eval"); 
  gk_dset(ctrl->nratings*4, 0, eval); 

  int * nr = gk_malloc(sizeof(int)*ctrl->nratings, "malloc nr"); 
  gk_iset(ctrl->nratings, 0, nr); 

  
  int ncols = train2->ncols; 
  if (ncols < model->ncols)
    ncols = model->ncols; 
  if (ctrl->wtype==WTYPE_USER) ncols = model->nrows; 
  int * nc = gk_malloc(sizeof(int)*ncols, "malloc nc"); 
  gk_iset(ncols, 0, nc); 
  int * nhc = gk_malloc(sizeof(int)*ncols, "malloc nhc"); 
  gk_iset(ncols, 0, nhc); 

  FILE * pfile = NULL; 
  if (ctrl->dbglvl > 0){
    pfile = gk_fopen(ctrl->pred_file, "w", "pred file"); 
    printf("predictions to %s file...\n", ctrl->pred_file); 
  }
  
  for (int u = 0; u < nu; u ++){
  
    if (u % 1000 == 0) {
      if (ctrl->dbglvl == 0){
	printf("."); fflush(stdout); 
      }
    }

    if (test->rowptr[u+1] - test->rowptr[u] == 0) {
      if (ctrl->dbglvl > 0) 
	fprintf(pfile, "\n"); 
      continue; 
    }
    n ++; 

/*     /\* rating prediction*\/ */
/*     if (ctrl->pred_rating == 1){ */
/*       for (int jj = test->rowptr[u]; jj < test->rowptr[u+1]; jj ++){ */
/* 	int ii = test->rowind[jj];  */
/* 	float r = test->rowval[jj];  */
/* 	float rcmdv = rsuggest_predict(ctrl, model, train, ii);  */
/*       } */
/*       continue;  */
/*     } */

    
    /* top-n recommendation */
    gk_dkv_t * rcmd = NULL; 
    int nrcmd = 0; 
/*     switch(ctrl->wtype){ */
/*     case WTYPE_ITEM: */
    nrcmd = suggest_predict2(ctrl, model, iidx, train, train2, u, RCMD_EXCLUDE_HISTORY, &rcmd); 
/*       break;  */
/*     case WTYPE_USER: */
/*       nrcmd = suggest_predict2(ctrl, model, iidx, train, u, &rcmd);  */
/*       break;  */
/*     } */
    
/*     int r = (int)(*(test->rowptr[u] + test->rowval)); /\* assume all ratings are integers [1, 2, ..., nratings],  */
/* 							 default Leave-One-Out*\/ */

    for (int kk = test->rowptr[u]; kk < test->rowptr[u+1]; kk ++){
	
      int r = (int)(test->rowval[kk]); /* assume all ratings are integers [1, 2, ..., nratings] */
      nr[r-1] ++ ; 

      nc[test->rowind[kk]] ++; 
    }


    for (int jj = 0; jj < nrcmd; jj ++){

      if (ctrl->dbglvl > 0){

	fprintf(pfile, "%d %.5f ", (int)rcmd[jj].val+1, rcmd[jj].key);

      }
/* /\* 	if (rcmd[jj].key != rcmd[jj].key){ *\/ */
/* /\* 	  printf("NAN user %d item %d\n", u, (int)rcmd[jj].val+1);  *\/ */
/* /\* 	  errexit("NAN\n");  *\/ */
/* /\* 	} *\/ */
/*       } */

      for (int kk = test->rowptr[u]; kk < test->rowptr[u+1]; kk ++){

	int r = (int)(test->rowval[kk]); /* assume all ratings are integers [1, 2, ..., nratings] */
/* 	if (jj == 0) */
/* 	  nr[r-1] ++ ;  */

	/* hit hit */
	if (rcmd[jj].val == test->rowind[kk]){

	  nhc[test->rowind[kk]] ++; 

	  /* nhits += jj; break;  */
	  /* overall hit rates */
	  nhits ++; arh += 1.0/(double)(jj + 1) ;
	  /* hit rates on different ratings */
	  /* 	eval[r*2] ++; /\* hit rate on rating r *\/ */
	  /* 	eval[r*2 + 1] += 1.0/(double)(jj + 1) ; /\* arh on rating r *\/ */
	  eval[(r - 1)*4 + 0] += 1.0; /* hit rate on rating r */
	  eval[(r - 1)*4 + 1] += 1.0/(double)(jj + 1) ; /* arh on rating r */
	  eval[(r - 1)*4 + 2]  = eval[(r - 1)*4 + 0]; 
	  eval[(r - 1)*4 + 3]  = eval[(r - 1)*4 + 1]; 
	
	  /* check how many sims contribute to the recommendation, etc */
	  /* support for hit */
	  /* 	if (ctrl->check_support) */
	  /* 	  check_support(ctrl, model, train, u, rcmd[jj].val);  */
	
	  /* print out the W entries that contribute to this hit */
/* 	  if (ctrl->dbglvl == 1){ */
	    
/* 	    int h = rcmd[jj].val; */
/* 	    printf("\n> %d:%d ", u+1, h+1); */

/* 	  /\* 	  int nu = train->rowptr[u+1] - train->rowptr[u];  *\/ */
/* 	  /\* 	  int ni = model->rowptr[h+1] - model->rowptr[h];  *\/ */
/* 	  /\* 	  int uk = 0, mk = 0;  *\/ */
/* 	  /\* 	  while(uk < nu && mk < ni){ *\/ */
/* 	  /\* 	    int   i1 = *(train->rowptr[u] + uk + train->rowind);  *\/ */
/* 	  /\* 	    //float v1 = *(train->rowptr[u] + uk + train->rowval);  *\/ */
/* 	  /\* 	    int   i2 = *(model->rowptr[h] + mk + model->rowind);  *\/ */
/* 	  /\* 	    float v2 = *(model->rowptr[h] + mk + model->rowval);  *\/ */
/* 	  /\* 	    if (i1 == i2){ *\/ */
/* 	  /\* 	      printf("%d %.5f ", i1, v2);  *\/ */
/* 	  /\* 	      uk ++; mk ++;  *\/ */
/* 	  /\* 	    }else if (i1 < i2){ *\/ */
/* 	  /\* 	      uk ++;  *\/ */
/* 	  /\* 	    }else{ *\/ */
/* 	  /\* 	      mk ++;  *\/ */
/* 	  /\* 	    } *\/ */
/* 	  /\* 	  } *\/ */
/* 	    printf("\n"); */
/* 	  } */

/* 	  if (ctrl->dbglvl <= 0) */
/* 	    break; */
	}
      }


/*       /\* print out the W entries that contribute to this hit/nonhit *\/ */
/*       if (ctrl->dbglvl == 1){ */

/* 	int h = rcmd[jj].val;  */
/* 	if (h ==  *(test->rowptr[u] + test->rowind)) */
/* 	  printf("> %d:%d ", u+1, h+1);  */
/* 	else  */
/* 	  printf("< %d:%d ", u+1, h+1);  */

/* 	int nu = train->rowptr[u+1] - train->rowptr[u];  */
/* 	int ni = model->rowptr[h+1] - model->rowptr[h];  */
/* 	int uk = 0, mk = 0;  */
/* 	while(uk < nu && mk < ni){ */
/* 	  int   i1 = *(train->rowptr[u] + uk + train->rowind);  */
/* 	  //float v1 = *(train->rowptr[u] + uk + train->rowval);  */
/* 	  int   i2 = *(model->rowptr[h] + mk + model->rowind);  */
/* 	  float v2 = *(model->rowptr[h] + mk + model->rowval);  */
/* 	  if (i1 == i2){ */
/* 	    printf("%d %.5f ", i1, v2);  */
/* 	    uk ++; mk ++;  */
/* 	  }else if (i1 < i2){ */
/* 	    uk ++;  */
/* 	  }else{ */
/* 	    mk ++;  */
/* 	  } */
/* 	} */
/* 	printf("\n");  */
/*       } */

    }
    /* support for top-1 rcmd */
    if (ctrl->check_support)
      check_support(ctrl, model, train, u, rcmd[0].val); 


    if (ctrl->dbglvl > 0)
      fprintf(pfile, "\n");

/*     nr[r-1] ++ ;  */

    /* clean up */
    gk_free((void **)&rcmd, LTERM); 
    
  }


  printf("\n"); 
  end_timer(timer); 
  display_timer(timer, "test"); 
  gk_free((void **)&timer, LTERM); 

  /* all stats */
/*   eval[0] = (double)nhits/(double)n; /\* hit rate *\/ */
/*   eval[1] = arh/(double)n; /\* average reciprocal hit rate *\/ */
/*   for (int i = 0; i < ctrl->nratings; i ++){ */
/*     if (nr[i] > 0){ */
/*       eval[(i+1)*2] /= (double)nr[i];  */
/*       eval[(i+1)*2 + 1] /= (double)nr[i];  */
/*     } */
/*   } */
  for (int i = 0; i < ctrl->nratings; i ++){
    if (nr[i] > 0){
      eval[i*4 + 0] /= (double)nr[i];
      eval[i*4 + 1] /= (double)nr[i];
    }
  }
  /* cumulative stats */
  for (int i = ctrl->nratings - 2; i >= 0; i --){
    nr[i]         += nr[i+1]; /* cumulative counts */
    eval[i*4 + 2] += eval[(i+1)*4 + 2]; /* cumulative hit counts */
    eval[i*4 + 3] += eval[(i+1)*4 + 3];  /* cumulative rhr counts */
  }
  for (int i = 0; i < ctrl->nratings; i ++){
    if (nr[i] > 0){
      eval[i*4 + 2] /= (double)nr[i];
      eval[i*4 + 3] /= (double)nr[i];    
    }
  }

/*   /\* hr for each column *\/ */
/*   printf("train counts:  ");  */
/*   for (int k = 0; k < train->ncols; k ++){ */
/*     if (nc[k] > 0) */
/*       printf("%6d %6d ", k, train->colptr[k+1] - train->colptr[k]);  */
/*   } */
/*   printf("\n");  */
/*   printf("column counts: ");  */
/*   for (int k = 0; k < train->ncols; k ++){ */
/*     if (nc[k] > 0) */
/*       printf("%6d %6d ", k, nc[k]);  */
/*   } */
/*   printf("\n");  */
/*   printf("column hr    : ");  */
/*   for (int k = 0; k < train->ncols; k ++){ */
/*     if (nc[k] > 0) */
/*       printf("%6d %.5f ", k, (float)nhc[k]/(float)nc[k]);  */
/*   } */
/*   printf("\n");  */
  
  
  if (ctrl->dbglvl > 0)
    gk_fclose(pfile); 
  gk_free((void **)&nc, LTERM); 
  gk_free((void **)&nhc, LTERM); 
  gk_free((void **)&nr, LTERM); 
  return eval; 



}



/*********************************************************
 * suggest predict
 *********************************************************/
int suggest_predict2(ctrl_t * ctrl, suggest_model_t * model, int * idx, 
		     gk_csr_t * train, gk_csr_t * train2, int u, int flag, gk_dkv_t ** rcmd){


  gk_csr_t * mytrain = train; 
  suggest_model_t * mymodel = model; 

/*   switch(ctrl->wtype){ */
/*   case WTYPE_ITEM: */
/*     /\* ni = train->ncols;    *\/ */
/*     break;  */
/*   case WTYPE_USER: */
/* /\*     ni = model->nrows;  *\/ */
/*     mytrain = model;  */
/*     mymodel = train;  */
/*     break;  */
/*   } */

  if (mymodel->colptr == NULL)
    gk_csr_CreateIndex(mymodel, GK_CSR_COL); 

  int ni = 0; 
/*   switch(ctrl->wtype){ */
/*   case WTYPE_ITEM: */
/*     ni = mytrain->ncols;    */
/*     break;  */
/*   case WTYPE_USER: */
/*     ni = mymodel->nrows;  */
/*     break;  */
/*   } */

/*   ni = mymodel->ncols;  */
  ni = train2->ncols; 

  if (iidx == NULL)
    iidx = gk_malloc(sizeof(int)*ni, "malloc iidx"); 

  gk_iset(ni, -1, iidx); 
  
  int nuitrn = 0; 
  switch(ctrl->wtype){
  case WTYPE_ITEM:
/*     nuitrn = mytrain->rowptr[u+1] - mytrain->rowptr[u];  */
    nuitrn = train2->rowptr[u+1] - train2->rowptr[u]; 
    for (int ii = 0; ii < nuitrn; ii ++)
      *(iidx + *(train2->rowptr[u] + ii + train2->rowind)) -= 1; 
    break; 
  case WTYPE_USER:
    nuitrn = mymodel->colptr[u+1] - mymodel->colptr[u]; 
    for (int ii = 0; ii < nuitrn; ii ++)
      *(iidx + *(mymodel->colptr[u] + ii + mymodel->colind)) -= 1; 
    break; 
  }
  
  if (nuitrn == 0){
    *rcmd = NULL; 
    return 0; 
  }

  /* can recommend items that are in profiles already */
  if (flag == RCMD_INCLUDE_HISTORY)
    gk_iset(ni, -1, iidx); 

  gk_dkv_t * ccandr = gk_malloc(sizeof(gk_dkv_t)*ni, "malloc ccandr"); 
  gk_dkv_t * ccandb = gk_malloc(sizeof(gk_dkv_t)*ni, "malloc ccandb"); 
  int nrcmd = 0; 

  float * sim_norm = gk_malloc(sizeof(float)*ni, "malloc sim_norm"); 
  gk_fset(ni, 0, sim_norm); 


  nuitrn = mytrain->rowptr[u+1] - mytrain->rowptr[u];
  for (int i = 0; i < nuitrn; i ++){
    int ii = *(mytrain->rowptr[u] + i + mytrain->rowind); 
    for (int j = 0; j < mymodel->colptr[ii+1] - mymodel->colptr[ii]; j ++){
      int jj = *(mymodel->colptr[ii] + j + mymodel->colind); 
      if (iidx[jj] < -1) continue; 

      
      if (iidx[jj] == -1){
	iidx[jj] = nrcmd; 
	/* predict using ratings */
/* 	ccandr[nrcmd].key = *(mymodel->colptr[ii] + j + mymodel->colval);  */
	ccandr[nrcmd].key = *(mymodel->colptr[ii] + j + mymodel->colval) * *(mytrain->rowptr[u] + i + mytrain->rowval); 
	ccandr[nrcmd].val = jj; 	

	/* predict using binaries */
	ccandb[nrcmd].key = *(mymodel->colptr[ii] + j + mymodel->colval) * 1.0; 
	ccandb[nrcmd].val = jj; 	

	nrcmd ++; 
      }else{
/* 	ccandr[iidx[jj]].key += *(mymodel->colptr[ii] + j + mymodel->colval);  */
	ccandr[iidx[jj]].key += *(mymodel->colptr[ii] + j + mymodel->colval) * *(mytrain->rowptr[u] + i + mytrain->rowval); 
	ccandb[iidx[jj]].key += *(mymodel->colptr[ii] + j + mymodel->colval) * 1.0; 
      }
      sim_norm[jj] += fabs(*(mymodel->colptr[ii] + j + mymodel->colval));      
    }
  }

  if (ctrl->Aopt == AOPT_FULL_BIAS){
    for (int i = 0; i < nrcmd; i ++){
      int j = ccandr[i].val; 
      ccandr[i].key += g_ibiasw[j] + g_ubiasw[j] * g_ibias[u]; 
    }      
  }
  
  if (ctrl->pred_norm){
    for (int i = 0; i < nrcmd; i ++){
      if (sim_norm[(int)ccandr[i].val] != 0)
	ccandr[i].key /= sim_norm[(int)ccandr[i].val]; 
    }
  }

  /* combine the two predictions */
  if (ctrl->suggest_br){
    for (int i = 0; i < nrcmd; i ++){
      ccandr[i].key *= ctrl->gamma; 
/*       ccandr[i].key += (1.0 - ctrl->gamma) * ccandb[i].key;  */
      ccandr[i].key += ccandb[i].key; 
    }
  }

  gk_dkvsortd(nrcmd, ccandr); 
  int nrcmd2 = gk_min(nrcmd, ctrl->topn); 
  *rcmd = ccandr; 

  gk_free((void **)&ccandb, LTERM); 
  gk_free((void **)&sim_norm, LTERM); 

  return nrcmd2; 
  
}


/********************************************************
 * suggest test
 ********************************************************/
double * suggest_test(ctrl_t * ctrl, suggest_model_t * model, 
		      gk_csr_t * train, gk_csr_t * test){

  int nu = train->nrows; 
  int ni = train->ncols; 
  int nhits = 0; 
  double arh = 0; 
  int n = 0; 

  if (iidx == NULL)
    iidx = gk_malloc(sizeof(int)*ni, "malloc iidx"); 

  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  start_timer(timer); 
  for (int u = 0; u < nu; u ++){

    if (u % 1000 == 0) {
      printf("."); fflush(stdout); 
    }

    if (test->rowptr[u+1] - test->rowptr[u] == 0) continue; 

    n ++; 
    
    gk_iset(ni, 0, iidx); 
	
    int nuitrn = train->rowptr[u+1] - train->rowptr[u]; 
    for (int ii = 0; ii < nuitrn; ii ++)
      *(iidx + *(train->rowptr[u] + ii + train->rowind)) += 1; 

    int nuitst = ni - nuitrn; 
    gk_dkv_t * rcmd = gk_malloc(sizeof(gk_dkv_t)*ctrl->topn, "malloc rcmd"); 

    for (int jj = 0, kk = 0; jj < ni; jj ++){
      
      if (iidx[jj]) continue; 
      
      double p = suggest_predict(ctrl, model, train, u, jj); 
      update_topn(rcmd, ctrl->topn, kk, p, jj); 
      kk ++; 

    }

    for (int jj = 0; jj < ((ctrl->topn < nuitst)? ctrl->topn:nuitst); jj ++){
      if (ctrl->dbglvl > 0)
	printf("%d %.5f ", (int)rcmd[jj].val+1, rcmd[jj].key);
      if (rcmd[jj].val == *(test->rowptr[u] + test->rowind)){ /* default Leave-One-Out */
	/* nhits += jj; break;  */
	nhits ++; arh += 1.0/(double)(jj + 1) ; break; 
      }
    }
    if (ctrl->dbglvl > 0){
/*       printf(" ; %d %.5f", *(test->rowptr[u] + test->rowind)+1, */
/* 	     suggest_predict(ctrl, model, train, u, *(test->rowptr[u] + test->rowind))); */
      printf("\n");
    }

    gk_free((void **)&rcmd, LTERM); 

  }

  printf("\n"); 
  end_timer(timer); 
  display_timer(timer, "test"); 
  gk_free((void **)&timer, LTERM); 
    
  double * eval = gk_malloc(sizeof(double)*2, "malloc eval"); 
  eval[0] = (double)nhits/(double)n; /* hit rate */
  eval[1] = arh/(double)n; /* average reciprocal hit rate */

  return eval; 


}


/*********************************************************
 * suggest predict
 *********************************************************/
double suggest_predict(ctrl_t * ctrl, suggest_model_t * model, 
		       gk_csr_t * train, int u, int i){

  int uni = train->rowptr[u+1] - train->rowptr[u]; 
  int ini = model->rowptr[i+1] - model->rowptr[i]; 
  
  int ju = 0; 
  int ji = 0; 
  double p = 0; 
  while(ju < uni && ji < ini){
    
    int ui = *(train->rowind + train->rowptr[u] + ju); 
    int ii = *(model->rowind + model->rowptr[i] + ji); 
    
    if (ui == ii) {
      p += *(model->rowval + model->rowptr[i] + ji); 
      ju ++; ji ++; 
    }
    else if (ui < ii){
      ju ++; 
    }
    else if (ui > ii){
      ji ++; 
    }
  }
  
  return p; 

}

/*************************************************************
 * check support
 *************************************************************/
void check_support(ctrl_t * ctrl, suggest_model_t * model, gk_csr_t * train, 
		   int useri, int itemj){

  /* NOTE by default model is the transpose of W as in AW - A */
  float rval = 0; 
  gk_fkv_t * rval_idx = gk_malloc(sizeof(gk_fkv_t)*(train->ncols), "malloc rval_idx"); 
  int n = 0; 

  int j1 = 0, j2 = 0; 
  int nj1 = train->rowptr[useri+1] - train->rowptr[useri];  
  int nj2 = model->rowptr[itemj+1] - model->rowptr[itemj]; 

  while(j1 < nj1 && j2 < nj2){  /* row indices are already sorted */
    int i1   = *(train->rowptr[useri] + j1 + train->rowind); 
    int i2   = *(model->rowptr[itemj] + j2 + model->rowind); 
    float v1 = *(train->rowptr[useri] + j1 + train->rowval); 
    float v2 = *(model->rowptr[itemj] + j2 + model->rowval); 
    if (i1 == i2){
      rval_idx[n].key = v1 * v2; 
      rval_idx[n].val = i1; 
      n ++; 
      rval += v1 * v2; 
      j1 ++; j2 ++; 
    }else if (i1 < i2)
      j1 ++; 
    else 
      j2 ++; 
  }

  gk_fkvsortd(n, rval_idx); 
  float rval2 = 0; 
  for (int i = 0; i < n; i ++){
    rval2 += rval_idx[i].key; 
    if (rval2 > 0.5 * rval){
      printf("Support check for user %d on item %d: rval = %.5f 0.5-support %d 1.0-support %d\n",
	     useri+1, itemj+1, rval, i+1, n); 
      break; 
    }
  }

  gk_free((void **)&rval_idx, LTERM); 

}
