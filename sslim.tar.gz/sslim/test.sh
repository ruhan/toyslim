./SSLIM -lmethod=cbcls -train_file=train.mat -test_file=test.mat -ft_file=train_feature.mat -suggest_file=out.mat -beta=1 -lambda=1 -optTol=0.00001 -nratings=1 -blas -wtype=item -wsim=sparse -max_bcls_niters=10000 -starti=1 -endi=100

