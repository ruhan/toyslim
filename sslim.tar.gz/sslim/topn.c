#include<bprmf.h>


/***********************************************************
 * update top-n list
 ***********************************************************/
int update_topn(gk_dkv_t * list, int topn, int i, double key, gk_idx_t val){

  int updated = 0; 

  /* only few key-val pairs, go ahead save them */
  if (i < topn){
    list[i].key = key; 
    list[i].val = val;
    /* top-n list filled, qsort the list */
    if (i == topn - 1)
      gk_dkvsortd(topn, list); 
    updated = 1; 
  }
  /* more than top-n keys */
  else{
    /* key is for sure not in top-n list, no updates */
    if (key <= list[topn-1].key); 
    /* otherwise, need to update the top-n list */
    else{
/*       /\* replace the min as the current key *\/ */
/*       list[topn-1].key = key; */
/*       list[topn-1].val = val; */
/*       /\* sort top-n *\/ */
/*       gk_dkvsortd(topn, list);  */  
      
      int j = topn - 2; 
      for (; j >= 0; j --){
	/* shift back */
	if (list[j].key < key){
	  list[j+1].key = list[j].key; 
	  list[j+1].val = list[j].val; 
	}
	/* right position to insert */
	else break; 
      }
      list[j+1].key = key; 
      list[j+1].val = val;       
    }
  }
  return updated; 

}
