#include<bprmf.h>

long idum = -1; 


#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0 - EPS)



/******************************************************************
 * extend csr matrix
 ******************************************************************/
void extend_binary(ctrl_t * ctrl, gk_csr_t * mat){
  

  int nnz0 = mat->rowptr[mat->nrows]; 
  int nrows = mat->nrows * 2; 
  int ncols = mat->ncols; 
  int nnz = mat->rowptr[mat->nrows] * 2;  

  int * rowptr = gk_malloc(sizeof(int)*(nrows+1), "malloc rowptr"); 
  int * rowind = gk_malloc(sizeof(int)*nnz, "malloc rowind"); 
  float * rowval = gk_malloc(sizeof(float)*nnz, "malloc roval"); 

  /* copy rating mat first */
  gk_icopy(mat->nrows, mat->rowptr, rowptr);
  gk_icopy(nnz0, mat->rowind, rowind); 
/*   gk_fcopy(nnz0, mat->rowval, rowval);  */
  for (int i = 0; i < nnz0; i ++)
/*     rowval[i] = mat->rowval[i] * ctrl->gamma ; /\* weight on the entire sum *\/ */
    rowval[i] = mat->rowval[i] * ctrl->gamma / (float)ctrl->nratings; 

  /* extend the binary version */
  for (int i = 0; i < mat->nrows; i ++)
    *(rowptr + mat->nrows + i) = *(rowptr + i) + nnz0; 
  *(rowptr + nrows) = nnz; 
  gk_icopy(nnz0, mat->rowind, rowind + nnz0); 
/*   gk_fset(ctrl->gamma, nnz, rowval + nnz0); /// */
  gk_fset(1.0, nnz, rowval + nnz0); ///
 

  /* modify mat */
  gk_csr_FreeContents(mat); 
  mat->nrows = nrows; 
  mat->ncols = ncols; 
  mat->rowptr = rowptr; 
  mat->rowind = rowind; 
  mat->rowval = rowval; 

}


/*********************************************************
 * generate a random number uniformly distribued in 0 -- 1
 *********************************************************/
double rand1(){
  
  return (double)rand()/(double)RAND_MAX; 
  
}


/*********************************************************
 * generate a random number from N(0, 1)
 *********************************************************/
double gasdev2(long * idum){

  static int iset = 0; 
  static double gset; 
  double fac, rsq, v1, v2; 

  if (*idum < 0) 
    iset = 0; 
  if (iset == 0){
    do{
      v1 = 2.0 * rand1() - 1.0; 
      v2 = 2.0 * rand1() - 1.0; 
      rsq = v1 * v1 + v2 * v2; 
      
    }while(rsq >= 1.0 || rsq == 0); 
    fac = sqrt(-2.0 * log(rsq)/rsq); 
    gset = v1*fac; 
    iset = 1; 
    return v2*fac; 
  }else{
    iset = 0; 
    return gset; 
  }
}



/***************************************************************
 * multi-value to binary, for non-negative matrix
 ***************************************************************/
void mv2binary(gk_csr_t * mat){
  
  int nnz = mat->rowptr[mat->nrows];

  for (int i = 0; i < nnz; i ++){
    if (mat->rowval[i] == 0);  // just in case
    else
      mat->rowval[i] = 1; 
  }
  if (mat->colval){
    for (int i = 0; i < nnz; i ++){
      if (mat->colval[i] == 0); 
      else
	gk_fset(nnz, 1.0, mat->colval); 
    }

  }
}




/*********************************************************
 * random sampling of an entire csr matrix
 *********************************************************/
gk_csr_t * csr_sampling_rows(gk_csr_t * mat, float rate){

  int nrows = mat->nrows; 
  int * idx = gk_malloc(sizeof(int)*nrows, "malloc idx"); 
  gk_RandomPermute(nrows, idx, 1); 
  
  int * mask = gk_malloc(sizeof(int)*nrows, "malloc mask"); 
  gk_iset(nrows, 1, mask); 
  int n = (int)(ceilf(rate * (float)nrows)); 
  for (int i = 0; i < n; i ++)
    mask[idx[i]] = 0; 
  
  int nnz = mat->rowptr[mat->nrows]; 
  int * mask2 = gk_malloc(sizeof(int)*nnz, "malloc mask2"); 
  gk_iset(nnz, 1, mask2); 
  for (int i = 0; i < nrows; i ++){
    if (mask[i] == 0){
      int nrowi = mat->rowptr[i+1] - mat->rowptr[i]; 
      for (int j = 0; j < nrowi; j ++)
	*(mask2 + j + mat->rowptr[i]) = 0; 
    }
  }


  gk_csr_t ** mat2 = gk_csr_Split(mat, mask2); 
  gk_csr_t * sample = mat2[0]; 

  gk_free((void **)&idx, LTERM); 
  gk_free((void **)&mask, LTERM); 
  gk_free((void **)&mask2, LTERM); 
  gk_csr_Free(&(mat2[1])); 
  gk_free((void **)&mat2, LTERM); 

  return sample; 

}




/***************************************************************
 * csr remove diagonal
 ***************************************************************/
void csr_RemoveDiag(gk_csr_t * mat){
 
  /* row view */
  for (int i = 0; i < mat->nrows; i ++){
    int nnz = mat->rowptr[i+1] - mat->rowptr[i]; 
    for (int k = 0; k < nnz; k ++){
      int j   = *(mat->rowptr[i] + k + mat->rowind); 
      float v = *(mat->rowptr[i] + k + mat->rowval); 
      if (i == j && v != 0)
	*(mat->rowptr[i] + k + mat->rowval) = 0; 
    }
  }

  /* column view */
  if (mat->colptr){
    for (int j = 0; j < mat->ncols; j ++){
      int nnz = mat->colptr[j+1] - mat->colptr[j]; 
      for (int k = 0; k < nnz; k ++){
	int i   = *(mat->colptr[j] + k + mat->colind); 
	float v = *(mat->colptr[j] + k + mat->colval); 
	if (i == j && v != 0)
	  *(mat->colptr[j] + k + mat->colval) = 0; 
      }
    }
  }
  
}
 


/***************************************************************
 * csr multiplication
 ***************************************************************/
gk_csr_t * csr_multiply(gk_csr_t * A, gk_csr_t * B){

  assert(A->ncols == B->nrows);

  /*   /\* well sort indices *\/ */
  /*   gk_csr_SortIndex(A, GK_CSR_ROW);  */
  /*   gk_csr_SortIndex(B, GK_CSR_ROW);  */

  int nnzA = A->rowptr[A->nrows]; 
  int nnzB = B->rowptr[B->nrows]; 
  int nnzbC = 20*gk_max((nnzA + nnzB), 100); 
  int max_nnzbC = nnzbC; 
  int cur_nnzC = 0; 
  /* int bsize = 1000;  */

  /* necessary spaces */
  /* tmp vec product */
  float * vm = gk_malloc(sizeof(float)*B->ncols, "malloc vm"); 
  gk_fset(B->ncols, 0, vm); 
  /* the result in csr */
  gk_csr_t * C = gk_csr_Create(); 
  C->colptr = NULL; C->colind = NULL; C->colval = NULL; 
  C->nrows = A->nrows; 
  C->ncols = B->ncols; 
  C->rowptr = gk_malloc(sizeof(int)*(C->nrows+1), "malloc C->rowptr"); 
  gk_iset(C->nrows + 1, 0, C->rowptr); 
  /* the following memories will be dynamically updated */
  C->rowind = gk_malloc(sizeof(int)*nnzbC, "malloc C->rowind"); 
  gk_iset(nnzbC, 0, C->rowind); 
  C->rowval = gk_malloc(sizeof(float)*nnzbC, "malloc C->rowval"); 
  gk_fset(nnzbC, 0, C->rowval); 
  
  ctimer_t * timer = gk_malloc(sizeof(ctimer_t), "malloc timer"); 
  ctimer_t * timer1 = gk_malloc(sizeof(ctimer_t), "malloc timer1"); 
  ctimer_t * timer2 = gk_malloc(sizeof(ctimer_t), "malloc timer2"); 
  ctimer_t * timer3 = gk_malloc(sizeof(ctimer_t), "malloc timer3"); 
  ctimer_t * timer4 = gk_malloc(sizeof(ctimer_t), "malloc timer4"); 
  double t = 0; 
  double t2 = 0; 
  double t3 = 0; 
  /* double t4 = 0;  */


  int last_nnz = 0; 
  int * nnz_idx = gk_malloc(sizeof(float)*B->ncols, "malloc nnz_idx"); 
  gk_iset(B->ncols, -1, nnz_idx); 

  start_timer(timer); 
  /* C = A * B */
  for (int i = 0; i < A->nrows; i ++){

    /* record C rows */
    C->rowptr[i+1] = C->rowptr[i]; 



    /*-------------------------------------------------------------------------->*/
    start_timer(timer1); 

    /* reset vector product */
    /* gk_fset(B->ncols, 0, vm);  */
    for (int k = 0; k < last_nnz; k ++){
      vm[nnz_idx[k]] = 0; 
      nnz_idx[k] = -1; 
    }
    last_nnz = 0; 
    gk_fset(B->ncols, 0, vm); 

    int nnzvm = 0; 
    
    /* product of this row */
    int nk = A->rowptr[i+1] - A->rowptr[i]; 
    for (int kk = 0; kk < nk; kk ++){
      int k     = *(A->rowptr[i] + kk + A->rowind); 
      float Aik = *(A->rowptr[i] + kk + A->rowval); 

      for (int jj = B->rowptr[k]; jj < B->rowptr[k+1]; jj ++){
	
	int j     = B->rowind[jj]; 
	float Bkj = B->rowval[jj]; 

	double prod = Aik*Bkj; 
	if (vm[j] == 0 && prod != 0){
	  /* 	if (vm[j] > -1.0*EPSILON && vm[j] < EPSILON && prod != 0){ */
	  nnzvm ++; 
	  nnz_idx[last_nnz] = j; 
	  last_nnz ++; 
	}
	/* else if (vm[j] != 0 && vm[j] + prod == 0) */
	/*   nnzvm --;  */

	vm[j] += prod; 

      }
    }

    end_timer(timer1); 
    t += (double)(timer1->end - timer1->start)/CLOCKS_PER_SEC; 
    /*<--------------------------------------------------------------------------*/




    /* /\*-------------------------------------------------------------------------->*\/ */
    /* start_timer(timer4);  */
    /* int nnzvm2 = 0;  */
    /* for (int j = 0; j < B->ncols; j ++){ */
    /*   if (vm[j] != 0) */
    /* 	nnzvm2 ++; */
    /* } */
    /* end_timer(timer4);  */
    /* t4 += (double)(timer4->end - timer4->start)/CLOCKS_PER_SEC;  */
    /* assert(nnzvm2 == nnzvm);  */
    /* /\*<--------------------------------------------------------------------------*\/     */


    /*-------------------------------------------------------------------------->*/
    start_timer(timer2); 
    /* need to increase the space */
    if (cur_nnzC + nnzvm > max_nnzbC){
      printf("Realloc C = A*B: cur_nnzC = %d, nnzvm = %d, max_nnzbC = %d\n", cur_nnzC, nnzvm, max_nnzbC);
      /* max_nnzbC += bsize;  */
      max_nnzbC *= 2; 
      C->rowind = gk_irealloc(C->rowind, sizeof(int)*max_nnzbC, "realloc C->rowind"); 
      C->rowval = gk_frealloc(C->rowval, sizeof(float)*max_nnzbC, "realloc C->rowval"); 
      /*       struct rusage rusage;  */
      /*       getrusage (RUSAGE_SELF, &rusage);  */
      /*       printf("Maximum memory used: %10ld K bytes\n", rusage.ru_maxrss);  */
      //printf(" Maximum memory used: %10ju bytes\n", gk_GetMaxMemoryUsed()); 
    }
    end_timer(timer2); 
    t2 += (double)(timer2->end - timer2->start)/CLOCKS_PER_SEC; 
    /*<--------------------------------------------------------------------------*/



    /*-------------------------------------------------------------------------->*/
    start_timer(timer3); 
    /* /\* save the results *\/ */
    /* for (int j = 0; j < B->ncols; j ++){ */
    /*   if (vm[j] != 0){ */
    /* 	C->rowptr[i+1] ++; */
    /* 	C->rowind[cur_nnzC] = j;  */
    /* 	C->rowval[cur_nnzC] = vm[j];  */
    /* 	cur_nnzC ++;  */
    /*   }  */
    /* } */

    /* save the results */
    /* gk_isorti(last_nnz, nnz_idx); // not necessary for sorting */
    for (int j = 0; j < last_nnz; j ++){
      if (vm[nnz_idx[j]] != 0){
	/*       if (vm[nnz_idx[j]] > EPSILON || vm[nnz_idx[j]] < -1.0*EPSILON){ */
	C->rowptr[i+1] ++;
	C->rowind[cur_nnzC] = nnz_idx[j]; 
	C->rowval[cur_nnzC] = vm[nnz_idx[j]]; 
	cur_nnzC ++; 
      } 
    }
    end_timer(timer3); 
    t3 += (double)(timer3->end - timer3->start)/CLOCKS_PER_SEC; 
    /*<--------------------------------------------------------------------------*/

  }

  end_timer(timer); 
  display_timer(timer, "csr multiplication"); 
  printf("csr multiplication product  %.5f\n", t); 
  printf("csr multiplication resize   %.5f\n", t2); 
  printf("csr multiplication save     %.5f\n", t3); 
  /* printf("csr scan    %.5f\n", t4);  */

  start_timer(timer); 
  /* format the sparse matrix */
  C->rowind = gk_irealloc(C->rowind, sizeof(int)*cur_nnzC, "malloc C->rowind finally"); 
  C->rowval = gk_frealloc(C->rowval, sizeof(float)*cur_nnzC, "malloc C->rowind finally"); 
  end_timer(timer); 
  printf("csr multiplication reformat %.5f\n", (double)(timer->end - timer->start)/CLOCKS_PER_SEC); 

  

  /* csr_Write(A, "./TEST/A.mat", "w", GK_CSR_FMT_CSR, 1, 1); */
  /* csr_Write(B, "./TEST/B.mat", "w", GK_CSR_FMT_CSR, 1, 1); */
  /* csr_Write(C, "./TEST/C.mat", "w", GK_CSR_FMT_CSR, 1, 1); */

  /* clean up */
  gk_free((void **)&vm, &nnz_idx, LTERM); 
  gk_free((void **)&timer, &timer1, &timer2, &timer3, &timer4, LTERM); 

  printf("C = A*B\n"); 
  printf("A: %d by %d, nnz = %d\n", A->nrows, A->ncols, A->rowptr[A->nrows]); 
  printf("B: %d by %d, nnz = %d\n", B->nrows, B->ncols, B->rowptr[B->nrows]); 
  printf("C: %d by %d, nnz = %d\n", C->nrows, C->ncols, C->rowptr[C->nrows]); 

  return C; 

}


/***************************************************************
 * row or column mean
 ***************************************************************/
float * csr_mean(gk_csr_t * mat, int what){

  float * mean = NULL; 

  switch (what){

  case GK_CSR_ROW:
    mean = gk_malloc(sizeof(float)*mat->nrows, "malloc mean"); 
    gk_fset(mat->nrows, 0, mean); 
    for (int i = 0; i < mat->nrows; i ++){
      int ni = mat->rowptr[i+1] - mat->rowptr[i]; 
      for (int jj = 0; jj < ni; jj ++){
	mean[i] += *(mat->rowptr[i] + jj + mat->rowval); 
      }
      if (ni > 0)
	mean[i] /= (float)mat->ncols; 
    }
    break; 

  case GK_CSR_COL:
    mean = gk_malloc(sizeof(float)*mat->ncols, "malloc mat->ncols"); 
    gk_fset(mat->ncols, 0, mean); 
    for (int j = 0; j < mat->ncols; j ++){
      int nj = mat->colptr[j+1] - mat->colptr[j]; 
      for (int ii = 0; ii < nj; ii ++){
	mean[j] += *(mat->colptr[j] + ii + mat->colval); 
      }
      if (nj > 0)
	mean[j] /= (float)mat->nrows; 
    }
    break; 
  }


  return mean; 

}


/*******************************************************************
 * extract the i-th columns/rows into dense format
 *******************************************************************/
void csr_ExtractColumnsRows(gk_csr_t * mat, int i, float * vec, int what){

  int * ptr = NULL; 
  int * ind = NULL; 
  float * val = NULL; 
  
  switch(what){

  case GK_CSR_COL:
    if (mat->colptr == NULL)
      gk_csr_CreateIndex(mat, GK_CSR_COL); 
    ptr = mat->colptr; 
    ind = mat->colind; 
    val = mat->colval; 
    gk_fset(mat->nrows, 0, vec); 
    break; 

  case GK_CSR_ROW:
    ptr = mat->rowptr; 
    ind = mat->rowind; 
    val = mat->rowval;
    gk_fset(mat->ncols, 0, vec); 
    break; 
  }

  int nnz = ptr[i+1] - ptr[i]; 
  for (int k = 0; k < nnz; k ++){
    int j   = *(ptr[i] + k + ind); 
    float v = *(ptr[i] + k + val); 
    vec[j] = v; 
  }

}



/***************************************************************
 * csr multiplication
 ***************************************************************/
void csr_multiplyScalar(gk_csr_t * A, float a){

  int nnz = A->rowptr[A->nrows]; 

  /* always row view */
  for (int i = 0; i < nnz; i ++){
    A->rowval[i] *= a;
  }

  /* also column view */
  if (A->colval){
    for (int i = 0; i < nnz; i ++)
      A->colval[i] *= a; 
  }

}


/***************************************************************
 * csr init by Gaussian & sparsity
 ***************************************************************/
void csr_RandomSparseInit(gk_csr_t ** A, int nrows, int ncols, 
			  float srate, float mean, float stdev){

  /* check the space */
  if (*A == NULL){
    *A = gk_csr_Create();
    (*A)->nrows = nrows; 
    (*A)->ncols = ncols; 
  }else{
    assert((*A)->nrows == nrows); 
    assert((*A)->ncols == ncols); 
  }
  
  /* space for the sparsity */
  int * rowptr = gk_malloc(sizeof(int)*(nrows+1), "malloc rowptr");
  rowptr[0] = 0;
  for (int i = 0; i < nrows; i ++)
    rowptr[i+1] = rowptr[i] + ceil(ncols * srate);
  int nnz = rowptr[nrows];     
  int * rowind = gk_malloc(sizeof(int)*nnz, "malloc rowind"); 
  float * rowval = gk_malloc(sizeof(float)*nnz, "malloc rowval");

  /* init the non-zero values and their positions */
  for (int i = 0; i < nnz; i ++)
    rowval[i] = fabs(mean + stdev * gasdev2(&idum)); // >= 0
  for (int i = 0; i < nrows; i ++ ){
    int nnzi = rowptr[i+1] - rowptr[i];
    for (int j = 0; j < nnzi; j ++){
      int cidx = gk_irandInRange(ncols);
      while(1){
	int k = 0; 
	for (; k < j; k ++){
	  if (cidx == *(rowptr[i] + k + rowind)){
	    cidx = gk_irandInRange(ncols);
	    break; 
	  }
	}
	if (k == j) break; 
      }
      *(rowptr[i] + j + rowind) = cidx; 
    }
  }

  /* finally ensemble */
  (*A)->rowptr = rowptr; 
  (*A)->rowind = rowind; 
  (*A)->rowval = rowval; 
  gk_csr_CreateIndex(*A, GK_CSR_COL);

}



/***************************************************************
 * csr transpose
 ***************************************************************/
void csr_transpose(gk_csr_t * A){

  int nrows = A->nrows; 
  int ncols = A->ncols; 
  int * rowptr   = A->rowptr; 
  int * rowind   = A->rowind; 
  float * rowval = A->rowval; 

  if (A->colptr){
    gk_free((void **)&A->colptr, LTERM); 
    gk_free((void **)&A->colind, LTERM); 
    gk_free((void **)&A->colval, LTERM); 
  }

  A->ncols = nrows; 
  A->nrows = ncols; 
  A->colptr = rowptr; 
  A->colind = rowind; 
  A->colval = rowval; 
  A->rowptr = NULL; 
  A->rowind = NULL; 
  A->rowval = NULL; 

  gk_csr_CreateIndex(A, GK_CSR_ROW); 

}



/*************************************************************
 * dump the csr into a file
 *************************************************************/
void csr_Write(gk_csr_t *mat, char *filename, char * mode, 
	       int format, int writevals, int numbering) {

  int i, j;
  FILE *fpout;
  
  if (filename)
    fpout = gk_fopen(filename, mode, "gk_csr_Write: fpout");
  else
    fpout = stdout;

  if (format == GK_CSR_FMT_CLUTO) {
    fprintf(fpout, "%d %d %d\n", mat->nrows, mat->ncols, mat->rowptr[mat->nrows]);
    writevals = 1;
    numbering = 1;
  }
  
  for (i=0; i<mat->nrows; i++) {
    for (j=mat->rowptr[i]; j<mat->rowptr[i+1]; j++) {
      fprintf(fpout, " %d", mat->rowind[j]+(numbering ? 1 : 0));
      if (writevals)
	fprintf(fpout, " %.5f", mat->rowval[j]);
    }
    fprintf(fpout, "\n");
  }
  if (filename)
    gk_fclose(fpout); 

}



/***************************************************************
 * extract one column from csr
 ***************************************************************/
void findCol(gk_csr_t * X, int j, double * col){
  
  for (int ii = X->colptr[j]; ii < X->colptr[j+1]; ii ++){
    int i   = X->colind[ii]; 
    float v = X->colval[ii]; 
    col[i]  = (double)v; 
  }

}



/***************************************************************
 * create a ctrl
 **************************************************************/
ctrl_t * create_ctrl(){

  ctrl_t * ctrl = gk_malloc(sizeof(ctrl_t), "malloc ctrl"); 

  ctrl->train_file = NULL; 
  ctrl->test_file  = NULL; 
  ctrl->ft_file = NULL; 
  ctrl->suggest_file = NULL; 
  ctrl->constraint_file = NULL; 
  ctrl->initW_file = NULL; 
  ctrl->similarity_file = NULL; 

  /* all the default values */
  ctrl->k = 50; 
  ctrl->k0 = 1; 
  ctrl->k1 = 1; 
  ctrl->user_bias = false; 
  ctrl->item_bias = false; 

  ctrl->init_mean = 0; 
  ctrl->init_stdev = 0.1; 

  ctrl->max_nepochs = 30; 
  ctrl->iter_length = 5; 
  
  ctrl->lrate = 0.05; 
  ctrl->reg_i = 0.0025; 
  ctrl->reg_j = 0.00025; 
  ctrl->reg_u = 0.0025; 

  ctrl->topn = 10; 
  ctrl->dbglvl = 0; 
  ctrl->realtime_eval = 0; 
  ctrl->fast_sample = 0; 
  ctrl->wsim = WSIM_SPARSE; 
  ctrl->wtype = WTYPE_ITEM;
  ctrl->blas = 0; 
  ctrl->notest = 0;
  ctrl->exttest = 0; 
  ctrl->fast_test = 0; 
  
  ctrl->load_model = 0; 
  ctrl->save_model = 0; 
  ctrl->save_model_iter = 0; 
  
  ctrl->pred_file    = NULL; 
  ctrl->ufactor_file = NULL; 
  ctrl->ifactor_file = NULL; 
  ctrl->exttest_file = NULL; 

  ctrl->lmethod = LMETHOD_BPRMF; 
  ctrl->normalize = 0; 
  ctrl->sc_weighted = 0; 

  ctrl->sm_topk = -1; 
  ctrl->test2 = 0; 

  ctrl->beta    = 1.0; 
  ctrl->lambda  = 1.0; 
  ctrl->beta1   = 1.0; 
  ctrl->beta2   = 1.0; 
  ctrl->lambda1 = 1.0; 
  ctrl->lambda2 = 1.0; 
  ctrl->sigma   = 100.0; 
  ctrl->alpha   = 10000.0; 

  ctrl->starti = -1; 
  ctrl->endi = -1; 
  ctrl->interi = -1; 


  ctrl->error2 = 0; 
  ctrl->w1 = 0.5; 
  ctrl->normalizeA = 0; 
  ctrl->p = 1; 
  ctrl->sparsity = 0; 
  ctrl->errork = 0; 
  ctrl->gnoise = 0; 
  ctrl->constraint = 0; 
  ctrl->rowmajor = 0; 
  ctrl->ibias = 0; 
  ctrl->ibias_step = 0.05; 

  ctrl->bl = 0;     /* by default, non-negativity constraint */
  ctrl->bu = 1e20;  /* by default, no upper bound */

  ctrl->stop = 0; /* by default */
  ctrl->tol = 0.01; 

  ctrl->sample_train = 0; 
  ctrl->srate = 0.8; 

  ctrl->optTol = 1e-3; 

  ctrl->initw = 0; 

  ctrl->sim_threshold = 0; 

  ctrl->mst = 0; 

  ctrl->pred_norm = 0; 

  ctrl->Aopt = AOPT_SPARSE; 

  //ctrl->cdl1_method = CDL1_METHOD_NAIVE; 
  ctrl->cdl1_method = CDL1_METHOD_COVARIANCE; 

  ctrl->combineBR = 0; 
  ctrl->gamma = 1.0; 
  ctrl->gamma1 = 1.0; 
  ctrl->nratings = 10;  /* by default, no ratings used */ 

  ctrl->check_support = 0; 
  
  ctrl->test_bcls = 0; 
  ctrl->max_bcls_niters = 10; 

  ctrl->suggest_br = 0; 

  ctrl->rscale = 0; 
  ctrl->rscale_alpha = 1.0; 

  ctrl->c_pos = 1.0; 
  ctrl->pred_rating = 0; 

  ctrl->kernel = KERNEL_LINEAR; 

  ctrl->nthreads = 1; 
  ctrl->openmp = 0; 

  ctrl->mult2binary = 0; 

  return ctrl; 

}

/***************************************************************
 * free a ctrl
 **************************************************************/
void free_ctrl(ctrl_t * ctrl){

  gk_free((void **)&ctrl->similarity_file, LTERM); 
  gk_free((void **)&ctrl->initW_file, LTERM); 
  gk_free((void **)&ctrl->suggest_file, LTERM); 
  gk_free((void **)&ctrl->train_file, LTERM); 
  gk_free((void **)&ctrl->test_file, LTERM); 
  gk_free((void **)&ctrl->ft_file, LTERM); 
  gk_free((void **)&ctrl->ufactor_file, LTERM); 
  gk_free((void **)&ctrl->ifactor_file, LTERM); 
  gk_free((void **)&ctrl->exttest_file, LTERM); 
  gk_free((void **)&ctrl->constraint_file, LTERM); 
  gk_free((void **)&ctrl->pred_file, LTERM); 
  gk_free((void **)&ctrl, LTERM); 
  

}

/***********************************************************
 * start a ctimer
 ***********************************************************/
void start_timer(ctimer_t * ctimer){
  
  ctimer->start = clock(); 
  
}

/***********************************************************
 * end a ctimer
 ***********************************************************/
void end_timer(ctimer_t * ctimer){

  ctimer->end = clock(); 
  
}

/***********************************************************
 * display duration
 ***********************************************************/
void display_timer(ctimer_t * ctimer, char * msg){

  printf("----- elapsed CPU time for %s: %f s\n", msg, 
         (double)(ctimer->end - ctimer->start)/CLOCKS_PER_SEC);  
  fflush(stdout);

}

/***********************************************************
 * count nnz
 ***********************************************************/
int count_nnz(double * array, int narray){

  int nnz = 0; 

  for (int i = 0; i < narray; i ++){
    if (array[i] > 1e-10 || array[i] < -1e-10)
      nnz ++; 
  }

  return nnz; 

}

/*************************************************************************
 * find topk indices
 *************************************************************************/
void find_topk(double * w, int n, int topk, double * map, int * topk2){


  gk_dkv_t * wkv = gk_malloc(sizeof(gk_dkv_t)*n, "malloc wkv"); 
  int k2 = 0; 

  for (int i = 0; i < n; i ++){
    wkv[i].key = w[i]; 
    wkv[i].val = i; 
    if (w[i] > 1e-10) k2 ++; 
  }

  gk_dkvsortd(n, wkv); 

  for (int i = 0; i < ((topk <= k2)? topk:k2); i ++){
    map[i] = wkv[i].val; 
  }
  
  *topk2 = ((topk <= k2)? topk:k2);
  gk_free((void **)&wkv, LTERM); 

}

/****************************************************************
 * find the i-th column
 ***************************************************************/
void getConstraint(ctrl_t * ctrl, gk_csr_t * constraint, int i, double * w){
  
/*   int nr = constraint->nrows;  */
/*   double * w = gk_malloc(sizeof(double)*nr, "malloc w");  */
/*   gk_dset(nr, 0, w);  */
  
  int nnz = constraint->colptr[i+1] - constraint->colptr[i]; 
  for (int j = 0; j < nnz; j ++){
    int k = *(constraint->colptr[i] + j + constraint->colind); 
/*     assert(k != i); // tmp */
    w[k]  = *(constraint->colptr[i] + j + constraint->colval); 
  }

/*   return w;  */

}

/****************************************************************
 * get an initial W from a file
 ***************************************************************/
double * get_initW(char * file, int n){

  double * initw = gk_malloc(sizeof(double)*n, "malloc initw"); 

  gk_dset(n, 0, initw); 

  FILE * fp = gk_fopen(file, "r", "open file"); 

  /* only one line */
  size_t lnlen = 0; 
  char * line = NULL; 
  gk_getline(&line, &lnlen, fp);

  gk_Tokens_t itokens; 
  gk_strtokenize(line, " \t\n", &itokens); 

  for (int j = 0; j < itokens.ntoks; j += 2)
    initw[atoi(itokens.list[j])-1] = atof(itokens.list[j+1]); 
 
  gk_freetokenslist(&itokens); 
  gk_free((void **)&line, LTERM); 
  gk_fclose(fp); 

  return initw; 

}
